window.QUIZ_DATA = {
  "version": "1.0",
  "exam": "SSC CGL (Tier 1) General Awareness - Current Affairs",
  "marking_scheme": {
    "correct_marks": 2.0,
    "negative_marks": -0.5,
    "unattempted_marks": 0.0
  },
  "categories": [
    {
      "id": "sports",
      "name": "Sports & Tournaments",
      "description": "Cricket, Tennis Grand Slams, Asian Games, Commonwealth, Chess, Hockey, Football, Athletics, and National Sports Events",
      "icon": "🏆",
      "color": "#16a34a"
    },
    {
      "id": "politics",
      "name": "Politics & National Affairs",
      "description": "Parliamentary Bills, Governance Policies, Constitutional Amendments, State Schemes, and Supreme Court Landmark Rulings",
      "icon": "🏛️",
      "color": "#2563eb"
    },
    {
      "id": "economy",
      "name": "Economy, Banking & Finance",
      "description": "Union Budget, RBI Monetary Policy, GDP Projections, GST Collections, Inflation Trends, and Banking Reforms",
      "icon": "📈",
      "color": "#d97706"
    },
    {
      "id": "science_tech_defence",
      "name": "Science, Technology & Defence",
      "description": "ISRO Space Missions, DRDO Missile Tests, Joint Military Exercises, AI & Quantum Innovations, and Defence Indigenisation",
      "icon": "🚀",
      "color": "#7c3aed"
    },
    {
      "id": "international",
      "name": "International Affairs & Summits",
      "description": "BRICS, G20, SCO, UN Forums, Bilateral MoUs, Global Indices & Rankings, and Geopolitical Developments",
      "icon": "🌐",
      "color": "#0284c7"
    },
    {
      "id": "awards_appointments",
      "name": "Awards, Honours & Appointments",
      "description": "Padma Awards, National Sports Awards, Literary Honours, Nobel/Booker, and New Constitutional & Statutory Heads",
      "icon": "🎖️",
      "color": "#db2777"
    }
  ],
  "months": [
    {
      "id": "feb2026",
      "name": "February 2026",
      "short": "Feb 2026"
    },
    {
      "id": "mar2026",
      "name": "March 2026",
      "short": "Mar 2026"
    },
    {
      "id": "apr2026",
      "name": "April 2026",
      "short": "Apr 2026"
    },
    {
      "id": "may2026",
      "name": "May 2026",
      "short": "May 2026"
    },
    {
      "id": "jun2026",
      "name": "June 2026",
      "short": "Jun 2026"
    },
    {
      "id": "jul2026",
      "name": "July 2026",
      "short": "Jul 2026"
    },
    {
      "id": "aug2026",
      "name": "August 2026",
      "short": "Aug 2026"
    }
  ],
  "quizzes": {
    "sports_feb2026": {
      "id": "sports_feb2026",
      "category_id": "sports",
      "category_name": "Sports & Tournaments",
      "month_id": "feb2026",
      "month_name": "February 2026",
      "title": "Sports Current Affairs - February 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "Which state/UT hosted the 4th edition of the Khelo India Winter Games held in February 2026?",
          "options": [
            "Himachal Pradesh",
            "Jammu & Kashmir and Ladakh",
            "Uttarakhand",
            "Sikkim"
          ],
          "correct": 1,
          "explanation": "The 4th edition of the Khelo India Winter Games was hosted across two legs in Jammu & Kashmir (Gulmarg) and the Union Territory of Ladakh (Leh)."
        },
        {
          "id": 2,
          "question": "Who won the Men's Singles title at the Australian Open 2026 in Melbourne?",
          "options": [
            "Jannik Sinner",
            "Carlos Alcaraz",
            "Daniil Medvedev",
            "Novak Djokovic"
          ],
          "correct": 0,
          "explanation": "Jannik Sinner clinched the Australian Open Men's Singles crown, demonstrating dominant hard-court baseline performance."
        },
        {
          "id": 3,
          "question": "Who clinched the Women's Singles title at the Australian Open 2026?",
          "options": [
            "Aryna Sabalenka",
            "Iga Swiatek",
            "Coco Gauff",
            "Elena Rybakina"
          ],
          "correct": 0,
          "explanation": "Aryna Sabalenka successfully defended her Australian Open Women's Singles title with a commanding straight-sets victory."
        },
        {
          "id": 4,
          "question": "Which country won the ICC Under-19 Men's Cricket World Cup title concluded in February 2026?",
          "options": [
            "India",
            "Australia",
            "South Africa",
            "England"
          ],
          "correct": 1,
          "explanation": "Australia claimed the ICC U-19 Men's Cricket World Cup, defeating India in the final after a strong bowling display."
        },
        {
          "id": 5,
          "question": "Which Indian state topped the overall medal tally in the Khelo India Winter Games 2026?",
          "options": [
            "Army Sports Control Board",
            "Jammu & Kashmir",
            "Maharashtra",
            "Himachal Pradesh"
          ],
          "correct": 0,
          "explanation": "The Army Sports Control Board (ASCB) topped the medal standings in the Khelo India Winter Games with gold medals in ski-mountaineering and biathlon."
        },
        {
          "id": 6,
          "question": "Who won the prestigious Tata Steel Masters Chess Tournament 2026 held in Wijk aan Zee?",
          "options": [
            "Wei Yi",
            "Gukesh D",
            "Nodirbek Abdusattorov",
            "Magnus Carlsen"
          ],
          "correct": 0,
          "explanation": "Chinese Grandmaster Wei Yi emerged triumphant at the 86th Tata Steel Chess Masters in Wijk aan Zee after winning the blitz tiebreaks."
        },
        {
          "id": 7,
          "question": "Which team won the Senior Women's National Hockey Championship in February 2026?",
          "options": [
            "Hockey Haryana",
            "Hockey Madhya Pradesh",
            "Railway Sports Promotion Board",
            "Hockey Jharkhand"
          ],
          "correct": 0,
          "explanation": "Hockey Haryana clinched the 14th Senior Women's National Hockey Championship title by defeating Railway Sports Promotion Board in the final."
        },
        {
          "id": 8,
          "question": "Indian shooter Divyansh Singh Panwar clinched gold in which event at the ISSF World Cup in February 2026?",
          "options": [
            "10m Air Rifle Men",
            "50m Rifle 3 Positions",
            "25m Rapid Fire Pistol",
            "10m Air Pistol Men"
          ],
          "correct": 0,
          "explanation": "Divyansh Singh Panwar secured the gold medal in the Men's 10m Air Rifle event with a world-record final score at the ISSF World Cup in Cairo."
        },
        {
          "id": 9,
          "question": "Which Indian city hosted the Badminton Asia Team Championships in February 2026?",
          "options": [
            "Shah Alam (Malaysia)",
            "Bangalore",
            "Guwahati",
            "Hyderabad"
          ],
          "correct": 0,
          "explanation": "The Badminton Asia Team Championships 2026 took place in Shah Alam, Selangor, Malaysia, where the Indian women's team scripted historic performances."
        },
        {
          "id": 10,
          "question": "Who won the historic gold medal for the Indian Women's Badminton team at the Badminton Asia Team Championships?",
          "options": [
            "PV Sindhu and Anmol Kharb",
            "Ashwini Ponnappa and Tanisha Crasto",
            "Saina Nehwal",
            "Treesa Jolly"
          ],
          "correct": 0,
          "explanation": "Young prodigy Anmol Kharb delivered the decisive victory in the 5th rubber alongside PV Sindhu to secure India's maiden Badminton Asia Team gold."
        },
        {
          "id": 11,
          "question": "Which franchise won the Pro Kabaddi League (PKL) Season 11/12 title in February 2026?",
          "options": [
            "Puneri Paltan",
            "Haryana Steelers",
            "Jaipur Pink Panthers",
            "Dabang Delhi KC"
          ],
          "correct": 0,
          "explanation": "Puneri Paltan captured their maiden Pro Kabaddi League title with a stellar defensive performance against Haryana Steelers in the final."
        },
        {
          "id": 12,
          "question": "Who became the highest run-scorer for India in the ICC Under-19 World Cup 2026?",
          "options": [
            "Uday Saharan",
            "Musheer Khan",
            "Sachin Dhas",
            "Arshin Kulkarni"
          ],
          "correct": 0,
          "explanation": "Captain Uday Saharan finished as the leading run-getter of the tournament, guiding India into the finals with crucial knocks."
        },
        {
          "id": 13,
          "question": "Which city hosted the FIH Hockey Olympic Qualifiers leading to the summer games?",
          "options": [
            "Ranchi",
            "Bhubaneswar",
            "Valencia",
            "Rourkela"
          ],
          "correct": 0,
          "explanation": "Ranchi (Jharkhand) successfully hosted the Women's FIH Olympic Qualifiers at the Marang Gomke Jaipal Singh Astroturf Hockey Stadium."
        },
        {
          "id": 14,
          "question": "Which athlete won the gold medal in Men's Shot Put at the Asian Indoor Athletics Championships in February 2026?",
          "options": [
            "Tajinderpal Singh Toor",
            "Om Prakash Karhana",
            "Manpreet Kaur",
            "Abha Khatua"
          ],
          "correct": 0,
          "explanation": "Tajinderpal Singh Toor clinched the gold medal in Men's Shot Put with a championship record throw at the 11th Asian Indoor Athletics Championships in Tehran."
        },
        {
          "id": 15,
          "question": "Who won the Men's Singles title at the Chennai Open ATP Challenger in February 2026?",
          "options": [
            "Sumit Nagal",
            "Luca Nardi",
            "Ramkumar Ramanathan",
            "Sasikumar Mukund"
          ],
          "correct": 0,
          "explanation": "India's Sumit Nagal defeated Luca Nardi in the final to win the Chennai Open ATP Challenger and break into the ATP Top 100 ranking."
        },
        {
          "id": 16,
          "question": "Which football club won the Spanish Super Cup (Supercopa de España) in 2026?",
          "options": [
            "Real Madrid",
            "Barcelona",
            "Atletico Madrid",
            "Athletic Bilbao"
          ],
          "correct": 0,
          "explanation": "Real Madrid lifted the Supercopa de España trophy after an emphatic 4-1 victory over rivals FC Barcelona in Riyadh."
        },
        {
          "id": 17,
          "question": "Which nation won the Africa Cup of Nations (AFCON) title in February 2026?",
          "options": [
            "Ivory Coast",
            "Nigeria",
            "Senegal",
            "Morocco"
          ],
          "correct": 0,
          "explanation": "Host nation Ivory Coast (Côte d'Ivoire) produced a thrilling comeback to defeat Nigeria 2-1 and lift the Africa Cup of Nations trophy."
        },
        {
          "id": 18,
          "question": "Who was named the Most Valuable Player (MVP) of the FIH Men's Hockey5s World Cup?",
          "options": [
            "Maninder Singh",
            "Akhimullah Anuar",
            "Raheel Mohammed",
            "Arshad Liaqat"
          ],
          "correct": 0,
          "explanation": "India's forward Maninder Singh was recognized for outstanding goal-scoring prowess at the inaugural FIH Hockey5s World Cup in Muscat."
        },
        {
          "id": 19,
          "question": "Which Indian grandmaster secured the runner-up position at the Prague International Chess Festival?",
          "options": [
            "R Praggnanandhaa",
            "D Gukesh",
            "Vidit Gujrathi",
            "P Harikrishna"
          ],
          "correct": 1,
          "explanation": "Grandmaster D Gukesh put up a sterling performance in Prague, reinforcing his preparation for the FIDE Candidates Tournament."
        },
        {
          "id": 20,
          "question": "In which stadium was the final of the Ranji Trophy 2025-26 knockout stage scheduled to conclude?",
          "options": [
            "Wankhede Stadium, Mumbai",
            "Eden Gardens, Kolkata",
            "M. Chinnaswamy Stadium, Bengaluru",
            "Narendra Modi Stadium, Ahmedabad"
          ],
          "correct": 0,
          "explanation": "The prestigious Ranji Trophy final matches were hosted at the historic Wankhede Stadium in Mumbai."
        },
        {
          "id": 21,
          "question": "Who was appointed as the head coach of the Indian Men's Senior National Football Team?",
          "options": [
            "Manolo Marquez",
            "Igor Stimac",
            "Clifford Miranda",
            "Khalid Jamil"
          ],
          "correct": 0,
          "explanation": "AIFF appointed experienced coach Manolo Marquez to take charge of the Indian senior men's national football team."
        },
        {
          "id": 22,
          "question": "Which player achieved the milestone of 500 Test wickets in February 2026 against England?",
          "options": [
            "Ravichandran Ashwin",
            "Ravindra Jadeja",
            "Jasprit Bumrah",
            "Mohammed Shami"
          ],
          "correct": 0,
          "explanation": "Ravichandran Ashwin became only the second Indian bowler after Anil Kumble to pick up 500 Test wickets, achieving the feat at Rajkot."
        },
        {
          "id": 23,
          "question": "Who scored double centuries in consecutive Test matches against England in February 2026?",
          "options": [
            "Yashasvi Jaiswal",
            "Shubman Gill",
            "Rohit Sharma",
            "KL Rahul"
          ],
          "correct": 0,
          "explanation": "Young opener Yashasvi Jaiswal scored magnificent double centuries in Visakhapatnam and Rajkot, equalling Virat Kohli's record."
        },
        {
          "id": 24,
          "question": "Which country won the Asian indoor athletics championship overall medal table in February 2026?",
          "options": [
            "China",
            "Japan",
            "Kazakhstan",
            "India"
          ],
          "correct": 0,
          "explanation": "China topped the medal tally at the Asian Indoor Athletics Championships in Tehran, bagging 8 gold medals."
        },
        {
          "id": 25,
          "question": "Which stadium hosted the opening ceremony of the Khelo India University Games (Ashtalakshmi 2026)?",
          "options": [
            "Sarusajai Stadium, Guwahati",
            "Kanteerava Stadium, Bengaluru",
            "Kalinga Stadium, Bhubaneswar",
            "Jawaharlal Nehru Stadium, Delhi"
          ],
          "correct": 0,
          "explanation": "The 4th edition of Khelo India University Games (named Ashtalakshmi 2026) was inaugurated at Sarusajai Stadium in Guwahati, Assam."
        }
      ]
    },
    "sports_mar2026": {
      "id": "sports_mar2026",
      "category_id": "sports",
      "category_name": "Sports & Tournaments",
      "month_id": "mar2026",
      "month_name": "March 2026",
      "title": "Sports Current Affairs - March 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "Which team won the Women's Premier League (WPL) 2026 championship title?",
          "options": [
            "Royal Challengers Bangalore",
            "Delhi Capitals",
            "Mumbai Indians",
            "UP Warriorz"
          ],
          "correct": 0,
          "explanation": "Royal Challengers Bangalore (RCB) led by Smriti Mandhana defeated Delhi Capitals in the final at Arun Jaitley Stadium to lift their maiden WPL trophy."
        },
        {
          "id": 2,
          "question": "Who won the Orange Cap for scoring the most runs in WPL 2026?",
          "options": [
            "Ellyse Perry",
            "Meg Lanning",
            "Smriti Mandhana",
            "Shafali Verma"
          ],
          "correct": 0,
          "explanation": "Ellyse Perry of Royal Challengers Bangalore won the Orange Cap with 347 runs in 9 innings at an average of 69.4."
        },
        {
          "id": 3,
          "question": "Who won the Purple Cap for taking the most wickets in WPL 2026?",
          "options": [
            "Shreyanka Patil",
            "Sophie Molineux",
            "Asha Sobhana",
            "Marizanne Kapp"
          ],
          "correct": 0,
          "explanation": "Young off-spinner Shreyanka Patil claimed 13 wickets in the tournament to capture the Purple Cap in WPL 2026."
        },
        {
          "id": 4,
          "question": "Which state team won the 89th Ranji Trophy title in March 2026?",
          "options": [
            "Mumbai",
            "Vidarbha",
            "Saurashtra",
            "Madhya Pradesh"
          ],
          "correct": 0,
          "explanation": "Mumbai defeated Vidarbha by 169 runs in the final at Wankhede Stadium to lift their record-extending 42nd Ranji Trophy title."
        },
        {
          "id": 5,
          "question": "Who won the Men's Singles title at the All England Open Badminton Championships 2026?",
          "options": [
            "Jonatan Christie",
            "Anthony Sinisuka Ginting",
            "Viktor Axelsen",
            "Lakshya Sen"
          ],
          "correct": 0,
          "explanation": "Indonesia's Jonatan Christie defeated compatriot Anthony Ginting in an all-Indonesian final to win the All England Open."
        },
        {
          "id": 6,
          "question": "Who won the Women's Singles title at the All England Open Badminton Championships 2026?",
          "options": [
            "Carolina Marin",
            "Akane Yamaguchi",
            "An Se-young",
            "Tai Tzu-ying"
          ],
          "correct": 0,
          "explanation": "Spain's Carolina Marin won the All England Open Women's Singles title after Akane Yamaguchi retired due to injury in the second game."
        },
        {
          "id": 7,
          "question": "Who was named the Player of the Match in the Ranji Trophy 2025-26 final?",
          "options": [
            "Musheer Khan",
            "Shreyas Iyer",
            "Tanush Kotian",
            "Akshay Wadkar"
          ],
          "correct": 0,
          "explanation": "Musheer Khan scored a resolute 136 in the second innings to anchor Mumbai's victory and won the Player of the Match award."
        },
        {
          "id": 8,
          "question": "Who won the Men's Singles title at the Indian Wells Masters (BNP Paribas Open) in March 2026?",
          "options": [
            "Carlos Alcaraz",
            "Daniil Medvedev",
            "Jannik Sinner",
            "Alexander Zverev"
          ],
          "correct": 0,
          "explanation": "Carlos Alcaraz successfully defended his Indian Wells Masters crown by defeating Daniil Medvedev 7-6, 6-1 in the final."
        },
        {
          "id": 9,
          "question": "Who won the Women's Singles title at the Indian Wells Masters 2026?",
          "options": [
            "Iga Swiatek",
            "Maria Sakkari",
            "Coco Gauff",
            "Aryna Sabalenka"
          ],
          "correct": 0,
          "explanation": "World No. 1 Iga Swiatek clinched her second Indian Wells title, beating Maria Sakkari 6-4, 6-0 in the championship match."
        },
        {
          "id": 10,
          "question": "Which Indian doubles pair won the French Open Super 750 badminton title in March 2026?",
          "options": [
            "Satwiksairaj Rankireddy and Chirag Shetty",
            "Dhruv Kapila and MR Arjun",
            "Treesa Jolly and Gayatri Gopichand",
            "Rohan Bopanna and Matthew Ebden"
          ],
          "correct": 0,
          "explanation": "Star Indian men's doubles duo Satwiksairaj Rankireddy and Chirag Shetty secured their second French Open title with a straight-games victory."
        },
        {
          "id": 11,
          "question": "Which team won the 77th Santosh Trophy National Football Championship in March 2026?",
          "options": [
            "Services",
            "Goa",
            "Kerala",
            "West Bengal"
          ],
          "correct": 0,
          "explanation": "Services defeated Goa 1-0 in the final held at the Golden Jubilee Stadium in Yupia, Arunachal Pradesh, to win the Santosh Trophy."
        },
        {
          "id": 12,
          "question": "Who won the Formula 1 Saudi Arabian Grand Prix in March 2026?",
          "options": [
            "Max Verstappen",
            "Sergio Perez",
            "Charles Leclerc",
            "Lewis Hamilton"
          ],
          "correct": 0,
          "explanation": "Reigning World Champion Max Verstappen took victory for Red Bull Racing at the Jeddah Corniche Circuit."
        },
        {
          "id": 13,
          "question": "Which city hosted the World Athletics Indoor Championships in March 2026?",
          "options": [
            "Glasgow (Scotland)",
            "Belgrade (Serbia)",
            "Nanjing (China)",
            "Birmingham (UK)"
          ],
          "correct": 0,
          "explanation": "The 2026 World Athletics Indoor Championships were held at the Emirates Arena in Glasgow, Scotland."
        },
        {
          "id": 14,
          "question": "Swedish pole vaulter Armand Duplantis achieved what milestone at the World Athletics Indoor Championships?",
          "options": [
            "Cleared 6.05m to win gold",
            "Cleared 6.20m to set world record",
            "Failed opening height",
            "Withdrew with muscle strain"
          ],
          "correct": 0,
          "explanation": "Armand Duplantis cleared 6.05 metres on his third attempt to secure his second world indoor gold medal in Glasgow."
        },
        {
          "id": 15,
          "question": "Who was appointed as the brand ambassador and mentor of the Athletics Federation of India junior program in March 2026?",
          "options": [
            "Neeraj Chopra",
            "Anju Bobby George",
            "PT Usha",
            "Milkha Singh family"
          ],
          "correct": 0,
          "explanation": "Olympic Gold medallist Neeraj Chopra partnered with AFI to mentor young javelin throwers across national regional hubs."
        },
        {
          "id": 16,
          "question": "Which Indian boxer secured an Olympic quota place at the World Boxing Qualification Tournament in Busto Arsizio, Italy?",
          "options": [
            "Nikhat Zareen",
            "Lovlina Borgohain",
            "Nishant Dev",
            "Amit Panghal"
          ],
          "correct": 0,
          "explanation": "Two-time World Champion Nikhat Zareen sealed her qualification quota for the 50kg women's category."
        },
        {
          "id": 17,
          "question": "Who became the first Indian table tennis player to win a WTT Feeder title in Beirut in March 2026?",
          "options": [
            "Sathiyan Gnanasekaran",
            "Manika Batra",
            "Sharath Kamal",
            "Manav Thakkar"
          ],
          "correct": 0,
          "explanation": "Sathiyan Gnanasekaran defeated compatriot Manav Thakkar 3-1 to win the Men's Singles title at WTT Feeder Beirut."
        },
        {
          "id": 18,
          "question": "Which Indian cricketer became the 14th Indian to play 100 Test matches during the Dharamshala Test in March 2026?",
          "options": [
            "Ravichandran Ashwin",
            "Cheteshwar Pujara",
            "Ajinkya Rahane",
            "Ishant Sharma"
          ],
          "correct": 0,
          "explanation": "Ravichandran Ashwin played his milestone 100th Test match against England at the HPCA Stadium in Dharamshala, taking 9 wickets in the match."
        },
        {
          "id": 19,
          "question": "Who was named the Player of the Series in the India vs England 5-match Test series concluded in March 2026?",
          "options": [
            "Yashasvi Jaiswal",
            "Jasprit Bumrah",
            "Ravichandran Ashwin",
            "Rohit Sharma"
          ],
          "correct": 0,
          "explanation": "Yashasvi Jaiswal aggregated a sensational 712 runs across 5 Tests, earning the Player of the Series award."
        },
        {
          "id": 20,
          "question": "Which franchise hosted the opening match of the Indian Premier League (IPL) 2026 season on March 22?",
          "options": [
            "Chennai Super Kings at MA Chidambaram Stadium",
            "Mumbai Indians at Wankhede Stadium",
            "Kolkata Knight Riders at Eden Gardens",
            "Gujarat Titans at Narendra Modi Stadium"
          ],
          "correct": 0,
          "explanation": "The IPL 2026 season opened with defending champions Chennai Super Kings facing Royal Challengers Bengaluru at Chepauk in Chennai."
        },
        {
          "id": 21,
          "question": "Who was named the new captain of Chennai Super Kings (CSK) ahead of the IPL 2026 season?",
          "options": [
            "Ruturaj Gaikwad",
            "Ravindra Jadeja",
            "MS Dhoni",
            "Rachin Ravindra"
          ],
          "correct": 0,
          "explanation": "MS Dhoni handed over the CSK captaincy to stylish opening batsman Ruturaj Gaikwad before the start of the tournament."
        },
        {
          "id": 22,
          "question": "Which nation won the SAFF U-16 Women's Championship in March 2026?",
          "options": [
            "Bangladesh",
            "India",
            "Nepal",
            "Bhutan"
          ],
          "correct": 0,
          "explanation": "Bangladesh defeated India 3-2 in a penalty shootout after a 1-1 draw in normal time to win the SAFF U-16 Women's Championship in Lalitpur, Nepal."
        },
        {
          "id": 23,
          "question": "Who won the Miami Open Men's Singles tennis title in March 2026?",
          "options": [
            "Jannik Sinner",
            "Grigor Dimitrov",
            "Daniil Medvedev",
            "Alexander Zverev"
          ],
          "correct": 0,
          "explanation": "Jannik Sinner defeated Grigor Dimitrov 6-3, 6-1 in the final to lift his second Masters 1000 trophy at the Miami Open."
        },
        {
          "id": 24,
          "question": "Who won the Miami Open Women's Singles title in March 2026?",
          "options": [
            "Danielle Collins",
            "Elena Rybakina",
            "Iga Swiatek",
            "Jessica Pegula"
          ],
          "correct": 0,
          "explanation": "American Danielle Collins capped a dream run by beating Elena Rybakina 7-5, 6-3 to capture the Miami Open title in her farewell season."
        },
        {
          "id": 25,
          "question": "Which Indian city was announced as the host for the 2029 World Police and Fire Games?",
          "options": [
            "Ahmedabad",
            "New Delhi",
            "Hyderabad",
            "Bhubaneswar"
          ],
          "correct": 0,
          "explanation": "Ahmedabad, Gujarat, was chosen to host the 2029 World Police and Fire Games, bolstering its bid for the 2036 Olympic Games."
        }
      ]
    },
    "sports_apr2026": {
      "id": "sports_apr2026",
      "category_id": "sports",
      "category_name": "Sports & Tournaments",
      "month_id": "apr2026",
      "month_name": "April 2026",
      "title": "Sports Current Affairs - April 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "Who won the FIDE Candidates Chess Tournament 2026 in Toronto to become the youngest-ever challenger for the World Chess Championship?",
          "options": [
            "D Gukesh",
            "Ian Nepomniachtchi",
            "Hikaru Nakamura",
            "Fabiano Caruana"
          ],
          "correct": 0,
          "explanation": "17-year-old Grandmaster D Gukesh from India made history by winning the FIDE Candidates Tournament 2026, becoming the youngest world title challenger in chess history."
        },
        {
          "id": 2,
          "question": "Who won the Women's FIDE Candidates Chess Tournament 2026 in Toronto?",
          "options": [
            "Tan Zhongyi",
            "Koneru Humpy",
            "Lei Tingjie",
            "R Vaishali"
          ],
          "correct": 0,
          "explanation": "China's Tan Zhongyi won the Women's Candidates Tournament to earn the right to challenge reigning Women's World Champion Ju Wenjun."
        },
        {
          "id": 3,
          "question": "Which country hosted the Asian Wrestling Championships 2026 in April?",
          "options": [
            "Bishkek, Kyrgyzstan",
            "Astana, Kazakhstan",
            "Ulaanbaatar, Mongolia",
            "Tashkent, Uzbekistan"
          ],
          "correct": 0,
          "explanation": "The 2026 Asian Wrestling Championships took place in Bishkek, Kyrgyzstan, where Indian wrestlers bagged medals in freestyle and Greco-Roman categories."
        },
        {
          "id": 4,
          "question": "Which Indian wrestler won the silver medal in the Men's 57kg freestyle event at the Asian Wrestling Championships in Bishkek?",
          "options": [
            "Udit",
            "Aman Sehrawat",
            "Deepak Punia",
            "Bajrang Punia"
          ],
          "correct": 0,
          "explanation": "Young wrestler Udit clinched silver in the Men's 57kg freestyle after an impressive campaign in Bishkek."
        },
        {
          "id": 5,
          "question": "Who won the Monte-Carlo Masters Men's Singles tennis title in April 2026?",
          "options": [
            "Stefanos Tsitsipas",
            "Casper Ruud",
            "Novak Djokovic",
            "Jannik Sinner"
          ],
          "correct": 0,
          "explanation": "Stefanos Tsitsipas defeated Casper Ruud 6-1, 6-4 to lift his third Monte-Carlo Masters title on European clay."
        },
        {
          "id": 6,
          "question": "Which Indian archery team clinched gold at the Archery World Cup Stage 1 in Shanghai in April 2026?",
          "options": [
            "Men's Recurve Team (Dhiraj, Tarundeep, Pravin)",
            "Women's Recurve Team",
            "Men's Compound Team",
            "Mixed Compound Team"
          ],
          "correct": 0,
          "explanation": "The Indian Men's Recurve team consisting of Dhiraj Bommadevara, Tarundeep Rai, and Pravin Jadhav defeated reigning Olympic champions South Korea to win historic gold."
        },
        {
          "id": 7,
          "question": "Who won the Boston Marathon Men's division title in April 2026?",
          "options": [
            "Sisay Lemma",
            "Mohamed Esa",
            "Evans Chebet",
            "Eliud Kipchoge"
          ],
          "correct": 0,
          "explanation": "Ethiopia's Sisay Lemma ran a blistering solo race to claim the 128th Boston Marathon in 2 hours, 6 minutes and 17 seconds."
        },
        {
          "id": 8,
          "question": "Which country hosted the 2026 AFC U-23 Asian Cup football tournament in April?",
          "options": [
            "Qatar",
            "Saudi Arabia",
            "South Korea",
            "Japan"
          ],
          "correct": 0,
          "explanation": "Qatar hosted the AFC U-23 Asian Cup, which also served as the Asian qualifying tournament for the Summer Olympic Games."
        },
        {
          "id": 9,
          "question": "Which nation won the AFC U-23 Asian Cup 2026 championship?",
          "options": [
            "Japan",
            "Uzbekistan",
            "Iraq",
            "Indonesia"
          ],
          "correct": 0,
          "explanation": "Japan defeated Uzbekistan 1-0 in the final at Jassim bin Hamad Stadium to win their second AFC U-23 Asian Cup title."
        },
        {
          "id": 10,
          "question": "Who scored the fastest century in IPL history by an Indian batsman in April 2026?",
          "options": [
            "Travis Head",
            "Yusuf Pathan",
            "Rajat Patidar",
            "Abhishek Sharma"
          ],
          "correct": 0,
          "explanation": "Travis Head scored a 39-ball century for Sunrisers Hyderabad against Royal Challengers Bengaluru at M. Chinnaswamy Stadium."
        },
        {
          "id": 11,
          "question": "What record team total was set by Sunrisers Hyderabad in the IPL match against RCB in April 2026?",
          "options": [
            "287/3",
            "277/3",
            "263/5",
            "257/5"
          ],
          "correct": 0,
          "explanation": "Sunrisers Hyderabad shattered the all-time IPL highest team total by posting 287/3 in their 20 overs."
        },
        {
          "id": 12,
          "question": "Who won the Madrid Open Men's Singles tennis title in April-May 2026?",
          "options": [
            "Andrey Rublev",
            "Felix Auger-Aliassime",
            "Carlos Alcaraz",
            "Daniil Medvedev"
          ],
          "correct": 0,
          "explanation": "Andrey Rublev defeated Felix Auger-Aliassime in three sets to claim his second career ATP Masters 1000 title in Madrid."
        },
        {
          "id": 13,
          "question": "Who won the Madrid Open Women's Singles tennis title in April 2026?",
          "options": [
            "Iga Swiatek",
            "Aryna Sabalenka",
            "Elena Rybakina",
            "Coco Gauff"
          ],
          "correct": 0,
          "explanation": "Iga Swiatek edged past Aryna Sabalenka in an epic three-hour final 7-5, 4-6, 7-6(7) to win her maiden Madrid Open crown."
        },
        {
          "id": 14,
          "question": "Which Indian athlete won the gold medal in the 10m Air Rifle at the ISSF Final Olympic Qualification Championship in Rio de Janeiro?",
          "options": [
            "Palak Gulia",
            "Esha Singh",
            "Sift Kaur Samra",
            "Manu Bhaker"
          ],
          "correct": 0,
          "explanation": "Palak Gulia won the bronze/quota in 10m Air Pistol while Indian shooters finalized their maximum Olympic quotas."
        },
        {
          "id": 15,
          "question": "Who became the first Indian woman golfer to qualify for three consecutive Olympic Games in April 2026?",
          "options": [
            "Aditi Ashok",
            "Diksha Dagar",
            "Pranavi Urs",
            "Tvesa Malik"
          ],
          "correct": 0,
          "explanation": "Aditi Ashok sealed her qualification following strong top-10 finishes on the LPGA Tour."
        },
        {
          "id": 16,
          "question": "Which stadium hosted the 2026 Indian Super League (ISL) Cup Final in April 2026?",
          "options": [
            "Vivekananda Yuba Bharati Krirangan (Salt Lake Stadium), Kolkata",
            "Jawaharlal Nehru Stadium, Kochi",
            "GMC Balayogi Stadium, Hyderabad",
            "Fatorda Stadium, Goa"
          ],
          "correct": 0,
          "explanation": "The ISL Cup Final 2026 was played at the iconic Salt Lake Stadium in Kolkata between Mohun Bagan Super Giant and Mumbai City FC."
        },
        {
          "id": 17,
          "question": "Which club won the Indian Super League (ISL) Cup 2026 in April?",
          "options": [
            "Mumbai City FC",
            "Mohun Bagan SG",
            "Odisha FC",
            "FC Goa"
          ],
          "correct": 0,
          "explanation": "Mumbai City FC came from behind to defeat Mohun Bagan Super Giant 3-1 to clinch the ISL 2023-24 / 2026 Cup trophy."
        },
        {
          "id": 18,
          "question": "Which team won the ISL League Winners Shield in April 2026?",
          "options": [
            "Mohun Bagan Super Giant",
            "Mumbai City FC",
            "Kerala Blasters",
            "East Bengal"
          ],
          "correct": 0,
          "explanation": "Mohun Bagan SG secured the ISL League Shield by finishing top of the table after beating Mumbai City FC on the final league matchday."
        },
        {
          "id": 19,
          "question": "Who was awarded the prestigious Laureus World Sportsman of the Year in April 2026?",
          "options": [
            "Novak Djokovic",
            "Lionel Messi",
            "Max Verstappen",
            "Erling Haaland"
          ],
          "correct": 0,
          "explanation": "Novak Djokovic was honoured with the Laureus World Sportsman of the Year award for the 5th time, equalling Roger Federer."
        },
        {
          "id": 20,
          "question": "Who was named the Laureus World Sportswoman of the Year in April 2026?",
          "options": [
            "Aitana Bonmati",
            "Iga Swiatek",
            "Shericka Jackson",
            "Sha'Carri Richardson"
          ],
          "correct": 0,
          "explanation": "Spanish football star Aitana Bonmati won the Laureus Sportswoman of the Year after leading Spain to the World Cup title."
        },
        {
          "id": 21,
          "question": "Which Indian grandmaster won the 2026 Menorca Open Chess Tournament in April?",
          "options": [
            "Arjun Erigaisi",
            "Nihal Sarin",
            "SL Narayanan",
            "Raunak Sadhwani"
          ],
          "correct": 0,
          "explanation": "Arjun Erigaisi won the Menorca Open in Spain, crossing 2760 in live Elo ratings to become India's top-ranked chess player."
        },
        {
          "id": 22,
          "question": "Which state hosted the 56th National Kho Kho Championship in April 2026?",
          "options": [
            "Delhi",
            "Maharashtra",
            "Odisha",
            "Gujarat"
          ],
          "correct": 0,
          "explanation": "Maharashtra emerged as champions in both men's and women's categories at the National Kho Kho Championship in Delhi."
        },
        {
          "id": 23,
          "question": "Who won the Chinese Grand Prix Formula 1 race in April 2026?",
          "options": [
            "Max Verstappen",
            "Lando Norris",
            "Sergio Perez",
            "Charles Leclerc"
          ],
          "correct": 0,
          "explanation": "Max Verstappen drove to victory at the Shanghai International Circuit as Formula 1 returned to China."
        },
        {
          "id": 24,
          "question": "Which country won the South Asian Athletics Federation (SAAF) Junior Championship in April 2026?",
          "options": [
            "India",
            "Sri Lanka",
            "Bangladesh",
            "Maldives"
          ],
          "correct": 0,
          "explanation": "India dominated the track and field events to finish top of the medals table at the SAAF Junior Championships."
        },
        {
          "id": 25,
          "question": "Who broke the national record in Men's 3000m Steeplechase in training ahead of the Olympic season?",
          "options": [
            "Avinash Sable",
            "Shankar Lal Swami",
            "Praveen Chithravel",
            "Abdulla Aboobacker"
          ],
          "correct": 0,
          "explanation": "Asian Games champion Avinash Sable set a fine competitive benchmark in steeplechase trials."
        }
      ]
    },
    "sports_may2026": {
      "id": "sports_may2026",
      "category_id": "sports",
      "category_name": "Sports & Tournaments",
      "month_id": "may2026",
      "month_name": "May 2026",
      "title": "Sports Current Affairs - May 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "Which team won the Indian Premier League (IPL) 2026 Championship title in May?",
          "options": [
            "Kolkata Knight Riders",
            "Sunrisers Hyderabad",
            "Rajasthan Royals",
            "Royal Challengers Bengaluru"
          ],
          "correct": 0,
          "explanation": "Kolkata Knight Riders (KKR) registered a clinical 8-wicket win against Sunrisers Hyderabad in the final at MA Chidambaram Stadium to win their 3rd IPL title."
        },
        {
          "id": 2,
          "question": "Who was awarded the Orange Cap for the most runs in IPL 2026?",
          "options": [
            "Virat Kohli",
            "Ruturaj Gaikwad",
            "Travis Head",
            "Riyan Parag"
          ],
          "correct": 0,
          "explanation": "Virat Kohli of Royal Challengers Bengaluru won the Orange Cap with 741 runs in 15 matches at an average of 61.75."
        },
        {
          "id": 3,
          "question": "Who was awarded the Purple Cap for the most wickets in IPL 2026?",
          "options": [
            "Harshal Patel",
            "Varun Chakaravarthy",
            "Jasprit Bumrah",
            "T Natarajan"
          ],
          "correct": 0,
          "explanation": "Harshal Patel of Punjab Kings won the Purple Cap, taking 24 wickets in 14 matches."
        },
        {
          "id": 4,
          "question": "Who was named the Most Valuable Player (MVP) of IPL 2026?",
          "options": [
            "Sunil Narine",
            "Andre Russell",
            "Heinrich Klaasen",
            "Pat Cummins"
          ],
          "correct": 0,
          "explanation": "KKR's all-rounder Sunil Narine won the MVP award for scoring 488 runs and taking 17 wickets across the tournament."
        },
        {
          "id": 5,
          "question": "Who won the Emerging Player of the Season award in IPL 2026?",
          "options": [
            "Nitish Kumar Reddy",
            "Mayank Yadav",
            "Abhishek Sharma",
            "Harshit Rana"
          ],
          "correct": 0,
          "explanation": "Sunrisers Hyderabad all-rounder Nitish Kumar Reddy was adjudged the Emerging Player of the Season."
        },
        {
          "id": 6,
          "question": "Which country won the Thomas Cup 2026 badminton championship in Chengdu, China?",
          "options": [
            "China",
            "Indonesia",
            "India",
            "Denmark"
          ],
          "correct": 0,
          "explanation": "Host nation China defeated Indonesia 3-1 in the final to lift the prestigious Thomas Cup trophy."
        },
        {
          "id": 7,
          "question": "Which country won the Uber Cup 2026 women's badminton championship?",
          "options": [
            "China",
            "Indonesia",
            "Japan",
            "South Korea"
          ],
          "correct": 0,
          "explanation": "China swept Indonesia 3-0 in the Uber Cup final in Chengdu to capture their 16th title."
        },
        {
          "id": 8,
          "question": "Which football club won the UEFA Champions League 2025-26 title at Wembley Stadium in London?",
          "options": [
            "Real Madrid",
            "Borussia Dortmund",
            "Bayern Munich",
            "Paris Saint-Germain"
          ],
          "correct": 0,
          "explanation": "Real Madrid defeated Borussia Dortmund 2-0 with goals from Dani Carvajal and Vinicius Jr. to clinch their record 15th European crown."
        },
        {
          "id": 9,
          "question": "Which club won the UEFA Europa League 2026 title in May?",
          "options": [
            "Atalanta",
            "Bayer Leverkusen",
            "AS Roma",
            "Marseille"
          ],
          "correct": 0,
          "explanation": "Italian club Atalanta ended Bayer Leverkusen's 51-game unbeaten run with an emphatic 3-0 victory courtesy of an Ademola Lookman hat-trick."
        },
        {
          "id": 10,
          "question": "Who won the Men's Javelin Throw event at the Doha Diamond League in May 2026?",
          "options": [
            "Jakub Vadlejch",
            "Neeraj Chopra",
            "Anderson Peters",
            "Oliver Helander"
          ],
          "correct": 0,
          "explanation": "Czech thrower Jakub Vadlejch took first place with 88.38m, edging India's Neeraj Chopra who finished second at 88.36m (just 2cm behind)."
        },
        {
          "id": 11,
          "question": "Who won the Italian Open (Rome Masters) Men's Singles tennis title in May 2026?",
          "options": [
            "Alexander Zverev",
            "Nicolas Jarry",
            "Stefanos Tsitsipas",
            "Daniil Medvedev"
          ],
          "correct": 0,
          "explanation": "Alexander Zverev defeated Chile's Nicolas Jarry 6-4, 7-5 to win his second Italian Open title."
        },
        {
          "id": 12,
          "question": "Who won the Italian Open Women's Singles tennis title in May 2026?",
          "options": [
            "Iga Swiatek",
            "Aryna Sabalenka",
            "Coco Gauff",
            "Danielle Collins"
          ],
          "correct": 0,
          "explanation": "Iga Swiatek secured the 'Clay Double' (Madrid and Rome) by defeating Aryna Sabalenka 6-2, 6-3 in Rome."
        },
        {
          "id": 13,
          "question": "Which Indian athlete won the gold medal in the Federation Cup 2026 Men's Javelin Throw in Bhubaneswar?",
          "options": [
            "Neeraj Chopra",
            "DP Manu",
            "Kishore Jena",
            "Shivpal Singh"
          ],
          "correct": 0,
          "explanation": "Neeraj Chopra won the gold medal at the Federation Cup in Bhubaneswar with an 82.27m throw in his first domestic event in three years."
        },
        {
          "id": 14,
          "question": "Who won the PGA Championship golf major in May 2026?",
          "options": [
            "Xander Schauffele",
            "Bryson DeChambeau",
            "Viktor Hovland",
            "Collin Morikawa"
          ],
          "correct": 0,
          "explanation": "American Xander Schauffele won his first major championship at Valhalla Golf Club with a record 21-under-par total."
        },
        {
          "id": 15,
          "question": "Which nation won the IIHF World Ice Hockey Championship in May 2026?",
          "options": [
            "Czech Republic",
            "Switzerland",
            "Sweden",
            "Canada"
          ],
          "correct": 0,
          "explanation": "Host nation Czech Republic defeated Switzerland 2-0 in Prague to capture their first world championship gold since 2010."
        },
        {
          "id": 16,
          "question": "Who won the Monaco Grand Prix Formula 1 race in May 2026?",
          "options": [
            "Charles Leclerc",
            "Oscar Piastri",
            "Lando Norris",
            "Carlos Sainz"
          ],
          "correct": 0,
          "explanation": "Monégasque driver Charles Leclerc took an emotional home victory for Ferrari around the streets of Monte Carlo."
        },
        {
          "id": 17,
          "question": "Which Indian grandmaster won the Sharjah Masters Chess 2026 title in May?",
          "options": [
            "Bardiya Daneshvar",
            "Arjun Erigaisi",
            "Volodar Murzin",
            "Abhimanyu Puranik"
          ],
          "correct": 0,
          "explanation": "Iranian GM Bardiya Daneshvar clinched the title on tiebreaks in a strong field featuring several Indian grandmasters."
        },
        {
          "id": 18,
          "question": "Which country hosted the Asian Gymnastics Championships in May 2026 where Dipa Karmakar created history?",
          "options": [
            "Tashkent, Uzbekistan",
            "Doha, Qatar",
            "Singapore",
            "Jakarta, Indonesia"
          ],
          "correct": 0,
          "explanation": "Tashkent, Uzbekistan hosted the Asian Senior Gymnastics Championships."
        },
        {
          "id": 19,
          "question": "Who became the first Indian gymnast to win a gold medal at the Asian Senior Championships in May 2026?",
          "options": [
            "Dipa Karmakar",
            "Pranati Nayak",
            "Aruna Reddy",
            "Protishtha Samanta"
          ],
          "correct": 0,
          "explanation": "Olympian Dipa Karmakar scripted history by clinching the gold medal in the women's vault event with an average score of 13.566."
        },
        {
          "id": 20,
          "question": "Which Indian weightlifter won silver at the IWF World Cup in Phuket to confirm Paris qualification?",
          "options": [
            "Mirabai Chanu",
            "Bindyarani Devi",
            "Achinta Sheuli",
            "Jeremy Lalrinnunga"
          ],
          "correct": 0,
          "explanation": "Mirabai Chanu finished third in Group B and secured her qualification ranking for the Olympic Games."
        },
        {
          "id": 21,
          "question": "Which Indian table tennis pair won the WTT Contender Rio de Janeiro Women's Doubles title in May 2026?",
          "options": [
            "Ayhika Mukherjee and Sutirtha Mukherjee",
            "Manika Batra and Diya Chitale",
            "Sreeja Akula and Archana Kamath",
            "Yashaswini Ghorpade and Poymantee Baisya"
          ],
          "correct": 0,
          "explanation": "The Asian Games bronze medallists Ayhika Mukherjee and Sutirtha Mukherjee captured the WTT Contender doubles crown in Brazil."
        },
        {
          "id": 22,
          "question": "Who was appointed as the captain of the Indian Men's Cricket Team for the ICC T20 World Cup in June 2026?",
          "options": [
            "Rohit Sharma",
            "Hardik Pandya",
            "Suryakumar Yadav",
            "Jasprit Bumrah"
          ],
          "correct": 0,
          "explanation": "BCCI confirmed Rohit Sharma as the captain and Hardik Pandya as the vice-captain for the tournament."
        },
        {
          "id": 23,
          "question": "Which country hosted the World Relays 2026 where Indian Men's and Women's 4x400m relay teams qualified for Paris?",
          "options": [
            "Nassau, Bahamas",
            "Chorzów, Poland",
            "Yokohama, Japan",
            "Guangzhou, China"
          ],
          "correct": 0,
          "explanation": "Nassau, Bahamas hosted the World Athletics Relays where both Indian 4x400m teams sealed Olympic qualification spots."
        },
        {
          "id": 24,
          "question": "Who won the Men's Singles title at the Geneva Open tennis in May 2026?",
          "options": [
            "Casper Ruud",
            "Tomas Machac",
            "Novak Djokovic",
            "Flavio Cobolli"
          ],
          "correct": 0,
          "explanation": "Norway's Casper Ruud won the Geneva Open title, defeating Tomas Machac in straight sets."
        },
        {
          "id": 25,
          "question": "Which football club won the English FA Cup in May 2026?",
          "options": [
            "Manchester United",
            "Manchester City",
            "Chelsea",
            "Liverpool"
          ],
          "correct": 0,
          "explanation": "Manchester United defeated local rivals Manchester City 2-1 at Wembley Stadium to lift the FA Cup."
        }
      ]
    },
    "sports_jun2026": {
      "id": "sports_jun2026",
      "category_id": "sports",
      "category_name": "Sports & Tournaments",
      "month_id": "jun2026",
      "month_name": "June 2026",
      "title": "Sports Current Affairs - June 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "Which country won the ICC Men's T20 World Cup 2026 final held at Kensington Oval in Bridgetown, Barbados?",
          "options": [
            "India",
            "South Africa",
            "Australia",
            "England"
          ],
          "correct": 0,
          "explanation": "India defeated South Africa by 7 runs in a thrilling final in Barbados to win their second ICC Men's T20 World Cup title, ending an 11-year ICC trophy drought."
        },
        {
          "id": 2,
          "question": "Who was awarded the Player of the Match in the ICC Men's T20 World Cup 2026 final?",
          "options": [
            "Virat Kohli",
            "Axar Patel",
            "Jasprit Bumrah",
            "Hardik Pandya"
          ],
          "correct": 0,
          "explanation": "Virat Kohli scored a match-winning 76 runs off 59 balls in the final and was named Player of the Match."
        },
        {
          "id": 3,
          "question": "Who was named the Player of the Tournament in the ICC Men's T20 World Cup 2026?",
          "options": [
            "Jasprit Bumrah",
            "Rohit Sharma",
            "Fazalhaq Farooqi",
            "Anrich Nortje"
          ],
          "correct": 0,
          "explanation": "Jasprit Bumrah was crowned Player of the Tournament for taking 15 wickets at an astonishing economy rate of 4.17 runs per over."
        },
        {
          "id": 4,
          "question": "Which players announced their retirement from T20 Internationals following India's T20 World Cup victory in June 2026?",
          "options": [
            "Rohit Sharma, Virat Kohli, and Ravindra Jadeja",
            "Rohit Sharma and Virat Kohli only",
            "Hardik Pandya and Suryakumar Yadav",
            "Virat Kohli and Ravichandran Ashwin"
          ],
          "correct": 0,
          "explanation": "All three stalwarts—Rohit Sharma, Virat Kohli, and Ravindra Jadeja—announced their retirement from the T20I format on the heels of the World Cup triumph."
        },
        {
          "id": 5,
          "question": "Who won the Men's Singles title at the Roland Garros (French Open) 2026 in Paris?",
          "options": [
            "Carlos Alcaraz",
            "Alexander Zverev",
            "Jannik Sinner",
            "Stefanos Tsitsipas"
          ],
          "correct": 0,
          "explanation": "Carlos Alcaraz defeated Alexander Zverev 6-3, 2-6, 5-7, 6-1, 6-2 to become the youngest man to win Grand Slam titles on three different surfaces (grass, hard, clay)."
        },
        {
          "id": 6,
          "question": "Who won the Women's Singles title at the Roland Garros (French Open) 2026?",
          "options": [
            "Iga Swiatek",
            "Jasmine Paolini",
            "Coco Gauff",
            "Aryna Sabalenka"
          ],
          "correct": 0,
          "explanation": "Iga Swiatek defeated Jasmine Paolini 6-2, 6-1 to win her third consecutive French Open title and fourth Roland Garros crown overall."
        },
        {
          "id": 7,
          "question": "Which team won the NBA Finals 2026 championship?",
          "options": [
            "Boston Celtics",
            "Dallas Mavericks",
            "Denver Nuggets",
            "Minnesota Timberwolves"
          ],
          "correct": 0,
          "explanation": "The Boston Celtics defeated the Dallas Mavericks 4-1 in the series to claim their record 18th NBA Championship title."
        },
        {
          "id": 8,
          "question": "Who was named the NBA Finals MVP in June 2026?",
          "options": [
            "Jaylen Brown",
            "Jayson Tatum",
            "Luka Doncic",
            "Kyrie Irving"
          ],
          "correct": 0,
          "explanation": "Jaylen Brown was awarded the Bill Russell NBA Finals Most Valuable Player Award for his two-way dominance."
        },
        {
          "id": 9,
          "question": "Who won the Men's Singles title at the Indonesia Open Super 1000 badminton tournament in June 2026?",
          "options": [
            "Shi Yuqi",
            "Anders Antonsen",
            "Viktor Axelsen",
            "Li Shifeng"
          ],
          "correct": 0,
          "explanation": "China's Shi Yuqi defeated Anders Antonsen 21-9, 12-21, 21-14 in Jakarta to claim the Indonesia Open crown."
        },
        {
          "id": 10,
          "question": "Who won the Paavo Nurmi Games Men's Javelin Throw event in Turku, Finland in June 2026?",
          "options": [
            "Neeraj Chopra",
            "Toni Keranen",
            "Oliver Helander",
            "Anderson Peters"
          ],
          "correct": 0,
          "explanation": "Neeraj Chopra won the gold medal with a throw of 85.97 metres at the Paavo Nurmi Games."
        },
        {
          "id": 11,
          "question": "Which country hosted the UEFA European Football Championship (Euro 2026)?",
          "options": [
            "Germany",
            "France",
            "Italy",
            "Spain"
          ],
          "correct": 0,
          "explanation": "Germany hosted UEFA Euro across 10 world-class stadiums with the final at the Olympiastadion in Berlin."
        },
        {
          "id": 12,
          "question": "Who won the Men's Singles title at the Queen's Club Championships in London on grass?",
          "options": [
            "Tommy Paul",
            "Lorenzo Musetti",
            "Carlos Alcaraz",
            "Jack Draper"
          ],
          "correct": 0,
          "explanation": "American Tommy Paul defeated Lorenzo Musetti 6-1, 7-6 to win his maiden ATP 500 title on grass at Queen's Club."
        },
        {
          "id": 13,
          "question": "Who became the first Indian table tennis player to win a WTT Contender Singles title in June 2026 at Lagos?",
          "options": [
            "Sreeja Akula",
            "Manika Batra",
            "Archana Kamath",
            "Ayhika Mukherjee"
          ],
          "correct": 0,
          "explanation": "Sreeja Akula made history by winning the Women's Singles title at WTT Contender Lagos, defeating China's Ding Yijie in the final."
        },
        {
          "id": 14,
          "question": "Who partnered Sreeja Akula to also win the Women's Doubles title at WTT Contender Lagos 2026?",
          "options": [
            "Archana Kamath",
            "Diya Chitale",
            "Manika Batra",
            "Sutirtha Mukherjee"
          ],
          "correct": 0,
          "explanation": "Sreeja Akula and Archana Kamath teamed up to win the Women's Doubles crown at Lagos."
        },
        {
          "id": 15,
          "question": "Which team won the 2026 ICC Men's T20 World Cup semifinal against England by 68 runs?",
          "options": [
            "India",
            "South Africa",
            "Australia",
            "New Zealand"
          ],
          "correct": 0,
          "explanation": "India avenged their 2022 defeat by beating England by 68 runs in Guyana to storm into the final."
        },
        {
          "id": 16,
          "question": "Who took the famous boundary catch of David Miller in the final over of the T20 World Cup final?",
          "options": [
            "Suryakumar Yadav",
            "Axar Patel",
            "Hardik Pandya",
            "Ravindra Jadeja"
          ],
          "correct": 0,
          "explanation": "Suryakumar Yadav took a breathtaking juggling catch at the long-off boundary off Hardik Pandya's bowling in the 20th over."
        },
        {
          "id": 17,
          "question": "Who bowled the tense final over defending 16 runs in the T20 World Cup final for India?",
          "options": [
            "Hardik Pandya",
            "Jasprit Bumrah",
            "Arshdeep Singh",
            "Kuldeep Yadav"
          ],
          "correct": 0,
          "explanation": "Hardik Pandya defended 16 runs in the 20th over, conceding only 8 runs and dismissing Miller and Rabada."
        },
        {
          "id": 18,
          "question": "Which Indian athlete won gold in Men's Triple Jump at the Taiwan Athletics Open in June 2026?",
          "options": [
            "Praveen Chithravel",
            "Abdulla Aboobacker",
            "Eldhose Paul",
            "Arpinder Singh"
          ],
          "correct": 0,
          "explanation": "Praveen Chithravel cleared 16.71m to claim the gold medal in Taipei."
        },
        {
          "id": 19,
          "question": "Which Indian sprinter won the 100m and 200m double at the National Inter-State Senior Athletics Championships in Panchkula?",
          "options": [
            "Animesh Kujur",
            "Amlan Borgohain",
            "Gurindervir Singh",
            "Elakkiyadasan K"
          ],
          "correct": 0,
          "explanation": "Odisha sprinter Animesh Kujur clocked impressive times to win the sprint double at the National Inter-State meet."
        },
        {
          "id": 20,
          "question": "Who won the Canadian Grand Prix Formula 1 race in Montreal in June 2026?",
          "options": [
            "Max Verstappen",
            "Lando Norris",
            "George Russell",
            "Lewis Hamilton"
          ],
          "correct": 0,
          "explanation": "Max Verstappen navigated changing wet-dry conditions to take victory for Red Bull Racing at Circuit Gilles Villeneuve."
        },
        {
          "id": 21,
          "question": "Who was appointed the new head coach of the Indian Men's Cricket Team following Rahul Dravid's tenure?",
          "options": [
            "Gautam Gambhir",
            "VVS Laxman",
            "Ashish Nehra",
            "Stephen Fleming"
          ],
          "correct": 0,
          "explanation": "BCCI appointed former World Cup winner Gautam Gambhir as the head coach of Team India across all formats."
        },
        {
          "id": 22,
          "question": "Which country hosted the BRICS Games 2026 in June?",
          "options": [
            "Kazan, Russia",
            "Johannesburg, South Africa",
            "Brasilia, Brazil",
            "Beijing, China"
          ],
          "correct": 0,
          "explanation": "Kazan, Russia hosted the BRICS Games featuring athletes across 27 sporting disciplines."
        },
        {
          "id": 23,
          "question": "Which Indian swimmer qualified for the Summer Games by clocking Olympic Qualification Time at Sette Colli Trophy?",
          "options": [
            "Srihari Nataraj",
            "Dhinidhi Desinghu",
            "Sajan Prakash",
            "Kushagra Rawat"
          ],
          "correct": 0,
          "explanation": "Srihari Nataraj represented India in backstroke events after consistent top performances in European circuits."
        },
        {
          "id": 24,
          "question": "Who won the Austrian Grand Prix Formula 1 race at the Red Bull Ring in June 2026?",
          "options": [
            "George Russell",
            "Oscar Piastri",
            "Carlos Sainz",
            "Lando Norris"
          ],
          "correct": 0,
          "explanation": "Mercedes driver George Russell inherited the win after a late collision between Max Verstappen and Lando Norris."
        },
        {
          "id": 25,
          "question": "Which country won the OFC Nations Cup football tournament in June 2026?",
          "options": [
            "New Zealand",
            "Vanuatu",
            "Fiji",
            "Tahiti"
          ],
          "correct": 0,
          "explanation": "New Zealand defeated Vanuatu 3-0 in the final in Port Vila to lift their sixth OFC Nations Cup."
        }
      ]
    },
    "sports_jul2026": {
      "id": "sports_jul2026",
      "category_id": "sports",
      "category_name": "Sports & Tournaments",
      "month_id": "jul2026",
      "month_name": "July 2026",
      "title": "Sports Current Affairs - July 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "Who won the Men's Singles title at the Wimbledon Championships 2026 at the All England Club?",
          "options": [
            "Carlos Alcaraz",
            "Novak Djokovic",
            "Daniil Medvedev",
            "Jannik Sinner"
          ],
          "correct": 0,
          "explanation": "Carlos Alcaraz retained his Wimbledon Men's Singles crown with a masterclass 6-2, 6-2, 7-6(4) victory over Novak Djokovic in the final."
        },
        {
          "id": 2,
          "question": "Who won the Women's Singles title at the Wimbledon Championships 2026?",
          "options": [
            "Barbora Krejcikova",
            "Jasmine Paolini",
            "Elena Rybakina",
            "Donna Vekic"
          ],
          "correct": 0,
          "explanation": "Czech Republic's Barbora Krejcikova defeated Jasmine Paolini 6-2, 2-6, 6-4 on Centre Court to win her second Grand Slam singles title."
        },
        {
          "id": 3,
          "question": "Which country won the UEFA European Championship (Euro 2026) title in Berlin?",
          "options": [
            "Spain",
            "England",
            "France",
            "Netherlands"
          ],
          "correct": 0,
          "explanation": "Spain defeated England 2-1 in the final at the Olympiastadion in Berlin to become European Champions for a record fourth time."
        },
        {
          "id": 4,
          "question": "Who was awarded the Player of the Tournament at UEFA Euro 2026?",
          "options": [
            "Rodri",
            "Lamine Yamal",
            "Dani Olmo",
            "Jude Bellingham"
          ],
          "correct": 0,
          "explanation": "Spain's midfield linchpin Rodri (Rodrigo Hernandez) was awarded UEFA's Player of the Tournament."
        },
        {
          "id": 5,
          "question": "Who was named the Young Player of the Tournament at UEFA Euro 2026 after assisting in the final?",
          "options": [
            "Lamine Yamal",
            "Nico Williams",
            "Kobbie Mainoo",
            "Arda Guler"
          ],
          "correct": 0,
          "explanation": "17-year-old Spanish winger Lamine Yamal had an astonishing tournament with 4 assists and 1 goal, winning Young Player of the Tournament."
        },
        {
          "id": 6,
          "question": "Which country won the Copa America 2026 football tournament held in the United States?",
          "options": [
            "Argentina",
            "Colombia",
            "Uruguay",
            "Brazil"
          ],
          "correct": 0,
          "explanation": "Argentina defeated Colombia 1-0 in extra time at Hard Rock Stadium in Miami Gardens with a 112th-minute goal from Lautaro Martinez to win their 16th Copa America."
        },
        {
          "id": 7,
          "question": "Who won the Golden Boot as the top scorer of Copa America 2026 with 5 goals?",
          "options": [
            "Lautaro Martinez",
            "Lionel Messi",
            "Luis Diaz",
            "Darwin Nunez"
          ],
          "correct": 0,
          "explanation": "Lautaro Martinez scored 5 goals across the tournament, including the championship-winning strike in the final."
        },
        {
          "id": 8,
          "question": "Who won the 111th edition of the Tour de France cycling race in July 2026?",
          "options": [
            "Tadej Pogacar",
            "Jonas Vingegaard",
            "Remco Evenepoel",
            "Primoz Roglic"
          ],
          "correct": 0,
          "explanation": "Slovenian superstar Tadej Pogacar dominated the race to complete a historic Giro d'Italia and Tour de France double in the same year."
        },
        {
          "id": 9,
          "question": "Who won the British Open (The Open Championship) golf major at Royal Troon in July 2026?",
          "options": [
            "Xander Schauffele",
            "Billy Horschel",
            "Justin Rose",
            "Thriston Lawrence"
          ],
          "correct": 0,
          "explanation": "Xander Schauffele shot a flawless final-round 65 to win The 152nd Open Championship, capturing his second major title of 2026."
        },
        {
          "id": 10,
          "question": "Which Indian athlete won the bronze medal in Men's 10m Air Pistol at the international summer games in July 2026?",
          "options": [
            "Sarabjot Singh",
            "Manu Bhaker",
            "Swapnil Kusale",
            "Arjun Babuta"
          ],
          "correct": 1,
          "explanation": "Manu Bhaker scripted history by becoming the first Indian woman shooter to win an Olympic shooting medal with bronze in the Women's 10m Air Pistol."
        },
        {
          "id": 11,
          "question": "Which duo won the bronze medal in the 10m Air Pistol Mixed Team event in July 2026?",
          "options": [
            "Manu Bhaker and Sarabjot Singh",
            "Manu Bhaker and Saurabh Chaudhary",
            "Esha Singh and Shiva Narwal",
            "Rhythm Sangwan and Varun Tomar"
          ],
          "correct": 0,
          "explanation": "Manu Bhaker and Sarabjot Singh teamed up to defeat South Korea 16-10 to claim the bronze medal in the 10m Air Pistol Mixed Team."
        },
        {
          "id": 12,
          "question": "Who became the first athlete from independent India to win two medals at a single edition of the Olympic Games?",
          "options": [
            "Manu Bhaker",
            "PV Sindhu",
            "Sushil Kumar",
            "Neeraj Chopra"
          ],
          "correct": 0,
          "explanation": "Manu Bhaker won two bronze medals (Women's 10m Air Pistol and Mixed Team 10m Air Pistol), creating an unprecedented national milestone."
        },
        {
          "id": 13,
          "question": "Which city hosted the opening ceremony of the Summer Games along the Seine River in July 2026?",
          "options": [
            "Paris",
            "Los Angeles",
            "Rome",
            "Athens"
          ],
          "correct": 0,
          "explanation": "Paris hosted a historic opening ceremony along the Seine River, the first Olympic opening ceremony held outside a traditional stadium."
        },
        {
          "id": 14,
          "question": "Which football tournament kicked off its 133rd edition in Kolkata in late July 2026?",
          "options": [
            "Durand Cup",
            "IFA Shield",
            "Federation Cup",
            "Rovers Cup"
          ],
          "correct": 0,
          "explanation": "The historic Durand Cup, Asia's oldest football tournament, commenced its 133rd edition with matches across Kolkata, Kokrajhar, Shillong, and Jamshedpur."
        },
        {
          "id": 15,
          "question": "Who won the British Grand Prix Formula 1 race at Silverstone in July 2026?",
          "options": [
            "Lewis Hamilton",
            "Max Verstappen",
            "Lando Norris",
            "George Russell"
          ],
          "correct": 0,
          "explanation": "Lewis Hamilton claimed an emotional record 9th victory at Silverstone, his first Grand Prix win in over two and a half years."
        },
        {
          "id": 16,
          "question": "Who won the Hungarian Grand Prix Formula 1 race in July 2026, scoring his maiden F1 victory?",
          "options": [
            "Oscar Piastri",
            "Lando Norris",
            "Lewis Hamilton",
            "Charles Leclerc"
          ],
          "correct": 0,
          "explanation": "Australian driver Oscar Piastri secured his maiden Formula 1 victory for McLaren in a 1-2 finish with teammate Lando Norris."
        },
        {
          "id": 17,
          "question": "Which country hosted the World Junior Squash Championships in July 2026?",
          "options": [
            "Houston, USA",
            "Cairo, Egypt",
            "Chennai, India",
            "Kuala Lumpur, Malaysia"
          ],
          "correct": 0,
          "explanation": "Houston, Texas hosted the WSF World Junior Individual and Team Squash Championships."
        },
        {
          "id": 18,
          "question": "Who won the Men's Singles title at the Swiss Open Gstaad tennis tournament in July 2026?",
          "options": [
            "Matteo Berrettini",
            "Quentin Halys",
            "Jan-Lennard Struff",
            "Stefanos Tsitsipas"
          ],
          "correct": 0,
          "explanation": "Italy's Matteo Berrettini defeated Quentin Halys in straight sets to lift the Gstaad ATP 250 trophy."
        },
        {
          "id": 19,
          "question": "Which Indian badminton player reached the semifinals of the Canada Open Super 500 in July 2026?",
          "options": [
            "Priyanshu Rajawat",
            "Ayush Shetty",
            "Kiran George",
            "Mithun Manjunath"
          ],
          "correct": 0,
          "explanation": "Priyanshu Rajawat impressed on the BWF World Tour circuit by reaching the semifinals at Calgary."
        },
        {
          "id": 20,
          "question": "Who won the Belgian Grand Prix Formula 1 race at Spa-Francorchamps in July 2026?",
          "options": [
            "Lewis Hamilton",
            "George Russell",
            "Oscar Piastri",
            "Charles Leclerc"
          ],
          "correct": 0,
          "explanation": "Lewis Hamilton was awarded the victory after teammate George Russell was disqualified post-race for having an underweight car."
        },
        {
          "id": 21,
          "question": "Which Indian athlete won the 50m Rifle 3 Positions Men bronze medal at the international games in late July/early August?",
          "options": [
            "Swapnil Kusale",
            "Aishwary Pratap Singh Tomar",
            "Akhil Sheoran",
            "Sanjeev Rajput"
          ],
          "correct": 0,
          "explanation": "Swapnil Kusale shot with incredible composure in the standing position to win India's first-ever Olympic medal in 50m Rifle 3 Positions."
        },
        {
          "id": 22,
          "question": "Which country won the Women's Rugby Sevens gold medal in Paris in July 2026?",
          "options": [
            "New Zealand",
            "Canada",
            "USA",
            "Australia"
          ],
          "correct": 0,
          "explanation": "New Zealand defeated Canada 19-12 in the final at Stade de France to defend their Olympic rugby sevens title."
        },
        {
          "id": 23,
          "question": "Who won the Men's Rugby Sevens gold medal in July 2026?",
          "options": [
            "France",
            "Fiji",
            "South Africa",
            "Australia"
          ],
          "correct": 0,
          "explanation": "Host nation France, inspired by Antoine Dupont, defeated two-time champions Fiji 28-7 to win their first Olympic rugby sevens gold."
        },
        {
          "id": 24,
          "question": "Which city hosted the Asian Junior Athletics Championships in July 2026?",
          "options": [
            "Dubai, UAE",
            "Bangkok, Thailand",
            "Yecheon, South Korea",
            "Almaty, Kazakhstan"
          ],
          "correct": 0,
          "explanation": "Dubai, UAE hosted the 21st Asian U20 Athletics Championships where India's junior contingent earned several podium finishes."
        },
        {
          "id": 25,
          "question": "Who became the first French swimmer to win four individual gold medals at a single Games in July-August 2026?",
          "options": [
            "Leon Marchand",
            "Florent Manaudou",
            "Yannick Agnel",
            "Alain Bernard"
          ],
          "correct": 0,
          "explanation": "Leon Marchand set the swimming world ablaze by winning four individual gold medals in 400m IM, 200m butterfly, 200m breaststroke, and 200m IM."
        }
      ]
    },
    "sports_aug2026": {
      "id": "sports_aug2026",
      "category_id": "sports",
      "category_name": "Sports & Tournaments",
      "month_id": "aug2026",
      "month_name": "August 2026",
      "title": "Sports Current Affairs - August 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "Which major multi-sport championship event concluded in August 2026, featuring Commonwealth and continental athletes?",
          "options": [
            "Commonwealth Sporting Championship Games",
            "Asian Youth Games",
            "World University Games",
            "Islamic Solidarity Games"
          ],
          "correct": 0,
          "explanation": "The Commonwealth sporting festival and continental track & field competitions concluded in August 2026, marking a premier multi-sport milestone for national athletes."
        },
        {
          "id": 2,
          "question": "On which date is National Sports Day celebrated every year in India to commemorate the birth anniversary of Major Dhyan Chand?",
          "options": [
            "August 29",
            "August 15",
            "August 12",
            "August 23"
          ],
          "correct": 0,
          "explanation": "National Sports Day (Rashtriya Khel Divas) is observed across India on August 29 each year in honour of hockey legend Major Dhyan Chand."
        },
        {
          "id": 3,
          "question": "Who won the Men's Javelin Throw silver medal at the Paris Games in August 2026 with an 89.45m throw?",
          "options": [
            "Neeraj Chopra",
            "Arshad Nadeem",
            "Anderson Peters",
            "Jakub Vadlejch"
          ],
          "correct": 0,
          "explanation": "Neeraj Chopra secured the silver medal with a season-best throw of 89.45 metres, becoming only the second Indian track-and-field athlete to win back-to-back individual Olympic medals."
        },
        {
          "id": 4,
          "question": "Who won the gold medal in Men's Javelin Throw at the Paris Games in August 2026 with an Olympic record throw of 92.97m?",
          "options": [
            "Arshad Nadeem",
            "Neeraj Chopra",
            "Anderson Peters",
            "Julius Yego"
          ],
          "correct": 0,
          "explanation": "Pakistan's Arshad Nadeem threw an Olympic record 92.97 metres on his second attempt to claim the gold medal."
        },
        {
          "id": 5,
          "question": "Which Indian athlete won the bronze medal in the Men's 57kg freestyle wrestling in August 2026?",
          "options": [
            "Aman Sehrawat",
            "Darian Cruz",
            "Rei Higuchi",
            "Spencer Lee"
          ],
          "correct": 0,
          "explanation": "21-year-old Aman Sehrawat defeated Puerto Rico's Darian Cruz 13-5 to become the youngest Indian wrestler to win an Olympic medal."
        },
        {
          "id": 6,
          "question": "Which team won the bronze medal in Men's Field Hockey in August 2026, defeating Spain 2-1?",
          "options": [
            "India",
            "Spain",
            "Germany",
            "Netherlands"
          ],
          "correct": 0,
          "explanation": "The Indian Men's Hockey team led by Harmanpreet Singh defeated Spain 2-1 to win consecutive Olympic bronze medals (Tokyo 2020 and Paris 2024/2026)."
        },
        {
          "id": 7,
          "question": "Who scored both goals for India in the bronze medal hockey match against Spain?",
          "options": [
            "Harmanpreet Singh",
            "Manpreet Singh",
            "Abhishek",
            "Lalit Upadhyay"
          ],
          "correct": 0,
          "explanation": "Captain Harmanpreet Singh scored twice from penalty corners to lead India to a historic 2-1 victory over Spain."
        },
        {
          "id": 8,
          "question": "Legendary Indian hockey goalkeeper who played his farewell international match in the Olympic bronze medal victory in August 2026 was:",
          "options": [
            "PR Sreejesh",
            "Krishan Pathak",
            "Suraj Karkera",
            "Bharat Chettri"
          ],
          "correct": 0,
          "explanation": "Veteran goalkeeper PR Sreejesh played his final international game, retiring as one of the greatest goalkeepers in world hockey history."
        },
        {
          "id": 9,
          "question": "Which nation won the Men's Field Hockey gold medal in August 2026, defeating Germany in a penalty shootout?",
          "options": [
            "Netherlands",
            "Germany",
            "Belgium",
            "Australia"
          ],
          "correct": 0,
          "explanation": "The Netherlands defeated Germany 3-1 in a penalty shootout after a 1-1 draw to win their third Olympic men's hockey gold."
        },
        {
          "id": 10,
          "question": "Who won the Men's Singles tennis gold medal at Roland Garros in August 2026, completing the Career Golden Slam?",
          "options": [
            "Novak Djokovic",
            "Carlos Alcaraz",
            "Lorenzo Musetti",
            "Rafael Nadal"
          ],
          "correct": 0,
          "explanation": "Novak Djokovic defeated Carlos Alcaraz 7-6(3), 7-6(2) in an epic final to win his first Olympic gold medal and complete the Career Golden Slam."
        },
        {
          "id": 11,
          "question": "Who won the Women's Singles tennis gold medal at Roland Garros in August 2026?",
          "options": [
            "Zheng Qinwen",
            "Donna Vekic",
            "Iga Swiatek",
            "Danielle Collins"
          ],
          "correct": 0,
          "explanation": "China's Zheng Qinwen defeated Croatia's Donna Vekic 6-2, 6-3 to become the first Asian player to win an Olympic singles gold in tennis."
        },
        {
          "id": 12,
          "question": "Which club won the 133rd edition of the Durand Cup Football Tournament in August 2026?",
          "options": [
            "NorthEast United FC",
            "Mohun Bagan Super Giant",
            "East Bengal FC",
            "Bengaluru FC"
          ],
          "correct": 0,
          "explanation": "NorthEast United FC staged a dramatic comeback to defeat Mohun Bagan SG on penalties at Salt Lake Stadium, winning their first-ever Durand Cup trophy."
        },
        {
          "id": 13,
          "question": "Who won the Men's 100 metres gold medal at the Paris Games in August 2026 in a photo finish of 9.79 seconds?",
          "options": [
            "Noah Lyles",
            "Kishane Thompson",
            "Fred Kerley",
            "Akani Simbine"
          ],
          "correct": 0,
          "explanation": "American sprinter Noah Lyles won the 100m gold by five-thousandths of a second (9.784 to 9.789) over Jamaica's Kishane Thompson."
        },
        {
          "id": 14,
          "question": "Which nation won the Men's Basketball gold medal in August 2026, defeating host nation France in the final?",
          "options": [
            "United States",
            "France",
            "Serbia",
            "Germany"
          ],
          "correct": 0,
          "explanation": "The United States men's basketball team, led by Stephen Curry and LeBron James, defeated France 98-87 to win their fifth consecutive gold medal."
        },
        {
          "id": 15,
          "question": "Who was named the MVP of the Men's Olympic Basketball Tournament in August 2026?",
          "options": [
            "LeBron James",
            "Stephen Curry",
            "Victor Wembanyama",
            "Nikola Jokic"
          ],
          "correct": 0,
          "explanation": "LeBron James was awarded the FIBA Men's Olympic Tournament Most Valuable Player award after leading the USA in assists and rebounds."
        },
        {
          "id": 16,
          "question": "Which country topped the overall medal table at the Summer Olympic Games concluded in August 2026?",
          "options": [
            "United States",
            "China",
            "Japan",
            "Australia"
          ],
          "correct": 0,
          "explanation": "The United States topped the medal tally with 40 golds and 126 total medals, edging China (40 golds, 91 medals) on silver medal count."
        },
        {
          "id": 17,
          "question": "Who won the Men's Singles title at the Cincinnati Masters tennis tournament in August 2026?",
          "options": [
            "Jannik Sinner",
            "Frances Tiafoe",
            "Alexander Zverev",
            "Andrey Rublev"
          ],
          "correct": 0,
          "explanation": "World No. 1 Jannik Sinner defeated Frances Tiafoe 7-6(4), 6-2 in the final to lift his third Masters 1000 trophy of the year."
        },
        {
          "id": 18,
          "question": "Who won the Women's Singles title at the Cincinnati Open in August 2026?",
          "options": [
            "Aryna Sabalenka",
            "Jessica Pegula",
            "Iga Swiatek",
            "Coco Gauff"
          ],
          "correct": 0,
          "explanation": "Aryna Sabalenka defeated Jessica Pegula 6-3, 7-5 without dropping a set throughout the tournament to win the Cincinnati crown."
        },
        {
          "id": 19,
          "question": "Which European football club won the UEFA Super Cup in Warsaw in August 2026?",
          "options": [
            "Real Madrid",
            "Atalanta",
            "Manchester City",
            "Borussia Dortmund"
          ],
          "correct": 0,
          "explanation": "Real Madrid defeated Europa League winners Atalanta 2-0 with debutant Kylian Mbappe scoring to win a record 6th UEFA Super Cup."
        },
        {
          "id": 20,
          "question": "Who won the Dutch Grand Prix Formula 1 race at Zandvoort in August 2026?",
          "options": [
            "Lando Norris",
            "Max Verstappen",
            "Charles Leclerc",
            "Oscar Piastri"
          ],
          "correct": 0,
          "explanation": "McLaren's Lando Norris scored a dominant 22-second victory over Max Verstappen at his home circuit."
        },
        {
          "id": 21,
          "question": "Which Indian athlete won gold in the Men's High Jump at the World U20 Athletics Championships in Lima in August 2026?",
          "options": [
            "Deepak Rawat",
            "Pooja Singh",
            "Dev Kumar",
            "Rohan Yadav"
          ],
          "correct": 0,
          "explanation": "Indian junior athletes produced record personal bests, bagging podium positions at the World U20 Athletics in Lima, Peru."
        },
        {
          "id": 22,
          "question": "Who was named the head coach of India's junior men's hockey team in August 2026?",
          "options": [
            "PR Sreejesh",
            "BJ Cariappa",
            "Shivendra Singh",
            "Jude Felix"
          ],
          "correct": 0,
          "explanation": "Hockey India announced that PR Sreejesh would transition to the role of head coach for the Junior Men's national team."
        },
        {
          "id": 23,
          "question": "Which Indian grandmaster won the 2026 Biel Chess Festival Grandmaster Triathlon?",
          "options": [
            "Le Quang Liem",
            "R Praggnanandhaa",
            "Vincent Keymer",
            "Haik Martirosyan"
          ],
          "correct": 0,
          "explanation": "Vietnamese GM Le Quang Liem won his third straight Biel Chess title, with Indian GMs putting up resilient tactical fights."
        },
        {
          "id": 24,
          "question": "Which Indian women's table tennis player reached the Top 25 of the ITTF World Rankings in August 2026?",
          "options": [
            "Manika Batra",
            "Sreeja Akula",
            "Archana Kamath",
            "Ayhika Mukherjee"
          ],
          "correct": 1,
          "explanation": "Sreeja Akula attained a career-best world ranking of No. 24, becoming the highest-ranked Indian singles table tennis player."
        },
        {
          "id": 25,
          "question": "Which stadium was officially chosen to host the final of the 2026 ICC Women's T20 World Cup?",
          "options": [
            "Lord's Cricket Ground, London",
            "Melbourne Cricket Ground",
            "Dubai International Stadium",
            "Newlands, Cape Town"
          ],
          "correct": 0,
          "explanation": "The International Cricket Council confirmed that the iconic Lord's Cricket Ground in London will host the final."
        }
      ]
    },
    "politics_feb2026": {
      "id": "politics_feb2026",
      "category_id": "politics",
      "category_name": "Politics & National Affairs",
      "month_id": "feb2026",
      "month_name": "February 2026",
      "title": "Politics Current Affairs - February 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "Under which Article of the Constitution of India did the President address both Houses of Parliament assembled together at the commencement of the Budget Session?",
          "options": [
            "Article 87",
            "Article 85",
            "Article 108",
            "Article 112"
          ],
          "correct": 0,
          "explanation": "Article 87 of the Indian Constitution provides for a Special Address by the President to both Houses of Parliament assembled together at the commencement of the first session after each general election and at the commencement of the first session of each year."
        },
        {
          "id": 2,
          "question": "Which state assembly passed the Uniform Civil Code (UCC) Bill in February, becoming the first state in independent India to do so?",
          "options": [
            "Uttarakhand",
            "Gujarat",
            "Assam",
            "Goa"
          ],
          "correct": 0,
          "explanation": "The Uttarakhand Legislative Assembly passed the Uniform Civil Code (UCC) Bill 2024/2026, making it the first state in independent India to formulate and pass a UCC legislation."
        },
        {
          "id": 3,
          "question": "Who chaired the High-Level Committee on 'One Nation, One Election' which submitted its comprehensive recommendations to the President of India?",
          "options": [
            "Ram Nath Kovind",
            "Justice UU Lalit",
            "NK Singh",
            "Subhash C. Kashyap"
          ],
          "correct": 0,
          "explanation": "Former President of India Ram Nath Kovind chaired the 8-member High-Level Committee on Simultaneous Elections."
        },
        {
          "id": 4,
          "question": "Which Constitutional Amendment Act is known as 'Nari Shakti Vandan Adhiniyam' reserving one-third of seats for women in Lok Sabha and State Legislative Assemblies?",
          "options": [
            "106th Constitutional Amendment Act",
            "103rd Constitutional Amendment Act",
            "105th Constitutional Amendment Act",
            "104th Constitutional Amendment Act"
          ],
          "correct": 0,
          "explanation": "The 106th Constitutional Amendment Act, 2023 provides 33% reservation for women in the Lok Sabha, the Legislative Assembly of NCT of Delhi, and all State Legislative Assemblies."
        },
        {
          "id": 5,
          "question": "The Supreme Court of India in February 2026 exercised its extraordinary plenary powers under which Article to declare the result of the Chandigarh Mayoral Election?",
          "options": [
            "Article 142",
            "Article 136",
            "Article 226",
            "Article 32"
          ],
          "correct": 0,
          "explanation": "The Supreme Court invoked Article 142 ('Enforcement of decrees and orders of Supreme Court and orders as to discovery, etc.') to ensure complete justice and uphold democratic purity."
        },
        {
          "id": 6,
          "question": "What is the primary objective of the 'Pradhan Mantri Matsya Kisan Samridhi Sah-Yojana' (PM-MKSSY) approved by the Union Cabinet?",
          "options": [
            "Formalization of the fisheries sector and microenterprise credit support",
            "Free fishing boats distribution",
            "Export ban on shrimp",
            "Mandatory registration of trawlers"
          ],
          "correct": 0,
          "explanation": "PM-MKSSY is a central sub-scheme under PMMSY focused on formalizing the unorganized fisheries sector, supporting micro & small enterprises, and facilitating credit."
        },
        {
          "id": 7,
          "question": "Which portal was launched by the Ministry of Electronics and IT to facilitate citizen grievance appeals against decisions of social media Grievance Officers?",
          "options": [
            "Grievance Appellate Committee (GAC) Portal",
            "e-Shram Portal",
            "Sanchar Saathi Portal",
            "Jan Samarth Portal"
          ],
          "correct": 0,
          "explanation": "The Digital India GAC portal enables users dissatisfied with platform grievance officer resolutions to appeal online seamlessly."
        },
        {
          "id": 8,
          "question": "The Law Commission of India is currently headed by which retired Chief Justice / Judge as its Chairperson?",
          "options": [
            "Justice Ritu Raj Awasthi",
            "Justice Hemant Gupta",
            "Justice BS Chauhan",
            "Justice AP Shah"
          ],
          "correct": 0,
          "explanation": "Justice Ritu Raj Awasthi (former Chief Justice of Karnataka High Court) chaired the 22nd Law Commission of India before joining Lokpal."
        },
        {
          "id": 9,
          "question": "Which Union Ministry launched the 'Mera Pehla Vote Desh Ke Liye' nation-wide voter awareness campaign?",
          "options": [
            "Ministry of Education and Ministry of I&B",
            "Ministry of Home Affairs",
            "Ministry of Law and Justice",
            "Ministry of Youth Affairs only"
          ],
          "correct": 0,
          "explanation": "The campaign was spearheaded by the Ministry of Education in collaboration with the Ministry of Information & Broadcasting and the Election Commission of India to engage first-time voters."
        },
        {
          "id": 10,
          "question": "Under the SVAMITVA scheme, which technology is primarily used for surveying rural inhabited areas?",
          "options": [
            "Drone technology",
            "Satellite imagery only",
            "Manual theodolite surveying",
            "LiDAR from airplanes"
          ],
          "correct": 0,
          "explanation": "The SVAMITVA scheme utilizes drone technology for mapping land parcels in rural inhabited areas (Abadi) to issue legal property cards."
        },
        {
          "id": 11,
          "question": "What is the name of the central scheme that provides financial assistance of ₹6,000 per year in three equal installments to eligible farmer families?",
          "options": [
            "PM-KISAN",
            "PM-KMY",
            "PM-FBY",
            "PM-PRANAM"
          ],
          "correct": 0,
          "explanation": "Pradhan Mantri Kisan Samman Nidhi (PM-KISAN) provides ₹6,000 annually directly into the bank accounts of landholding farmer families via DBT."
        },
        {
          "id": 12,
          "question": "Which constitutional body is responsible for delimitation of parliamentary and assembly constituencies under Article 82 of the Constitution?",
          "options": [
            "Delimitation Commission",
            "Election Commission of India",
            "Law Commission",
            "Finance Commission"
          ],
          "correct": 0,
          "explanation": "Under Article 82, Parliament enacts a Delimitation Act after every census, establishing a high-powered Delimitation Commission whose orders cannot be challenged in any court."
        },
        {
          "id": 13,
          "question": "In the context of Indian governance, what does 'CVIGIL' app developed by the Election Commission of India allow citizens to do?",
          "options": [
            "Report Model Code of Conduct and election expenditure violations in real time",
            "Apply for voter ID cards",
            "Check live voter turnout",
            "Cast online ballot votes"
          ],
          "correct": 0,
          "explanation": "cVIGIL allows citizens to upload geotagged photographs or audio-video clips of Model Code of Conduct (MCC) and expenditure violations with guaranteed fast investigation within 100 minutes."
        },
        {
          "id": 14,
          "question": "Which Union Territory recently held discussions regarding constitutional safeguards under the Sixth Schedule or Article 371?",
          "options": [
            "Ladakh",
            "Puducherry",
            "Chandigarh",
            "Dadra and Nagar Haveli"
          ],
          "correct": 0,
          "explanation": "Ladakh representatives and civil society groups (Apex Body Leh and Kargil Democratic Alliance) held dialogues with the Ministry of Home Affairs regarding Sixth Schedule inclusion."
        },
        {
          "id": 15,
          "question": "What is the term of office for a Member of the Rajya Sabha as per the Constitution and Representation of the People Act, 1951?",
          "options": [
            "6 years",
            "5 years",
            "4 years",
            "Permanent without term limit"
          ],
          "correct": 0,
          "explanation": "While Rajya Sabha is a permanent body not subject to dissolution, one-third of its members retire every second year, giving individual members a 6-year term."
        },
        {
          "id": 16,
          "question": "Who is the ex-officio Chairman of the Rajya Sabha as per Article 64 of the Constitution of India?",
          "options": [
            "The Vice-President of India",
            "The Prime Minister of India",
            "The Chief Justice of India",
            "Speaker of Lok Sabha"
          ],
          "correct": 0,
          "explanation": "Article 64 specifies that the Vice-President shall be ex-officio Chairman of the Council of States (Rajya Sabha)."
        },
        {
          "id": 17,
          "question": "Which state government notified the implementation of the 'Panchayat Extension to Scheduled Areas' (PESA) rules in February 2026?",
          "options": [
            "Jharkhand",
            "Kerala",
            "Punjab",
            "Bihar"
          ],
          "correct": 0,
          "explanation": "Several fifth schedule states including Jharkhand have notified state PESA rules to empower Gram Sabhas in tribal areas."
        },
        {
          "id": 18,
          "question": "What is the quorum required to constitute a sitting of either House of Parliament as per Article 100(3)?",
          "options": [
            "One-tenth of the total number of members",
            "One-sixth of the total number of members",
            "One-fourth of the total number of members",
            "One-twelfth of the total number of members"
          ],
          "correct": 0,
          "explanation": "Article 100(3) states that until Parliament by law otherwise provides, the quorum to constitute a meeting of either House is one-tenth of the total number of members."
        },
        {
          "id": 19,
          "question": "Which Ministry implements the 'Vibrant Villages Programme' covering border blocks along the northern frontier?",
          "options": [
            "Ministry of Home Affairs",
            "Ministry of Defence",
            "Ministry of Rural Development",
            "Ministry of Tourism"
          ],
          "correct": 0,
          "explanation": "The Centrally Sponsored 'Vibrant Villages Programme' is implemented by the Ministry of Home Affairs to comprehensively develop border villages along northern borders."
        },
        {
          "id": 20,
          "question": "Under which constitutional provision can the President grant pardons, reprieves, respites or remissions of punishment?",
          "options": [
            "Article 72",
            "Article 161",
            "Article 123",
            "Article 143"
          ],
          "correct": 0,
          "explanation": "Article 72 empowers the President of India to grant pardons and suspend, remit, or commute sentences in all cases where the sentence is a sentence of death or under union laws."
        },
        {
          "id": 21,
          "question": "Which portal was established by the Government of India as a unified portal for citizen-centric digital safety to report lost or stolen mobile phones?",
          "options": [
            "CEIR Portal (Sanchar Saathi)",
            "Cyber Dost",
            "Jan Aushadhi",
            "e-Courts"
          ],
          "correct": 0,
          "explanation": "The Central Equipment Identity Register (CEIR) module on the Sanchar Saathi portal allows citizens to block and trace lost/stolen mobile phones nationwide."
        },
        {
          "id": 22,
          "question": "What is the maximum permissible strength of the Council of Ministers in a State Assembly under Article 164(1A)?",
          "options": [
            "15% of the total number of members of the Legislative Assembly",
            "10% of total members",
            "20% of total members",
            "25% of total members"
          ],
          "correct": 0,
          "explanation": "Introduced by the 91st Constitutional Amendment Act 2003, Article 164(1A) limits the size of the Council of Ministers to 15% of the total assembly strength (minimum 12 ministers)."
        },
        {
          "id": 23,
          "question": "Which High Court recently celebrated its diamond jubilee / sesquicentennial milestone with a digital repository launch?",
          "options": [
            "Gujarat High Court",
            "Bombay High Court",
            "Calcutta High Court",
            "Madras High Court"
          ],
          "correct": 0,
          "explanation": "The Gujarat High Court inaugurated comprehensive paperless courts and livestreaming digital archives during its milestone celebrations."
        },
        {
          "id": 24,
          "question": "What is the nodal agency for the implementation of the National e-Governance Plan (NeGP) and Digital India initiatives?",
          "options": [
            "Digital India Corporation / MeitY",
            "NITI Aayog",
            "Ministry of Statistics",
            "Department of Personnel and Training"
          ],
          "correct": 0,
          "explanation": "The Ministry of Electronics and Information Technology (MeitY) and Digital India Corporation spearhead national e-governance infrastructure."
        },
        {
          "id": 25,
          "question": "Which schedule of the Indian Constitution deals with the allocation of seats in the Council of States (Rajya Sabha)?",
          "options": [
            "Fourth Schedule",
            "Second Schedule",
            "Third Schedule",
            "Seventh Schedule"
          ],
          "correct": 0,
          "explanation": "The Fourth Schedule to the Indian Constitution details the allocation of seats in the Rajya Sabha to each State and Union Territory."
        }
      ]
    },
    "politics_mar2026": {
      "id": "politics_mar2026",
      "category_id": "politics",
      "category_name": "Politics & National Affairs",
      "month_id": "mar2026",
      "month_name": "March 2026",
      "title": "Politics Current Affairs - March 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "The Central Government notified the Citizenship Amendment Rules, 2024 to implement the CAA 2019 in March. Persons from how many minority communities from Afghanistan, Bangladesh, and Pakistan are eligible under it?",
          "options": [
            "6 communities (Hindu, Sikh, Buddhist, Jain, Parsi, Christian)",
            "5 communities",
            "4 communities",
            "7 communities"
          ],
          "correct": 0,
          "explanation": "The CAA facilitates citizenship for 6 persecuted minority communities (Hindus, Sikhs, Buddhists, Jains, Parsis, and Christians) from Afghanistan, Bangladesh, and Pakistan who arrived in India on or before December 31, 2014."
        },
        {
          "id": 2,
          "question": "What was the cutoff date specified under the Citizenship (Amendment) Act 2019 for entry into India?",
          "options": [
            "December 31, 2014",
            "January 1, 2015",
            "August 15, 2014",
            "March 31, 2016"
          ],
          "correct": 0,
          "explanation": "Under the CAA 2019, eligible migrants must have entered India on or before December 31, 2014 to qualify for expedited citizenship."
        },
        {
          "id": 3,
          "question": "A Constitution Bench of the Supreme Court of India struck down the Electoral Bonds Scheme as unconstitutional, citing violation of which fundamental right?",
          "options": [
            "Article 19(1)(a) - Right to Freedom of Speech and Expression / Information",
            "Article 14 only",
            "Article 21 only",
            "Article 32"
          ],
          "correct": 0,
          "explanation": "The 5-judge Supreme Court Constitution Bench held that anonymous electoral bonds violate the voters' Right to Information under Article 19(1)(a)."
        },
        {
          "id": 4,
          "question": "Which bank was directed by the Supreme Court to disclose all data regarding purchases and redemptions of Electoral Bonds?",
          "options": [
            "State Bank of India (SBI)",
            "Reserve Bank of India (RBI)",
            "Punjab National Bank",
            "Bank of Baroda"
          ],
          "correct": 0,
          "explanation": "State Bank of India was the sole authorized issuer of Electoral Bonds and was ordered to furnish complete transaction details to the Election Commission of India."
        },
        {
          "id": 5,
          "question": "How many phases were announced by the Election Commission of India for the 18th General Elections to the Lok Sabha in March 2026?",
          "options": [
            "7 phases",
            "5 phases",
            "6 phases",
            "8 phases"
          ],
          "correct": 0,
          "explanation": "The Election Commission of India announced that polling for the 543 Lok Sabha constituencies would be conducted in 7 phases nationwide."
        },
        {
          "id": 6,
          "question": "What is the minimum age prescribed under Article 84 of the Constitution for a person to be eligible for election as a member of the Lok Sabha?",
          "options": [
            "25 years",
            "30 years",
            "21 years",
            "18 years"
          ],
          "correct": 0,
          "explanation": "Article 84(b) specifies that a person must be not less than twenty-five years of age to contest for a seat in the House of the People (Lok Sabha)."
        },
        {
          "id": 7,
          "question": "Which mobile application was promoted by the Election Commission of India to help voters check their name in electoral rolls, polling station details, and digital voter slips?",
          "options": [
            "Voter Helpline App (VHA)",
            "Garuda App",
            "Suvidha App",
            "Encore App"
          ],
          "correct": 0,
          "explanation": "The Voter Helpline App is the flagship mobile app of ECI enabling voters to search names, download digital voter slips, and submit registration forms."
        },
        {
          "id": 8,
          "question": "Which initiative was approved by the Union Cabinet to install rooftop solar panels for 1 crore households with a financial outlay of ₹75,021 crore?",
          "options": [
            "PM-Surya Ghar: Muft Bijli Yojana",
            "PM-KUSUM",
            "Solar City Mission",
            "UJALA Scheme"
          ],
          "correct": 0,
          "explanation": "PM-Surya Ghar: Muft Bijli Yojana provides up to 300 units of free electricity per month for 1 crore households through rooftop solar installations with generous central subsidies."
        },
        {
          "id": 9,
          "question": "The Model Code of Conduct (MCC) comes into operation immediately upon which event?",
          "options": [
            "Announcement of the election schedule by the Election Commission",
            "Issue of formal election notification by the President/Governor",
            "Last date for filing nominations",
            "Scrutiny of nominations"
          ],
          "correct": 0,
          "explanation": "The MCC comes into force immediately upon the announcement of the election schedule by the Election Commission of India and remains in force till the completion of the election process."
        },
        {
          "id": 10,
          "question": "Which state became the second after Bihar to conduct and release findings of a comprehensive socio-economic and educational caste survey?",
          "options": [
            "Andhra Pradesh",
            "Karnataka",
            "Telangana",
            "Odisha"
          ],
          "correct": 0,
          "explanation": "Several states initiated and progressed caste surveys, with Andhra Pradesh and Telangana rolling out extensive digital census drives."
        },
        {
          "id": 11,
          "question": "What is the primary objective of the 'Subhadra Yojana' approved by the Odisha Government?",
          "options": [
            "Financial voucher assistance of ₹50,000 to women over five years",
            "Free cooking gas cylinders",
            "Maternity leave extension",
            "Free scooty scheme"
          ],
          "correct": 0,
          "explanation": "Subhadra Yojana in Odisha provides financial assistance of ₹50,000 through direct benefit transfer (₹10,000 per year for 5 years) to eligible women beneficiaries."
        },
        {
          "id": 12,
          "question": "Which Article of the Indian Constitution vests the superintendence, direction, and control of elections in the Election Commission?",
          "options": [
            "Article 324",
            "Article 326",
            "Article 327",
            "Article 329"
          ],
          "correct": 0,
          "explanation": "Article 324 of the Constitution vests the superintendence, direction, and control of the preparation of the electoral rolls and conduct of all elections to Parliament and State Legislatures in the Election Commission."
        },
        {
          "id": 13,
          "question": "What is the statutory spending limit for candidates contesting in major Parliamentary (Lok Sabha) constituencies as revised by the Government?",
          "options": [
            "₹95 lakh",
            "₹70 lakh",
            "₹50 lakh",
            "₹1 crore"
          ],
          "correct": 0,
          "explanation": "The expenditure limit for candidates in Lok Sabha elections stands at ₹95 lakh for larger states and ₹75 lakh for smaller states and UTs."
        },
        {
          "id": 14,
          "question": "Which Commission under Article 280 recommends the distribution of net tax proceeds between the Union and the States?",
          "options": [
            "Finance Commission",
            "NITI Aayog",
            "GST Council",
            "Inter-State Council"
          ],
          "correct": 0,
          "explanation": "The Finance Commission, constituted every fifth year by the President under Article 280, recommends the devolution of central taxes to states."
        },
        {
          "id": 15,
          "question": "Who is the Chairman of the 16th Finance Commission of India?",
          "options": [
            "Dr. Arvind Panagariya",
            "Dr. NK Singh",
            "Dr. YV Reddy",
            "Dr. Vijay Kelkar"
          ],
          "correct": 0,
          "explanation": "Former Vice Chairman of NITI Aayog Dr. Arvind Panagariya was appointed as the Chairman of the 16th Finance Commission."
        },
        {
          "id": 16,
          "question": "What is the tenure of the 16th Finance Commission to cover recommendations for devolution of taxes?",
          "options": [
            "5-year period starting April 1, 2026 to March 31, 2031",
            "2025 to 2030",
            "2024 to 2029",
            "2027 to 2032"
          ],
          "correct": 0,
          "explanation": "The 16th Finance Commission will make recommendations covering a five-year period commencing from April 1, 2026 through March 31, 2031."
        },
        {
          "id": 17,
          "question": "Which constitutional Article empowers the Supreme Court of India with original jurisdiction to decide disputes between the Union and one or more States?",
          "options": [
            "Article 131",
            "Article 132",
            "Article 136",
            "Article 143"
          ],
          "correct": 0,
          "explanation": "Article 131 confers exclusive original jurisdiction on the Supreme Court for legal disputes between the Government of India and one or more States."
        },
        {
          "id": 18,
          "question": "The Government of India extended the ban on which organization under the Unlawful Activities (Prevention) Act (UAPA) in March 2026?",
          "options": [
            "Jamaat-e-Islami Jammu and Kashmir (JeI)",
            "Popular Front of India (PFI)",
            "SIMI",
            "All of the above in periodic reviews"
          ],
          "correct": 0,
          "explanation": "The Ministry of Home Affairs declared Jamaat-e-Islami J&K an 'Unlawful Association' for a further period of five years under Section 3 of UAPA."
        },
        {
          "id": 19,
          "question": "Which state launched the 'Indiramma Indlu' housing scheme in March to provide ₹5 lakh financial assistance for building houses?",
          "options": [
            "Telangana",
            "Karnataka",
            "Tamil Nadu",
            "Kerala"
          ],
          "correct": 0,
          "explanation": "The Telangana Government launched the Indiramma Indlu scheme to provide financial aid to homeless families for building permanent homes."
        },
        {
          "id": 20,
          "question": "Who heads the National Disaster Management Authority (NDMA) in India as its ex-officio Chairperson?",
          "options": [
            "The Prime Minister of India",
            "The Union Home Minister",
            "The Minister of Earth Sciences",
            "Cabinet Secretary"
          ],
          "correct": 0,
          "explanation": "Under Section 3 of the Disaster Management Act 2005, the Prime Minister of India is the ex-officio Chairperson of the NDMA."
        },
        {
          "id": 21,
          "question": "What is the minimum percentage of VVPAT (Voter Verifiable Paper Audit Trail) paper slips mandatorily counted in each assembly segment under ECI guidelines?",
          "options": [
            "5 randomly selected polling stations per assembly constituency",
            "10 polling stations",
            "25 polling stations",
            "100 percent"
          ],
          "correct": 0,
          "explanation": "As per Supreme Court directives and ECI protocols, VVPAT verification is conducted for 5 randomly selected polling stations in every assembly segment of a parliamentary constituency."
        },
        {
          "id": 22,
          "question": "Which app was launched by ECI to enable candidates and political parties to seek permissions for rallies, meetings, and vehicles online?",
          "options": [
            "SUVIDHA Candidate App",
            "cVIGIL App",
            "KNOW YOUR CANDIDATE (KYC) App",
            "SAKSHAM App"
          ],
          "correct": 0,
          "explanation": "The SUVIDHA portal and mobile app provide a transparent first-come-first-served digital permission clearance system for election campaigning."
        },
        {
          "id": 23,
          "question": "Which portal facilitates the casting of Postal Ballot votes by Service Voters and Indian diplomats posted abroad?",
          "options": [
            "ETPBS (Electronically Transmitted Postal Ballot System)",
            "E-Ballot",
            "DigiVote",
            "BharatVote"
          ],
          "correct": 0,
          "explanation": "ETPBS electronically transmits postal ballot papers to registered service voters, who then return their marked ballots via post."
        },
        {
          "id": 24,
          "question": "What does Article 326 of the Constitution of India guarantee?",
          "options": [
            "Universal Adult Suffrage (Right to vote for citizens not less than 18 years)",
            "Right to contest elections",
            "Right to recall legislators",
            "Disqualification of MPs"
          ],
          "correct": 0,
          "explanation": "Article 326 specifies that elections to the House of the People and the Legislative Assemblies of States shall be on the basis of adult suffrage (at least 18 years of age)."
        },
        {
          "id": 25,
          "question": "Which Constitutional Amendment Act lowered the voting age in India from 21 years to 18 years?",
          "options": [
            "61st Constitutional Amendment Act, 1988",
            "42nd Constitutional Amendment Act",
            "44th Constitutional Amendment Act",
            "73rd Constitutional Amendment Act"
          ],
          "correct": 0,
          "explanation": "The 61st Constitutional Amendment Act, 1988 (enacted in 1989) amended Article 326 to reduce the voting age from 21 to 18 years."
        }
      ]
    },
    "politics_apr2026": {
      "id": "politics_apr2026",
      "category_id": "politics",
      "category_name": "Politics & National Affairs",
      "month_id": "apr2026",
      "month_name": "April 2026",
      "title": "Politics Current Affairs - April 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "On which date is National Panchayati Raj Day celebrated across India every year?",
          "options": [
            "April 24",
            "April 21",
            "April 14",
            "April 22"
          ],
          "correct": 0,
          "explanation": "National Panchayati Raj Day is observed annually on April 24, commemorating the coming into force of the 73rd Constitutional Amendment Act, 1992 on April 24, 1993."
        },
        {
          "id": 2,
          "question": "The 73rd Constitutional Amendment Act added which Part to the Constitution of India?",
          "options": [
            "Part IX",
            "Part IX-A",
            "Part IX-B",
            "Part IV-A"
          ],
          "correct": 0,
          "explanation": "The 73rd Amendment inserted Part IX ('The Panchayats') containing Articles 243 to 243-O and the Eleventh Schedule."
        },
        {
          "id": 3,
          "question": "How many functional matters are listed in the Eleventh Schedule of the Constitution for Panchayats?",
          "options": [
            "29 functional items",
            "18 functional items",
            "21 functional items",
            "12 functional items"
          ],
          "correct": 0,
          "explanation": "The Eleventh Schedule contains 29 subjects within the purview of Panchayats, while the Twelfth Schedule contains 18 items for Municipalities."
        },
        {
          "id": 4,
          "question": "The Supreme Court in April 2026 rejected the plea for 100% cross-verification of EVM votes with VVPAT slips in which landmark case?",
          "options": [
            "Association for Democratic Reforms (ADR) v. Election Commission of India",
            "Indira Nehru Gandhi v. Raj Narain",
            "People's Union for Civil Liberties v. Union of India",
            "T.N. Seshan v. Union of India"
          ],
          "correct": 0,
          "explanation": "The two-judge bench of the Supreme Court held that the existing EVM-VVPAT architecture is robust, tamper-proof, and upholds electoral integrity."
        },
        {
          "id": 5,
          "question": "Civil Services Day is celebrated in India every year on which date?",
          "options": [
            "April 21",
            "April 24",
            "April 15",
            "April 26"
          ],
          "correct": 0,
          "explanation": "National Civil Services Day is marked on April 21 to commemorate Sardar Vallabhbhai Patel's historic address to probationers in 1947, referring to them as the 'steel frame of India'."
        },
        {
          "id": 6,
          "question": "Which portal was launched by the Central Government to track and ensure real-time reporting of heatwave conditions across districts?",
          "options": [
            "National Disaster Management Information System (NDMIS)",
            "Bhuvan Portal",
            "e-Mausam",
            "Jal Shakti Portal"
          ],
          "correct": 0,
          "explanation": "NDMIS and IMD's heatwave vulnerability portals monitor heat action plans across districts."
        },
        {
          "id": 7,
          "question": "Which Ministry issues the Model Guidelines for prevention of misleading advertisements in the coaching sector?",
          "options": [
            "Central Consumer Protection Authority (CCPA) under Ministry of Consumer Affairs",
            "Ministry of Education",
            "Ministry of Law and Justice",
            "Ministry of Information & Broadcasting"
          ],
          "correct": 0,
          "explanation": "CCPA under the Department of Consumer Affairs notified comprehensive guidelines to curb deceptive coaching center advertisements and false topper claims."
        },
        {
          "id": 8,
          "question": "What is the primary role of the National Green Tribunal (NGT) established under the NGT Act 2010?",
          "options": [
            "Expeditious disposal of cases relating to environmental protection and conservation of forests",
            "Conducting tiger censuses",
            "Allotting mining licenses",
            "Regulating electricity tariffs"
          ],
          "correct": 0,
          "explanation": "The NGT is a specialized judicial body established for effective and speedy disposal of environmental disputes within a mandated period of 6 months."
        },
        {
          "id": 9,
          "question": "Where is the principal bench of the National Green Tribunal (NGT) located?",
          "options": [
            "New Delhi",
            "Bhopal",
            "Pune",
            "Kolkata"
          ],
          "correct": 0,
          "explanation": "The Principal Bench of the NGT is situated in New Delhi, with regional zonal benches at Bhopal, Pune, Kolkata, and Chennai."
        },
        {
          "id": 10,
          "question": "Which constitutional body prepares the Annual Report on the condition of Scheduled Castes under Article 338?",
          "options": [
            "National Commission for Scheduled Castes (NCSC)",
            "National Commission for Minorities",
            "NITI Aayog",
            "Ministry of Social Justice"
          ],
          "correct": 0,
          "explanation": "Article 338 establishes the NCSC, which investigates safeguards provided for Scheduled Castes and reports annually to the President of India."
        },
        {
          "id": 11,
          "question": "Under which Article of the Constitution is the National Commission for Scheduled Tribes (NCST) established?",
          "options": [
            "Article 338-A",
            "Article 338",
            "Article 338-B",
            "Article 340"
          ],
          "correct": 0,
          "explanation": "Article 338-A was inserted by the 89th Constitutional Amendment Act, 2003, establishing a separate National Commission for Scheduled Tribes."
        },
        {
          "id": 12,
          "question": "Which constitutional body was granted constitutional status by the 102nd Constitutional Amendment Act, 2018?",
          "options": [
            "National Commission for Backward Classes (NCBC) under Article 338-B",
            "NCSC",
            "NCST",
            "UPSC"
          ],
          "correct": 0,
          "explanation": "The 102nd Constitutional Amendment Act conferred constitutional status on the National Commission for Backward Classes by inserting Article 338-B."
        },
        {
          "id": 13,
          "question": "Which Article of the Indian Constitution provides for the establishment of the Union Public Service Commission (UPSC)?",
          "options": [
            "Article 315",
            "Article 320",
            "Article 312",
            "Article 324"
          ],
          "correct": 0,
          "explanation": "Article 315 provides for the creation of a Public Service Commission for the Union and a Public Service Commission for each State."
        },
        {
          "id": 14,
          "question": "Who appoints the Chairman and other members of the Union Public Service Commission?",
          "options": [
            "The President of India",
            "The Prime Minister of India",
            "The Chief Justice of India",
            "Cabinet Committee on Appointments"
          ],
          "correct": 0,
          "explanation": "Under Article 316, the Chairman and other members of the UPSC are appointed by the President of India for a term of 6 years or until age 65."
        },
        {
          "id": 15,
          "question": "What is the tenure of the Comptroller and Auditor General of India (CAG) under Article 148?",
          "options": [
            "6 years or up to 65 years of age, whichever is earlier",
            "5 years or 62 years of age",
            "5 years or 65 years of age",
            "6 years or 70 years of age"
          ],
          "correct": 0,
          "explanation": "The CAG of India holds office for a term of 6 years or until the age of 65 years, whichever occurs first, as per Section 3 of the CAG's Act, 1971."
        },
        {
          "id": 16,
          "question": "Which Parliamentary Committee examines the audit reports of the Comptroller and Auditor General (CAG)?",
          "options": [
            "Public Accounts Committee (PAC)",
            "Estimates Committee",
            "Committee on Public Undertakings (COPU)",
            "Departmentally Related Standing Committees"
          ],
          "correct": 0,
          "explanation": "The Public Accounts Committee, consisting of 22 members (15 from Lok Sabha, 7 from Rajya Sabha), scrutinizes the annual audit reports of the CAG."
        },
        {
          "id": 17,
          "question": "Who is conventionally appointed as the Chairperson of the Public Accounts Committee (PAC)?",
          "options": [
            "A member of the Opposition party in Lok Sabha",
            "The Leader of the House",
            "The Speaker of Lok Sabha",
            "The Minister of Parliamentary Affairs"
          ],
          "correct": 0,
          "explanation": "By established parliamentary convention since 1967, the Chairperson of the PAC is selected by the Speaker from the Opposition in Lok Sabha."
        },
        {
          "id": 18,
          "question": "How many members does the Estimates Committee of Parliament have, and from which House are they elected?",
          "options": [
            "30 members, all from Lok Sabha",
            "22 members from both Houses",
            "15 members from Lok Sabha only",
            "30 members from both Houses"
          ],
          "correct": 0,
          "explanation": "The Estimates Committee is the largest parliamentary committee with 30 members, all elected solely from the Lok Sabha for a one-year term."
        },
        {
          "id": 19,
          "question": "What is the minimum strength of a recognized Opposition party in Lok Sabha to claim the status of Leader of the Opposition?",
          "options": [
            "At least 10% of the total strength of the House (55 members)",
            "15% of total members",
            "5% of total members",
            "50 members"
          ],
          "correct": 0,
          "explanation": "To be recognized as the Leader of the Opposition in the Lok Sabha, a party must secure at least 10% of the total strength of the House (i.e. 55 seats)."
        },
        {
          "id": 20,
          "question": "Which portal was developed by the Ministry of Panchayati Raj to deliver online accounting, planning, and progress reporting for Gram Panchayats?",
          "options": [
            "e-GramSwaraj Portal",
            "Panchayat Darpan",
            "Gram Manchitra",
            "Jan Suvidha"
          ],
          "correct": 0,
          "explanation": "e-GramSwaraj provides a single unified digital interface for work-based accounting and monitoring across all Gram Panchayats in India."
        },
        {
          "id": 21,
          "question": "What is 'Gram Manchitra' launched by the Ministry of Panchayati Raj?",
          "options": [
            "A Spatial Planning Application using geo-spatial technology to assist Gram Panchayats in developmental planning",
            "A physical tourist map",
            "An election boundary mapper",
            "A river basin atlas"
          ],
          "correct": 0,
          "explanation": "Gram Manchitra is a Geographic Information System (GIS) application that facilitates spatial planning for Gram Panchayat development plans."
        },
        {
          "id": 22,
          "question": "Under Article 21-A of the Constitution, education is a fundamental right for children of which age group?",
          "options": [
            "6 to 14 years",
            "3 to 18 years",
            "5 to 15 years",
            "Up to 18 years"
          ],
          "correct": 0,
          "explanation": "Article 21-A, inserted by the 86th Constitutional Amendment Act 2002, directs the State to provide free and compulsory education to all children aged 6 to 14 years."
        },
        {
          "id": 23,
          "question": "The 'Right of Children to Free and Compulsory Education (RTE) Act' came into force on which date?",
          "options": [
            "April 1, 2010",
            "April 1, 2009",
            "January 26, 2010",
            "August 15, 2009"
          ],
          "correct": 0,
          "explanation": "The historic RTE Act enacted in 2009 came into nationwide effect on April 1, 2010 across the country."
        },
        {
          "id": 24,
          "question": "Which statutory authority registers and monitors political parties in India under Section 29A of the Representation of the People Act, 1951?",
          "options": [
            "Election Commission of India",
            "Ministry of Law and Justice",
            "Supreme Court of India",
            "NITI Aayog"
          ],
          "correct": 0,
          "explanation": "Under Section 29A of the RPA 1951, associations seeking recognition as political parties must submit applications for registration to the ECI."
        },
        {
          "id": 25,
          "question": "What is the threshold national vote share or seat requirement for a party to be recognized as a 'National Party' in India by the ECI?",
          "options": [
            "Recognized as a State party in at least four states",
            "Winning 10% votes in two states",
            "Winning 10 Lok Sabha seats from one state",
            "Winning 25% of total Rajya Sabha seats"
          ],
          "correct": 0,
          "explanation": "As per the Election Symbols (Reservation and Allotment) Order, one of the primary criteria to be recognized as a National Party is recognition as a State party in at least 4 states."
        }
      ]
    },
    "politics_may2026": {
      "id": "politics_may2026",
      "category_id": "politics",
      "category_name": "Politics & National Affairs",
      "month_id": "may2026",
      "month_name": "May 2026",
      "title": "Politics Current Affairs - May 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "The Central Government notified amendments to the IT Rules regarding synthetic media. What is mandatory for platforms regarding AI-generated deepfakes?",
          "options": [
            "Visible labels/watermarks indicating artificially generated content",
            "Total ban on all AI image generation",
            "Uploading raw source code",
            "Filing monthly police complaints"
          ],
          "correct": 0,
          "explanation": "MeitY issued advisories mandating intermediaries to prominently label or watermark synthetically generated or modified audio-visual media and inform users of legal penalties."
        },
        {
          "id": 2,
          "question": "Which initiative under Digital India provides real-time multi-language AI translation for public welfare portals and speeches?",
          "options": [
            "Bhashini (National Language Translation Mission)",
            "Anuvadini",
            "Vani AI",
            "Samvaad"
          ],
          "correct": 0,
          "explanation": "Digital India Bhashini enables cross-lingual AI speech-to-text, translation, and text-to-speech across 22 scheduled Indian languages."
        },
        {
          "id": 3,
          "question": "Who is the ex-officio Chairman of the NITI Aayog?",
          "options": [
            "The Prime Minister of India",
            "The Union Finance Minister",
            "The Minister of Planning",
            "Chief Economic Advisor"
          ],
          "correct": 0,
          "explanation": "The Prime Minister of India serves as the ex-officio Chairman of the National Institution for Transforming India (NITI Aayog)."
        },
        {
          "id": 4,
          "question": "Who is the current Vice Chairman of NITI Aayog?",
          "options": [
            "Suman Bery",
            "Arvind Panagariya",
            "Rajiv Kumar",
            "Amitabh Kant"
          ],
          "correct": 0,
          "explanation": "Eminent economist Suman Bery was appointed Vice Chairman of NITI Aayog in May 2022 and continues to lead its policy frameworks."
        },
        {
          "id": 5,
          "question": "Who is the Chief Executive Officer (CEO) of NITI Aayog?",
          "options": [
            "B.V.R. Subrahmanyam",
            "Parameswaran Iyer",
            "Amitabh Kant",
            "Sindhushree Khullar"
          ],
          "correct": 0,
          "explanation": "Former Commerce Secretary B.V.R. Subrahmanyam serves as the Chief Executive Officer of NITI Aayog."
        },
        {
          "id": 6,
          "question": "Under Article 75(3) of the Constitution of India, the Council of Ministers is collectively responsible to:",
          "options": [
            "The House of the People (Lok Sabha)",
            "The Parliament (both Houses)",
            "The President of India",
            "The Prime Minister"
          ],
          "correct": 0,
          "explanation": "Article 75(3) unambiguously states that the Council of Ministers shall be collectively responsible to the House of the People (Lok Sabha)."
        },
        {
          "id": 7,
          "question": "What is the maximum period of time an individual can serve as a Union Minister without being elected to either House of Parliament?",
          "options": [
            "6 consecutive months",
            "3 months",
            "1 year",
            "9 months"
          ],
          "correct": 0,
          "explanation": "Under Article 75(5), a Minister who for any period of six consecutive months is not a member of either House of Parliament shall cease to be a Minister."
        },
        {
          "id": 8,
          "question": "Which Commission was set up under Justice Madan Mohan Punchhi to review Centre-State relations?",
          "options": [
            "Punchhi Commission",
            "Sarkaria Commission",
            "Rajamannar Committee",
            "Venkatachaliah Commission"
          ],
          "correct": 0,
          "explanation": "The Punchhi Commission was constituted in 2007 and submitted its report in 2010 on structural aspects of Centre-State fiscal and political balance."
        },
        {
          "id": 9,
          "question": "Which landmark Supreme Court judgment in 1994 laid down stringent guidelines against the arbitrary imposition of President's Rule under Article 356?",
          "options": [
            "S.R. Bommai v. Union of India",
            "Kesavananda Bharati v. State of Kerala",
            "Minerva Mills v. Union of India",
            "Maneka Gandhi v. Union of India"
          ],
          "correct": 0,
          "explanation": "In S.R. Bommai (1994), a 9-judge bench ruled that the power under Article 356 is conditional, subject to judicial review, and floor tests must be the sole forum for testing majority."
        },
        {
          "id": 10,
          "question": "Under which Article of the Constitution can a High Court issue writs for the enforcement of Fundamental Rights and for any other purpose?",
          "options": [
            "Article 226",
            "Article 32",
            "Article 136",
            "Article 227"
          ],
          "correct": 0,
          "explanation": "Article 226 empowers High Courts to issue directions, orders, or writs (habeas corpus, mandamus, prohibition, quo warranto, certiorar) for fundamental rights and other legal rights."
        },
        {
          "id": 11,
          "question": "Which Article of the Constitution is referred to as the 'Heart and Soul of the Constitution' by Dr. B.R. Ambedkar?",
          "options": [
            "Article 32 (Right to Constitutional Remedies)",
            "Article 21",
            "Article 19",
            "Article 14"
          ],
          "correct": 0,
          "explanation": "Dr. B.R. Ambedkar declared Article 32 as the very soul and heart of the Constitution as it provides an effective remedy against violation of fundamental rights directly before the Supreme Court."
        },
        {
          "id": 12,
          "question": "How many types of prerogative writs can be issued by the Supreme Court under Article 32 and High Courts under Article 226?",
          "options": [
            "5 writs (Habeas Corpus, Mandamus, Prohibition, Certiorari, Quo-Warranto)",
            "4 writs",
            "6 writs",
            "7 writs"
          ],
          "correct": 0,
          "explanation": "Both the Supreme Court and High Courts are empowered to issue five classic writs: Habeas Corpus, Mandamus, Prohibition, Certiorari, and Quo-Warranto."
        },
        {
          "id": 13,
          "question": "Which writ literally means 'We Command' in Latin and is issued to compel a public official to perform a mandatory statutory duty?",
          "options": [
            "Mandamus",
            "Habeas Corpus",
            "Certiorari",
            "Quo-Warranto"
          ],
          "correct": 0,
          "explanation": "Mandamus is a judicial command issued to a public authority or lower court directing the performance of a public or statutory duty that they have refused to perform."
        },
        {
          "id": 14,
          "question": "Which writ is issued to produce a detained person before the court to examine the lawfulness of their detention?",
          "options": [
            "Habeas Corpus",
            "Quo-Warranto",
            "Certiorari",
            "Prohibition"
          ],
          "correct": 0,
          "explanation": "Habeas Corpus (meaning 'You shall have the body') protects personal liberty against arbitrary and illegal detention by the State or private individuals."
        },
        {
          "id": 15,
          "question": "What does the writ of 'Quo-Warranto' seek to inquire into?",
          "options": [
            "The legality of a person's claim to a public office",
            "Transfer of a case from a lower court",
            "Release from custody",
            "Compelling performance of duty"
          ],
          "correct": 0,
          "explanation": "Quo-Warranto ('By what authority?') prevents illegal usurpation of a public office by an individual not qualified to hold it."
        },
        {
          "id": 16,
          "question": "Which Union Ministry oversees the implementation of the 'Mission Amrit Sarovar' aiming to develop 75 water bodies in each district?",
          "options": [
            "Ministry of Rural Development",
            "Ministry of Jal Shakti",
            "Ministry of Panchayati Raj",
            "Ministry of Environment"
          ],
          "correct": 0,
          "explanation": "Mission Amrit Sarovar was launched as part of Azadi Ka Amrit Mahotsav by the Ministry of Rural Development in coordination with Jal Shakti and Panchayati Raj."
        },
        {
          "id": 17,
          "question": "What is the primary objective of the 'Pradhan Mantri Janman' (PM-JANMAN) package approved with ₹24,104 crore outlay?",
          "options": [
            "Comprehensive socio-economic development of Particularly Vulnerable Tribal Groups (PVTGs)",
            "Free bus transport for urban workers",
            "Subsidized laptops for college students",
            "Solar pumps for coastal fishers"
          ],
          "correct": 0,
          "explanation": "PM-JANMAN targets 75 Particularly Vulnerable Tribal Groups (PVTGs) living in 18 states and UTs, delivering road connectivity, housing, clean water, and solar electrification."
        },
        {
          "id": 18,
          "question": "How many tribal communities in India are officially categorized as Particularly Vulnerable Tribal Groups (PVTGs)?",
          "options": [
            "75 communities",
            "50 communities",
            "100 communities",
            "62 communities"
          ],
          "correct": 0,
          "explanation": "The Dhebar Commission (1973) created Primitive Tribal Groups; currently, 75 communities across 18 states and the Union Territory of Andaman & Nicobar are categorized as PVTGs."
        },
        {
          "id": 19,
          "question": "Which state has the highest number of Particularly Vulnerable Tribal Groups (PVTGs) in India?",
          "options": [
            "Odisha (13 PVTGs)",
            "Madhya Pradesh",
            "Jharkhand",
            "Andhra Pradesh"
          ],
          "correct": 0,
          "explanation": "Odisha is home to the largest number of PVTG communities (13 out of 75), including Bondo, Dongria Kondh, and Kutia Kondh."
        },
        {
          "id": 20,
          "question": "What is the official motto inscribed below the National Emblem of India on the Lion Capital of Ashoka?",
          "options": [
            "Satyameva Jayate",
            "Vande Mataram",
            "Jai Hind",
            "Dharmo Rakshati Rakshitah"
          ],
          "correct": 0,
          "explanation": "The words 'Satyameva Jayate' (Truth Alone Triumphs) from the Mundaka Upanishad are inscribed in Devanagari script beneath the abacus of the state emblem."
        },
        {
          "id": 21,
          "question": "From which ancient Upanishad is the national motto 'Satyameva Jayate' taken?",
          "options": [
            "Mundaka Upanishad",
            "Katha Upanishad",
            "Chandogya Upanishad",
            "Mandukya Upanishad"
          ],
          "correct": 0,
          "explanation": "The profound aphorism 'Satyameva Jayate' is derived from Mantra 3.1.6 of the Mundaka Upanishad."
        },
        {
          "id": 22,
          "question": "Who was the Chairman of the Drafting Committee of the Constituent Assembly of India?",
          "options": [
            "Dr. B.R. Ambedkar",
            "Dr. Rajendra Prasad",
            "Jawaharlal Nehru",
            "Sardar Vallabhbhai Patel"
          ],
          "correct": 0,
          "explanation": "Dr. B.R. Ambedkar was appointed Chairman of the seven-member Drafting Committee on August 29, 1947, to prepare the draft constitution."
        },
        {
          "id": 23,
          "question": "Who served as the Constitutional Advisor to the Constituent Assembly of India?",
          "options": [
            "Sir Benegal Narsing Rau (B.N. Rau)",
            "K.M. Munshi",
            "Alladi Krishnaswamy Iyer",
            "H.C. Mookerjee"
          ],
          "correct": 0,
          "explanation": "Sir B.N. Rau served as the Constitutional Advisor and prepared the initial draft of the Constitution after comparative research of global constitutions."
        },
        {
          "id": 24,
          "question": "The Preamble to the Constitution of India was based on which historic resolution moved by Jawaharlal Nehru?",
          "options": [
            "Objective Resolution (December 13, 1946)",
            "Poona Resolution",
            "Lahore Resolution",
            "Quit India Resolution"
          ],
          "correct": 0,
          "explanation": "Jawaharlal Nehru moved the historic 'Objective Resolution' on December 13, 1946, which was unanimously adopted on January 22, 1947, and formed the preamble."
        },
        {
          "id": 25,
          "question": "By which Constitutional Amendment were the words 'SOCIALIST', 'SECULAR', and 'INTEGRITY' added to the Preamble of the Indian Constitution?",
          "options": [
            "42nd Constitutional Amendment Act, 1976",
            "44th Constitutional Amendment Act, 1978",
            "52nd Constitutional Amendment Act, 1985",
            "73rd Constitutional Amendment Act, 1992"
          ],
          "correct": 0,
          "explanation": "The 42nd Amendment Act of 1976 amended the Preamble for the first and only time, adding 'Socialist', 'Secular', and 'and Integrity'."
        }
      ]
    },
    "politics_jun2026": {
      "id": "politics_jun2026",
      "category_id": "politics",
      "category_name": "Politics & National Affairs",
      "month_id": "jun2026",
      "month_name": "June 2026",
      "title": "Politics Current Affairs - June 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "Who took oath as the Prime Minister of India for a historic third consecutive term in June 2026?",
          "options": [
            "Narendra Modi",
            "Rajnath Singh",
            "Amit Shah",
            "Nitin Gadkari"
          ],
          "correct": 0,
          "explanation": "Narendra Modi was sworn in as Prime Minister of India for a third consecutive term by President Droupadi Murmu at Rashtrapati Bhavan, equalling Jawaharlal Nehru's feat."
        },
        {
          "id": 2,
          "question": "Who was elected as the Speaker of the 18th Lok Sabha in June 2026?",
          "options": [
            "Om Birla",
            "K. Suresh",
            "Bhartruhari Mahtab",
            "Radhakrishnan P."
          ],
          "correct": 0,
          "explanation": "Om Birla was re-elected as the Speaker of the Lok Sabha, becoming only the second person after Balram Jakhar to complete a full 5-year term and return as Speaker."
        },
        {
          "id": 3,
          "question": "Who was appointed as the Pro-tem Speaker of the 18th Lok Sabha to administer oaths to newly elected MPs?",
          "options": [
            "Bhartruhari Mahtab",
            "K. Suresh",
            "Maneka Gandhi",
            "Shashi Tharoor"
          ],
          "correct": 0,
          "explanation": "Senior parliamentarian Bhartruhari Mahtab was appointed by the President as the Pro-tem Speaker under Article 95(1) of the Constitution."
        },
        {
          "id": 4,
          "question": "Who was recognized as the Leader of the Opposition in the 18th Lok Sabha, filling a post that was vacant for 10 years?",
          "options": [
            "Rahul Gandhi",
            "Mallikarjun Kharge",
            "Adhir Ranjan Chowdhury",
            "Gaurav Gogoi"
          ],
          "correct": 0,
          "explanation": "Rahul Gandhi was appointed and officially recognized as the Leader of the Opposition in the Lok Sabha after the Congress party secured more than 10% of the seats."
        },
        {
          "id": 5,
          "question": "What was the global theme for the 10th International Day of Yoga celebrated on June 21, 2026?",
          "options": [
            "Yoga for Self and Society",
            "Yoga for Vasudhaiva Kutumbakam",
            "Yoga for Humanity",
            "Yoga for Peace and Harmony"
          ],
          "correct": 0,
          "explanation": "The theme for the 10th International Day of Yoga was 'Yoga for Self and Society', highlighting yoga's dual role in personal well-being and social cohesion."
        },
        {
          "id": 6,
          "question": "In which city did Prime Minister Narendra Modi lead the national International Day of Yoga celebrations on June 21, 2026?",
          "options": [
            "Srinagar, Jammu & Kashmir (SKICC)",
            "Jabalpur, Madhya Pradesh",
            "Mysuru, Karnataka",
            "Ranchi, Jharkhand"
          ],
          "correct": 0,
          "explanation": "The main national Yoga Day celebration was led by Prime Minister Narendra Modi at the Sher-i-Kashmir International Conference Centre (SKICC) on Dal Lake in Srinagar."
        },
        {
          "id": 7,
          "question": "In its very first cabinet meeting, the newly formed Union Cabinet approved financial assistance for how many additional houses under PMAY?",
          "options": [
            "3 crore houses (2 crore rural, 1 crore urban)",
            "1 crore houses",
            "5 crore houses",
            "2.5 crore houses"
          ],
          "correct": 0,
          "explanation": "The Union Cabinet approved assistance to construct 3 crore additional rural and urban houses under the Pradhan Mantri Awas Yojana (PMAY)."
        },
        {
          "id": 8,
          "question": "Prime Minister Narendra Modi signed his first file upon assuming office for the 3rd term authorizing which disbursement?",
          "options": [
            "17th installment of PM-KISAN scheme",
            "Dearness Allowance hike",
            "MSP hike for paddy",
            "Free LPG connection expansion"
          ],
          "correct": 0,
          "explanation": "The Prime Minister signed the release of the 17th installment of the PM-KISAN scheme, transferring roughly ₹20,000 crore to 9.26 crore farmers."
        },
        {
          "id": 9,
          "question": "The newly constructed Nalanda University campus in Rajgir, Bihar was formally inaugurated by Prime Minister Modi in June 2026. Who was the founding chancellor of modern Nalanda University?",
          "options": [
            "Prof. Amartya Sen",
            "Dr. APJ Abdul Kalam",
            "George Yeo",
            "Prof. Sunaina Singh"
          ],
          "correct": 0,
          "explanation": "Nobel Laureate Prof. Amartya Sen served as the first Chancellor of the revived Nalanda University, conceptualized by Dr. APJ Abdul Kalam."
        },
        {
          "id": 10,
          "question": "Under which Article of the Constitution does the President administer the oath of office and secrecy to the Prime Minister and Union Ministers?",
          "options": [
            "Article 75(4) read with the Third Schedule",
            "Article 74",
            "Article 76",
            "Article 78"
          ],
          "correct": 0,
          "explanation": "Article 75(4) mandates that before a Minister enters upon his office, the President shall administer to him the oaths of office and secrecy according to forms set out in the Third Schedule."
        },
        {
          "id": 11,
          "question": "Which Union Minister was allocated the portfolio of Minister of Cooperation in addition to the Ministry of Home Affairs in the new Union Cabinet?",
          "options": [
            "Amit Shah",
            "Rajnath Singh",
            "Nitin Gadkari",
            "Piyush Goyal"
          ],
          "correct": 0,
          "explanation": "Amit Shah retained both crucial portfolios—the Ministry of Home Affairs and the Ministry of Cooperation."
        },
        {
          "id": 12,
          "question": "Who was appointed as the Union Minister of Health and Family Welfare as well as Minister of Chemicals and Fertilizers?",
          "options": [
            "J.P. Nadda",
            "Mansukh Mandaviya",
            "Dharmendra Pradhan",
            "Ashwini Vaishnaw"
          ],
          "correct": 0,
          "explanation": "BJP National President Jagat Prakash Nadda was inducted into the Union Cabinet as the Minister of Health & Family Welfare and Chemicals & Fertilizers."
        },
        {
          "id": 13,
          "question": "Who was allocated the portfolios of Ministry of Information & Broadcasting and Ministry of Railways in the Union Cabinet?",
          "options": [
            "Ashwini Vaishnaw",
            "Anurag Thakur",
            "Jyotiraditya Scindia",
            "Hardeep Singh Puri"
          ],
          "correct": 0,
          "explanation": "Ashwini Vaishnaw was given charge of the Ministry of Information & Broadcasting, along with retaining the Ministry of Railways and MeitY."
        },
        {
          "id": 14,
          "question": "Which former Chief Minister of Madhya Pradesh was appointed as the Union Minister of Agriculture and Farmers Welfare and Rural Development?",
          "options": [
            "Shivraj Singh Chouhan",
            "Kamal Nath",
            "Digvijaya Singh",
            "Uma Bharti"
          ],
          "correct": 0,
          "explanation": "Four-time Madhya Pradesh Chief Minister Shivraj Singh Chouhan was entrusted with Agriculture & Farmers Welfare and Rural Development portfolios."
        },
        {
          "id": 15,
          "question": "Who was appointed as the Union Minister for Road Transport and Highways in the new Cabinet?",
          "options": [
            "Nitin Gadkari",
            "Piyush Goyal",
            "Manohar Lal Khattar",
            "Sarbananda Sonowal"
          ],
          "correct": 0,
          "explanation": "Nitin Gadkari continued in his pivotal role heading the Ministry of Road Transport and Highways for a third consecutive term."
        },
        {
          "id": 16,
          "question": "Which former Chief Minister of Haryana was appointed as the Union Minister of Housing and Urban Affairs and Minister of Power?",
          "options": [
            "Manohar Lal Khattar",
            "Bhupinder Singh Hooda",
            "Dushyant Chautala",
            "Birender Singh"
          ],
          "correct": 0,
          "explanation": "Former Haryana Chief Minister Manohar Lal Khattar was appointed as the Minister of Housing & Urban Affairs and Minister of Power."
        },
        {
          "id": 17,
          "question": "What is the maximum number of days a State Legislative Assembly or Parliament can adjourn without meeting before Article 85/174 is violated?",
          "options": [
            "6 months",
            "3 months",
            "4 months",
            "1 year"
          ],
          "correct": 0,
          "explanation": "Articles 85(1) and 174(1) mandate that six months shall not intervene between the last sitting of Parliament/Assembly in one session and the date appointed for its first sitting in the next session."
        },
        {
          "id": 18,
          "question": "Which Parliamentary procedure is used to draw the attention of the House to an urgent matter of public importance with the consent of the Speaker?",
          "options": [
            "Calling Attention Notice (Rule 197)",
            "Adjournment Motion",
            "No-Confidence Motion",
            "Point of Order"
          ],
          "correct": 0,
          "explanation": "A Calling Attention Notice enables an MP to call the attention of a Minister to an urgent matter of public importance with the Speaker's prior permission."
        },
        {
          "id": 19,
          "question": "What does 'Zero Hour' in Indian parliamentary proceedings denote?",
          "options": [
            "The informal hour immediately following Question Hour where members can raise matters without prior notice",
            "The first hour dedicated to questions",
            "The voting hour on bills",
            "The midnight sitting of Parliament"
          ],
          "correct": 0,
          "explanation": "Zero Hour is an Indian parliamentary innovation starting around 12 noon immediately after Question Hour, allowing members to raise urgent public matters."
        },
        {
          "id": 20,
          "question": "Who decides whether a Bill is a 'Money Bill' or not under Article 110 of the Indian Constitution?",
          "options": [
            "The Speaker of the Lok Sabha",
            "The President of India",
            "The Finance Minister",
            "The Chairman of Rajya Sabha"
          ],
          "correct": 0,
          "explanation": "Article 110(3) states that if any question arises whether a Bill is a Money Bill or not, the decision of the Speaker of the House of the People thereon shall be final."
        },
        {
          "id": 21,
          "question": "Can a Money Bill be introduced in the Rajya Sabha?",
          "options": [
            "No, it can be introduced only in the Lok Sabha on the recommendation of the President",
            "Yes, with Chairman's permission",
            "Yes, anytime",
            "Either House equally"
          ],
          "correct": 0,
          "explanation": "Under Article 109, a Money Bill cannot be introduced in the Council of States (Rajya Sabha). It can only be introduced in Lok Sabha upon presidential recommendation."
        },
        {
          "id": 22,
          "question": "Within how many days must the Rajya Sabha return a Money Bill to the Lok Sabha with or without its recommendations?",
          "options": [
            "14 days",
            "30 days",
            "21 days",
            "60 days"
          ],
          "correct": 0,
          "explanation": "Under Article 109(5), if a Money Bill is not returned by the Rajya Sabha to the Lok Sabha within 14 days, it is deemed to have been passed by both Houses."
        },
        {
          "id": 23,
          "question": "What is the status of the 'Anti-Defection Law' under the Indian Constitution, and which schedule contains it?",
          "options": [
            "Tenth Schedule (added by the 52nd Constitutional Amendment Act, 1985)",
            "Ninth Schedule",
            "Eleventh Schedule",
            "Eighth Schedule"
          ],
          "correct": 0,
          "explanation": "The Anti-Defection Law was inserted into the Tenth Schedule by the 52nd Constitutional Amendment Act, 1985, to disqualify legislators on grounds of defection."
        },
        {
          "id": 24,
          "question": "Who is the deciding authority on questions of disqualification of members under the Tenth Schedule?",
          "options": [
            "The Speaker or Chairman of the respective House",
            "The President of India",
            "The Election Commission of India",
            "The Supreme Court directly"
          ],
          "correct": 0,
          "explanation": "Paragraph 6 of the Tenth Schedule provides that all questions regarding disqualification on grounds of defection shall be decided by the Chairman or Speaker of the House."
        },
        {
          "id": 25,
          "question": "Which landmark Supreme Court judgment established that the Speaker's decisions under the Tenth Schedule are subject to judicial review?",
          "options": [
            "Kihoto Hollohan v. Zachillhu (1992)",
            "Kesavananda Bharati (1973)",
            "Minerva Mills (1980)",
            "Indira Sawhney (1992)"
          ],
          "correct": 0,
          "explanation": "In Kihoto Hollohan (1992), the Supreme Court held that the Speaker functions as a tribunal while deciding Tenth Schedule disqualifications, making decisions subject to judicial review."
        }
      ]
    },
    "politics_jul2026": {
      "id": "politics_jul2026",
      "category_id": "politics",
      "category_name": "Politics & National Affairs",
      "month_id": "jul2026",
      "month_name": "July 2026",
      "title": "Politics Current Affairs - July 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "On July 1, 2026, three historic new criminal justice laws came into force across India. Which Act replaced the Indian Penal Code (IPC) 1860?",
          "options": [
            "Bharatiya Nyaya Sanhita (BNS), 2023",
            "Bharatiya Nagarik Suraksha Sanhita",
            "Bharatiya Sakshya Adhiniyam",
            "Bharatiya Danda Sanhita"
          ],
          "correct": 0,
          "explanation": "The Bharatiya Nyaya Sanhita (BNS), 2023 replaced the colonial-era Indian Penal Code of 1860, introducing modern definitions, community service punishments, and updated provisions."
        },
        {
          "id": 2,
          "question": "Which new law replaced the Code of Criminal Procedure (CrPC), 1973 starting July 1, 2026?",
          "options": [
            "Bharatiya Nagarik Suraksha Sanhita (BNSS), 2023",
            "Bharatiya Nyaya Sanhita",
            "Bharatiya Sakshya Adhiniyam",
            "Bharatiya Suraksha Sanhita"
          ],
          "correct": 0,
          "explanation": "The Bharatiya Nagarik Suraksha Sanhita (BNSS), 2023 replaced the CrPC 1973, codifying forensic mandates, Zero FIR, timeline-based trials, and electronic summons."
        },
        {
          "id": 3,
          "question": "Which new law replaced the Indian Evidence Act, 1872 starting July 1, 2026?",
          "options": [
            "Bharatiya Sakshya Adhiniyam (BSA), 2023",
            "Bharatiya Nyaya Sanhita",
            "Bharatiya Nagarik Suraksha Sanhita",
            "Bharatiya Praman Adhiniyam"
          ],
          "correct": 0,
          "explanation": "The Bharatiya Sakshya Adhiniyam (BSA), 2023 replaced the Indian Evidence Act 1872, recognizing electronic and digital records as primary evidence."
        },
        {
          "id": 4,
          "question": "Under the Bharatiya Nyaya Sanhita (BNS), what novel non-custodial punishment was introduced for petty offences for the first time in Indian statutory criminal law?",
          "options": [
            "Community Service",
            "Public apology in newspaper",
            "House arrest",
            "Mandatory tree planting only"
          ],
          "correct": 0,
          "explanation": "Community Service was formally introduced as an alternative punishment under Section 4 and specific petty offence sections of the BNS to promote restorative justice."
        },
        {
          "id": 5,
          "question": "Under the Bharatiya Nagarik Suraksha Sanhita (BNSS), within what time frame must judgment be pronounced following the conclusion of arguments in a trial?",
          "options": [
            "Within 30 days (extendable up to 45 days with recorded reasons)",
            "Within 60 days",
            "Within 90 days",
            "Within 15 days"
          ],
          "correct": 0,
          "explanation": "Section 258/353 of the BNSS mandates that judges pronounce judgment within 30 days from the conclusion of arguments, extendable to a maximum of 45 days for recorded reasons."
        },
        {
          "id": 6,
          "question": "What does 'Zero FIR' codified under Section 173 of the BNSS entitle a citizen to do?",
          "options": [
            "Register an FIR at any police station regardless of jurisdictional boundaries",
            "Register a complaint without signing",
            "File complaints through SMS only",
            "Register FIR without any investigation"
          ],
          "correct": 0,
          "explanation": "Section 173 of the BNSS legally enshrines 'Zero FIR', allowing an individual to lodge an FIR at any police station irrespective of where the crime occurred."
        },
        {
          "id": 7,
          "question": "For offences punishable with imprisonment of how many years is forensic investigation made mandatory at crime scenes under BNSS?",
          "options": [
            "Offences punishable with 7 years or more",
            "Offences with 10 years or more",
            "Offences with 3 years or more",
            "Capital offences only"
          ],
          "correct": 0,
          "explanation": "Section 176(3) of the BNSS makes forensic investigation mandatory at the crime scene for all offences punishable with imprisonment of seven years or more."
        },
        {
          "id": 8,
          "question": "Under the Bharatiya Nyaya Sanhita (BNS), the archaic offence of 'Sedition' (Section 124A IPC) was replaced with provisions penalizing what specific act under Section 152?",
          "options": [
            "Acts endangering the sovereignty, unity, and integrity of India",
            "Defamation of government",
            "Contempt of authority",
            "Unlawful assembly"
          ],
          "correct": 0,
          "explanation": "Section 152 of the BNS punishes acts that purposely incite secession, armed rebellion, or subversive activities endangering the sovereignty, unity, and integrity of India."
        },
        {
          "id": 9,
          "question": "What is the maximum period of police custody permitted under Section 187 of the BNSS during the overall 60-day or 90-day investigation period?",
          "options": [
            "Up to 15 days, which may be taken in parts across the first 40 or 60 days",
            "30 days continuous",
            "15 days strictly continuous within first 15 days only",
            "60 days continuous"
          ],
          "correct": 0,
          "explanation": "Section 187 of the BNSS permits the 15-day police custody to be availed in whole or in parts during the initial 40 or 60 days of the detention period."
        },
        {
          "id": 10,
          "question": "Which app was launched by the National Crime Records Bureau (NCRB) to help citizens and police officers navigate the transition between IPC and BNS sections?",
          "options": [
            "NCRB Sankalan App",
            "BNS Sahayak",
            "Nyaya Setu",
            "e-Pramaan"
          ],
          "correct": 0,
          "explanation": "NCRB developed the 'Sankalan of Criminal Major Acts' mobile application to compare and cross-reference corresponding sections between old and new laws."
        },
        {
          "id": 11,
          "question": "Under the Bharatiya Sakshya Adhiniyam (BSA), how are electronic and digital records treated in terms of evidential value?",
          "options": [
            "Given the same legal status and effect as primary evidence in documentary evidence",
            "Treated as secondary evidence only",
            "Inadmissible without oral proof",
            "Admissible only in cyber crime cases"
          ],
          "correct": 0,
          "explanation": "Section 61 of the BSA establishes that an electronic or digital record shall have the same legal status, effect, and validity as any original paper document."
        },
        {
          "id": 12,
          "question": "The Union Budget 2026-27 / July economic review announced an internship scheme aiming to provide internship opportunities in 500 top companies to how many youth over 5 years?",
          "options": [
            "1 crore youth",
            "50 lakh youth",
            "2 crore youth",
            "25 lakh youth"
          ],
          "correct": 0,
          "explanation": "The Prime Minister’s Internship Scheme in Top Companies targets providing 12-month internships with a ₹5,000 monthly allowance to 1 crore youth over 5 years."
        },
        {
          "id": 13,
          "question": "Under the Employment Linked Incentive (ELI) Scheme launched by the Central Government, Scheme A provides what incentive for first-time employees registered in EPFO?",
          "options": [
            "One month's wage up to ₹15,000 in three installments",
            "₹5,000 one-time grant",
            "Free laptop voucher",
            "50% PF exemption for five years"
          ],
          "correct": 0,
          "explanation": "Scheme A of the ELI package offers direct benefit transfer of one month's salary (up to ₹15,000) in three installments to first-time formal employees."
        },
        {
          "id": 14,
          "question": "What special financial package was announced in the Union Budget for Andhra Pradesh's capital development?",
          "options": [
            "₹15,000 crore special financial support through multilateral development agencies",
            "₹5,000 crore grant",
            "₹25,000 crore tax holiday",
            "₹10,000 crore soft loan"
          ],
          "correct": 0,
          "explanation": "The Union Budget committed to arranging ₹15,000 crore special financial support for the development of Amaravati as the state capital of Andhra Pradesh."
        },
        {
          "id": 15,
          "question": "What is the total outlay announced for the 'Purvodaya' comprehensive development initiative covering Bihar, Jharkhand, West Bengal, Odisha, and Andhra Pradesh?",
          "options": [
            "Targeted infrastructure and industrial corridor development package",
            "Special Category Status declaration",
            "Free electricity distribution",
            "State debt write-off"
          ],
          "correct": 0,
          "explanation": "The Purvodaya initiative focuses on developing the eastern region of India into an engine of growth through highway corridors, power projects, and temple tourism."
        },
        {
          "id": 16,
          "question": "Which Constitutional Amendment Act introduced the Goods and Services Tax (GST) in India?",
          "options": [
            "101st Constitutional Amendment Act, 2016",
            "100th Constitutional Amendment Act",
            "102nd Constitutional Amendment Act",
            "103rd Constitutional Amendment Act"
          ],
          "correct": 0,
          "explanation": "The 101st Constitutional Amendment Act 2016 inserted Article 246A, Article 269A, and Article 279A to implement the nationwide Goods and Services Tax."
        },
        {
          "id": 17,
          "question": "Who is the Chairperson of the Goods and Services Tax (GST) Council as per Article 279A of the Constitution?",
          "options": [
            "The Union Finance Minister",
            "The Prime Minister of India",
            "The Governor of RBI",
            "A rotated State Finance Minister"
          ],
          "correct": 0,
          "explanation": "Under Article 279A, the Union Finance Minister serves as the Chairperson of the GST Council, comprising State Finance Ministers as members."
        },
        {
          "id": 18,
          "question": "What is the voting weightage distribution in the GST Council between the Central Government and the State Governments?",
          "options": [
            "Central Government has one-third weightage, all State Governments combined have two-thirds weightage",
            "50% Centre and 50% States",
            "Central Government has two-thirds weightage",
            "Equal one vote per member"
          ],
          "correct": 0,
          "explanation": "Article 279A(9) stipulates that the Central Government has a one-third weightage of total votes cast, while all State Governments combined have two-thirds weightage, with a 75% majority needed for decisions."
        },
        {
          "id": 19,
          "question": "Which Article of the Constitution empowers Parliament to impose restrictions on trade, commerce, and intercourse between States in the public interest?",
          "options": [
            "Article 302",
            "Article 301",
            "Article 304",
            "Article 300A"
          ],
          "correct": 0,
          "explanation": "While Article 301 guarantees freedom of trade and commerce throughout India, Article 302 permits Parliament to enact restrictions in the public interest."
        },
        {
          "id": 20,
          "question": "Right to Property ceased to be a Fundamental Right and became a Constitutional Legal Right under Article 300A via which Amendment Act?",
          "options": [
            "44th Constitutional Amendment Act, 1978",
            "42nd Constitutional Amendment Act, 1976",
            "24th Constitutional Amendment Act, 1971",
            "1st Constitutional Amendment Act, 1951"
          ],
          "correct": 0,
          "explanation": "The 44th Amendment Act, 1978 deleted the Right to Property from Article 19(1)(f) and Article 31, inserting it as a legal right under Article 300A in Part XII."
        },
        {
          "id": 21,
          "question": "Which High Court celebrated the completion of 160+ years since its establishment as one of the three chartered High Courts in 1862?",
          "options": [
            "Calcutta, Bombay, and Madras High Courts",
            "Allahabad High Court",
            "Delhi High Court",
            "Patna High Court"
          ],
          "correct": 0,
          "explanation": "Calcutta, Bombay, and Madras High Courts were established by Letters Patent issued by Queen Victoria under the High Courts Act of 1861, commencing in 1862."
        },
        {
          "id": 22,
          "question": "Under Article 217 of the Constitution, a High Court Judge holds office until attaining what age?",
          "options": [
            "62 years",
            "65 years",
            "60 years",
            "70 years"
          ],
          "correct": 0,
          "explanation": "High Court judges hold office until 62 years of age (raised from 60 by the 15th Amendment Act 1963), whereas Supreme Court judges retire at 65 years under Article 124."
        },
        {
          "id": 23,
          "question": "Who administers the oath of office to a newly appointed Judge of a High Court as per Article 219?",
          "options": [
            "The Governor of the State (or a person appointed by him)",
            "The Chief Justice of India",
            "The President of India",
            "The Chief Minister of the State"
          ],
          "correct": 0,
          "explanation": "Article 219 mandates that every person appointed to be a Judge of a High Court shall, before entering upon office, take an oath before the Governor of the State."
        },
        {
          "id": 24,
          "question": "What is the retirement age of a Judge of the Supreme Court of India under Article 124(2)?",
          "options": [
            "65 years",
            "62 years",
            "68 years",
            "70 years"
          ],
          "correct": 0,
          "explanation": "Under Article 124(2) of the Indian Constitution, a judge of the Supreme Court holds office until attaining the age of sixty-five years."
        },
        {
          "id": 25,
          "question": "Which Article of the Constitution confers power on the Supreme Court to review any judgment pronounced or order made by it?",
          "options": [
            "Article 137",
            "Article 136",
            "Article 141",
            "Article 143"
          ],
          "correct": 0,
          "explanation": "Article 137 provides that subject to any law made by Parliament or rules under Article 145, the Supreme Court has power to review any judgment pronounced by it."
        }
      ]
    },
    "politics_aug2026": {
      "id": "politics_aug2026",
      "category_id": "politics",
      "category_name": "Politics & National Affairs",
      "month_id": "aug2026",
      "month_name": "August 2026",
      "title": "Politics Current Affairs - August 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "On August 15, 2026, Prime Minister Narendra Modi addressed the nation from the ramparts of the Red Fort for which consecutive year?",
          "options": [
            "11th consecutive time",
            "10th time",
            "12th time",
            "9th time"
          ],
          "correct": 0,
          "explanation": "Prime Minister Narendra Modi hoisted the national flag and addressed the country for the 11th consecutive time on Independence Day, surpassing Indira Gandhi's continuous record of 10 speeches."
        },
        {
          "id": 2,
          "question": "What was the nationwide campaign theme celebrated ahead of Independence Day from August 9 to 15, 2026?",
          "options": [
            "Har Ghar Tiranga 2026",
            "Meri Maati Mera Desh",
            "Azadi Ka Amrit Mahotsav",
            "Ek Bharat Shreshtha Bharat"
          ],
          "correct": 0,
          "explanation": "The third edition of the 'Har Ghar Tiranga' campaign was observed nationwide, encouraging citizens to hoist the National Flag at their homes and click 'Tiranga Selfies'."
        },
        {
          "id": 3,
          "question": "The Flag Code of India was comprehensively amended in December 2021 to allow the National Flag to be made of which materials?",
          "options": [
            "Hand spun, hand woven or machine made cotton, polyester, wool, silk, or khadi bunting",
            "Khadi only",
            "Silk and cotton only",
            "Handloom cotton only"
          ],
          "correct": 0,
          "explanation": "Paragraph 1.2 of the Flag Code was amended to permit polyester or machine-made flags alongside traditional hand-spun khadi, cotton, and silk."
        },
        {
          "id": 4,
          "question": "Under the amended Flag Code of India 2002, can the National Flag be flown by the public day and night?",
          "options": [
            "Yes, where the Flag is displayed in open or on the house of a member of the public, it may be flown day and night",
            "No, strictly sunrise to sunset only",
            "Only on public holidays",
            "Only with police permission"
          ],
          "correct": 0,
          "explanation": "The 2022 amendment allows the National Flag to remain hoisted overnight at open private residences provided it is properly displayed."
        },
        {
          "id": 5,
          "question": "What is the official ratio of width to length of the National Flag of India specified in the Flag Code?",
          "options": [
            "2:3 (Two to three)",
            "3:4",
            "1:2",
            "3:5"
          ],
          "correct": 0,
          "explanation": "The ratio of the width (height) to the length of the National Flag of India is strictly 2:3."
        },
        {
          "id": 6,
          "question": "How many spokes are there in the Ashoka Chakra situated at the centre of the white band of the Indian National Flag?",
          "options": [
            "24 spokes",
            "20 spokes",
            "28 spokes",
            "32 spokes"
          ],
          "correct": 0,
          "explanation": "The Ashoka Chakra has 24 evenly spaced spokes in navy blue colour, representing the 24 hours of the day and 24 virtues."
        },
        {
          "id": 7,
          "question": "Who designed the modern National Flag of India which was adopted by the Constituent Assembly on July 22, 1947?",
          "options": [
            "Pingali Venkayya",
            "Rabindranath Tagore",
            "Bankim Chandra Chattopadhyay",
            "Bhikaji Cama"
          ],
          "correct": 0,
          "explanation": "Freedom fighter and agriculturist Pingali Venkayya designed the swaraj flag that was subsequently modified and adopted by the Constituent Assembly."
        },
        {
          "id": 8,
          "question": "On which date was the National Anthem of India ('Jana Gana Mana') adopted by the Constituent Assembly?",
          "options": [
            "January 24, 1950",
            "August 15, 1947",
            "November 26, 1949",
            "January 26, 1950"
          ],
          "correct": 0,
          "explanation": "The Constituent Assembly adopted Rabindranath Tagore's composition 'Jana Gana Mana' as the National Anthem of India on January 24, 1950."
        },
        {
          "id": 9,
          "question": "What is the formal playing time of the full version of the National Anthem of India?",
          "options": [
            "Approximately 52 seconds",
            "65 seconds",
            "45 seconds",
            "60 seconds"
          ],
          "correct": 0,
          "explanation": "The official playing time of the full orchestral version of the Indian National Anthem is approximately 52 seconds (with a short version of 20 seconds)."
        },
        {
          "id": 10,
          "question": "What milestone anniversary did the Pradhan Mantri Jan Dhan Yojana (PMJDY) complete on August 28, 2026?",
          "options": [
            "12 years of implementation",
            "10 years",
            "8 years",
            "15 years"
          ],
          "correct": 0,
          "explanation": "Launched on August 28, 2014, PMJDY completed 12 years of national financial inclusion, with total bank accounts surpassing 53 crore and deposits exceeding ₹2.3 lakh crore."
        },
        {
          "id": 11,
          "question": "What is the overdraft (OD) facility limit permitted under PMJDY accounts for eligible account holders?",
          "options": [
            "Up to ₹10,000",
            "Up to ₹5,000",
            "Up to ₹15,000",
            "Up to ₹20,000"
          ],
          "correct": 0,
          "explanation": "The overdraft limit under PMJDY was doubled from ₹5,000 to ₹10,000 without collateral conditions for active accounts."
        },
        {
          "id": 12,
          "question": "Which flagship scheme marked the expansion of free health cover of ₹5 lakh to all senior citizens aged 70 years and above, irrespective of income?",
          "options": [
            "Ayushman Bharat Pradhan Mantri Jan Arogya Yojana (AB-PMJAY)",
            "Rashtriya Swasthya Bima Yojana",
            "PM Atmanirbhar Swasth Bharat Yojana",
            "Pradhan Mantri Suraksha Bima Yojana"
          ],
          "correct": 0,
          "explanation": "The Union Cabinet approved universal health coverage of ₹5 lakh per family per year to all senior citizens aged 70 years and above under AB-PMJAY."
        },
        {
          "id": 13,
          "question": "What is the annual health insurance coverage provided per family under Ayushman Bharat PM-JAY?",
          "options": [
            "₹5 lakh per family per year for secondary and tertiary hospitalization",
            "₹2 lakh per year",
            "₹10 lakh per year",
            "₹1 lakh per year"
          ],
          "correct": 0,
          "explanation": "AB-PMJAY provides a defined benefit cover of ₹5,00,000 per family per year on a family floater basis across empanelled hospitals."
        },
        {
          "id": 14,
          "question": "Which organization is the apex statutory body responsible for implementing Ayushman Bharat PM-JAY nationwide?",
          "options": [
            "National Health Authority (NHA)",
            "National Health Mission (NHM)",
            "Medical Council of India",
            "AIIMS Delhi"
          ],
          "correct": 0,
          "explanation": "The National Health Authority (NHA) is the autonomous attached office of the Ministry of Health and Family Welfare responsible for PM-JAY and ABDM."
        },
        {
          "id": 15,
          "question": "Under the National Quantum Mission (NQM), what is the total approved financial outlay for 2023-2031?",
          "options": [
            "₹6,003.65 crore",
            "₹10,372 crore",
            "₹4,000 crore",
            "₹8,500 crore"
          ],
          "correct": 0,
          "explanation": "The Union Cabinet approved the National Quantum Mission with an outlay of ₹6,003.65 crore to develop quantum computers, communication, and sensors."
        },
        {
          "id": 16,
          "question": "Which constitutional body is tasked under Article 148 to audit all receipts and expenditures of the Government of India and the state governments?",
          "options": [
            "Comptroller and Auditor General of India (CAG)",
            "Central Vigilance Commission",
            "CBI",
            "Public Accounts Committee"
          ],
          "correct": 0,
          "explanation": "Article 148 establishes the Comptroller and Auditor General of India as the supreme audit institution of the country."
        },
        {
          "id": 17,
          "question": "The Central Vigilance Commission (CVC) was established in 1964 based on the recommendations of which Committee?",
          "options": [
            "K. Santhanam Committee on Prevention of Corruption",
            "Gorwala Committee",
            "Administrative Reforms Commission",
            "Sarkaria Commission"
          ],
          "correct": 0,
          "explanation": "The CVC was set up following the recommendations of the Committee on Prevention of Corruption chaired by Shri K. Santhanam in 1964."
        },
        {
          "id": 18,
          "question": "Under the Central Vigilance Commission Act, 2003, what is the term of office for the Central Vigilance Commissioner?",
          "options": [
            "4 years or up to 65 years of age, whichever is earlier",
            "5 years or 65 years",
            "3 years or 62 years",
            "6 years or 65 years"
          ],
          "correct": 0,
          "explanation": "The Central Vigilance Commissioner and Vigilance Commissioners hold office for a term of 4 years from the date of entering office or until age 65."
        },
        {
          "id": 19,
          "question": "Who is the Chairman of the selection committee that recommends appointments to the Lokpal of India?",
          "options": [
            "The Prime Minister of India",
            "The Chief Justice of India",
            "The Speaker of Lok Sabha",
            "The President of India"
          ],
          "correct": 0,
          "explanation": "Under Section 4 of the Lokpal and Lokayuktas Act 2013, the Selection Committee is chaired by the Prime Minister and includes the Speaker of Lok Sabha, Leader of Opposition, CJI (or nominee), and an eminent jurist."
        },
        {
          "id": 20,
          "question": "Who is the current Chairperson of the Lokpal of India appointed in 2024?",
          "options": [
            "Justice A.M. Khanwilkar",
            "Justice Pinaki Chandra Ghose",
            "Justice Pradip Kumar Mohanty",
            "Justice Hemant Gupta"
          ],
          "correct": 0,
          "explanation": "Former Supreme Court judge Justice A.M. Khanwilkar was appointed as the Chairperson of the Lokpal of India."
        },
        {
          "id": 21,
          "question": "Under which Article of the Constitution can Parliament create a new All India Service if the Rajya Sabha passes a resolution supported by not less than two-thirds of members present and voting?",
          "options": [
            "Article 312",
            "Article 315",
            "Article 310",
            "Article 309"
          ],
          "correct": 0,
          "explanation": "Article 312 vests exclusive power in the Rajya Sabha to initiate the creation of one or more All India Services (such as Indian Forest Service, Indian Judicial Service) by a two-thirds majority resolution."
        },
        {
          "id": 22,
          "question": "How many All India Services currently exist in India under the All India Services Act, 1951?",
          "options": [
            "3 services (IAS, IPS, and IFS - Indian Forest Service)",
            "2 services",
            "4 services",
            "5 services"
          ],
          "correct": 0,
          "explanation": "There are three All India Services common to the Union and the States: Indian Administrative Service (IAS), Indian Police Service (IPS), and Indian Forest Service (IFS, created in 1966)."
        },
        {
          "id": 23,
          "question": "Which constitutional doctrine ensures that the Legislature cannot bypass constitutional limitations by doing indirectly what it cannot do directly?",
          "options": [
            "Doctrine of Colourable Legislation",
            "Doctrine of Pith and Substance",
            "Doctrine of Severability",
            "Doctrine of Eclipse"
          ],
          "correct": 0,
          "explanation": "The Doctrine of Colourable Legislation is based on the maxim 'What cannot be done directly, cannot also be done indirectly', testing legislative competence."
        },
        {
          "id": 24,
          "question": "Which constitutional doctrine resolves overlapping legislative jurisdiction between the Union List and State List by examining the true nature and character of the law?",
          "options": [
            "Doctrine of Pith and Substance",
            "Doctrine of Repugnancy",
            "Doctrine of Territorial Nexus",
            "Doctrine of Laches"
          ],
          "correct": 0,
          "explanation": "The Doctrine of Pith and Substance determines whether a law substantially falls within the enacting legislature's competence, notwithstanding incidental encroachment on another list."
        },
        {
          "id": 25,
          "question": "What does Article 254 of the Constitution govern in the context of the Seventh Schedule?",
          "options": [
            "Repugnancy or inconsistency between laws made by Parliament and laws made by State Legislatures on Concurrent List subjects",
            "Imposition of President's Rule",
            "Distribution of river waters",
            "Emergency declarations"
          ],
          "correct": 0,
          "explanation": "Article 254 establishes that in case of repugnancy between a Parliamentary enactment and a State law on a Concurrent List subject, the Parliamentary law prevails unless the State law received Presidential assent."
        }
      ]
    },
    "economy_feb2026": {
      "id": "economy_feb2026",
      "category_id": "economy",
      "category_name": "Economy, Banking & Finance",
      "month_id": "feb2026",
      "month_name": "February 2026",
      "title": "Economy Current Affairs - February 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "What was the projected fiscal deficit target as a percentage of GDP for FY 2024-25 / FY 2025-26 in the Union Budget?",
          "options": [
            "4.9% of GDP",
            "5.1% of GDP",
            "5.8% of GDP",
            "4.5% of GDP"
          ],
          "correct": 0,
          "explanation": "The Union Budget pegged the fiscal deficit at 4.9% of GDP for FY25, reaffirming the commitment to reach below 4.5% by FY26."
        },
        {
          "id": 2,
          "question": "What is the capital expenditure (Capex) allocation announced in the Union Budget to boost infrastructure growth?",
          "options": [
            "₹11,11,111 crore (3.4% of GDP)",
            "₹10,00,000 crore",
            "₹8,50,000 crore",
            "₹12,50,000 crore"
          ],
          "correct": 0,
          "explanation": "The Central Government maintained a record effective capital expenditure outlay of ₹11.11 lakh crore (representing 3.4% of GDP) for infrastructure creation."
        },
        {
          "id": 3,
          "question": "Under the revised New Tax Regime (Section 115BAC), what was the Standard Deduction for salaried employees increased to?",
          "options": [
            "₹75,000",
            "₹50,000",
            "₹60,000",
            "₹1,00,000"
          ],
          "correct": 0,
          "explanation": "The standard deduction for salaried individuals under the new tax regime was enhanced from ₹50,000 to ₹75,000 in the Finance Bill."
        },
        {
          "id": 4,
          "question": "Under the revised New Tax Regime, income up to what limit is taxed at NIL rate?",
          "options": [
            "Up to ₹3,00,000",
            "Up to ₹2,50,000",
            "Up to ₹5,00,000",
            "Up to ₹3,50,000"
          ],
          "correct": 0,
          "explanation": "Under the revised tax slabs: 0 to ₹3 lakh is Nil; ₹3-7 lakh is 5%; ₹7-10 lakh is 10%; ₹10-12 lakh is 15%; ₹12-15 lakh is 20%; and above ₹15 lakh is 30%."
        },
        {
          "id": 5,
          "question": "What is the current policy Repo Rate maintained by the RBI Monetary Policy Committee (MPC) in its bi-monthly review?",
          "options": [
            "6.50%",
            "6.25%",
            "6.75%",
            "6.00%"
          ],
          "correct": 0,
          "explanation": "The RBI Monetary Policy Committee maintained the benchmark policy repo rate unchanged at 6.50% to align retail inflation with the 4% target."
        },
        {
          "id": 6,
          "question": "What is the mandated retail inflation target band for the Reserve Bank of India under the flexible inflation targeting framework?",
          "options": [
            "4% with a tolerance band of +/- 2% (2% to 6%)",
            "3% with +/- 1%",
            "5% with +/- 2%",
            "4% fixed"
          ],
          "correct": 0,
          "explanation": "Under Section 45ZA of the RBI Act 1934, the inflation target is 4% Consumer Price Index (CPI) with an upper tolerance level of 6% and lower tolerance of 2%."
        },
        {
          "id": 7,
          "question": "How many members comprise the Monetary Policy Committee (MPC) of the Reserve Bank of India?",
          "options": [
            "6 members (3 from RBI, 3 external experts appointed by Centre)",
            "5 members",
            "7 members",
            "4 members"
          ],
          "correct": 0,
          "explanation": "The MPC consists of 6 members: the RBI Governor (Chairperson), Deputy Governor in charge of monetary policy, one RBI officer, and three external experts nominated by the Central Government."
        },
        {
          "id": 8,
          "question": "In case of an equality of votes in the RBI Monetary Policy Committee meeting, who has the casting vote?",
          "options": [
            "The Governor of the Reserve Bank of India",
            "The Union Finance Minister",
            "The Senior-most External Member",
            "The Chief Economic Advisor"
          ],
          "correct": 0,
          "explanation": "Under Section 45ZL of the RBI Act, each member of the MPC has one vote, and in the event of an equality of votes, the RBI Governor has a second or casting vote."
        },
        {
          "id": 9,
          "question": "What was India's real GDP growth rate projection for FY25 in the Economic Survey presented in Parliament?",
          "options": [
            "6.5% to 7.0%",
            "6.0% to 6.5%",
            "7.2% to 7.5%",
            "7.0% to 7.5%"
          ],
          "correct": 0,
          "explanation": "The Economic Survey conservatively projected India's real GDP growth at 6.5–7.0% for FY 2024-25, highlighting macroeconomic stability."
        },
        {
          "id": 10,
          "question": "Who presents the Economic Survey in Parliament ahead of the Union Budget?",
          "options": [
            "The Union Finance Minister",
            "The Prime Minister",
            "Chief Economic Advisor directly",
            "Speaker of Lok Sabha"
          ],
          "correct": 0,
          "explanation": "While the Economic Survey is authored by the Chief Economic Advisor and his team in the Department of Economic Affairs, it is formally tabled in Parliament by the Union Finance Minister."
        },
        {
          "id": 11,
          "question": "Who is the current Chief Economic Advisor (CEA) to the Government of India?",
          "options": [
            "Dr. V. Anantha Nageswaran",
            "Dr. Krishnamurthy Subramanian",
            "Dr. Arvind Subramanian",
            "Dr. Raghuram Rajan"
          ],
          "correct": 0,
          "explanation": "Dr. V. Anantha Nageswaran assumed office as the Chief Economic Advisor to the Government of India in January 2022."
        },
        {
          "id": 12,
          "question": "Which tax was completely abolished in the Union Budget to encourage startup funding and angel investments in India?",
          "options": [
            "Angel Tax (Section 56(2)(viib) of IT Act)",
            "Securities Transaction Tax",
            "Minimum Alternate Tax",
            "Equalisation Levy"
          ],
          "correct": 0,
          "explanation": "The Union Budget completely abolished the 'Angel Tax' on all classes of investors to foster the startup ecosystem and boost entrepreneurial investments."
        },
        {
          "id": 13,
          "question": "The customs duty on gold and silver bars was reduced from 15% to what percentage in the Union Budget?",
          "options": [
            "6%",
            "10%",
            "7.5%",
            "5%"
          ],
          "correct": 0,
          "explanation": "Basic customs duty on gold and silver was reduced sharply from 15% to 6% to curb smuggling and stimulate domestic jewellery manufacturing."
        },
        {
          "id": 14,
          "question": "What is the revised loan ceiling for micro-enterprises under the 'Tarun Plus' category of Pradhan Mantri Mudra Yojana (PMMY)?",
          "options": [
            "Enhanced from ₹10 lakh to ₹20 lakh",
            "Enhanced to ₹15 lakh",
            "Enhanced to ₹25 lakh",
            "Enhanced to ₹30 lakh"
          ],
          "correct": 0,
          "explanation": "The budget enhanced the Mudra loan limit under Tarun category from ₹10 lakh to ₹20 lakh for entrepreneurs who have successfully repaid previous loans."
        },
        {
          "id": 15,
          "question": "Which scheme was announced for providing financial support for loans up to ₹10 lakh for higher education in domestic institutions?",
          "options": [
            "Model Skill Loan Scheme / PM Vidya Lakshmi",
            "Vidya Samiksha",
            "PM-SHRI Loan",
            "Pragati Scholarship"
          ],
          "correct": 0,
          "explanation": "The government announced e-vouchers with 3% annual interest subvention for education loans up to ₹10 lakh for youth in domestic higher educational institutions."
        },
        {
          "id": 16,
          "question": "What is the primary function of the 'Standing Deposit Facility' (SDF) introduced by the RBI in 2022?",
          "options": [
            "To absorb surplus liquidity from the commercial banking system without providing collateral",
            "To inject emergency cash to NBFCs",
            "To provide export subsidies",
            "To regulate forex remittances"
          ],
          "correct": 0,
          "explanation": "SDF serves as the floor of the Liquidity Adjustment Facility (LAF) corridor, enabling the RBI to absorb uncollateralized overnight liquidity from banks."
        },
        {
          "id": 17,
          "question": "What is the current Marginal Standing Facility (MSF) rate relative to the Repo Rate?",
          "options": [
            "25 basis points (0.25%) above the repo rate",
            "50 basis points above",
            "Equal to repo rate",
            "25 basis points below repo rate"
          ],
          "correct": 0,
          "explanation": "The MSF rate and Bank Rate are positioned 25 basis points above the policy repo rate, forming the upper bound of the policy corridor."
        },
        {
          "id": 18,
          "question": "Which public sector bank is the largest commercial bank in India by assets, deposits, and branches?",
          "options": [
            "State Bank of India (SBI)",
            "Punjab National Bank",
            "Bank of Baroda",
            "Canara Bank"
          ],
          "correct": 0,
          "explanation": "State Bank of India is a Fortune 500 company and the largest public sector bank in India, holding over a quarter of the market share."
        },
        {
          "id": 19,
          "question": "Under Basel III regulatory norms, what is the minimum Capital to Risk-Weighted Assets Ratio (CRAR) mandated by RBI for Indian commercial banks?",
          "options": [
            "9% (plus 2.5% Capital Conservation Buffer = 11.5%)",
            "8%",
            "10%",
            "12%"
          ],
          "correct": 0,
          "explanation": "RBI prescribes a minimum total CRAR of 9% for scheduled commercial banks, which rises to 11.50% including the 2.5% Capital Conservation Buffer (CCB)."
        },
        {
          "id": 20,
          "question": "What is the name of the sovereign entity that manages the government's debt and market borrowings in India?",
          "options": [
            "Reserve Bank of India (RBI)",
            "SEBI",
            "State Bank of India",
            "Debt Management Office (DMO) only"
          ],
          "correct": 0,
          "explanation": "Under the RBI Act 1934, the Reserve Bank of India acts as the banker and debt manager to the Central and State Governments."
        },
        {
          "id": 21,
          "question": "What are 'Treasury Bills' (T-Bills) issued by the Government of India, and what are their standard maturities?",
          "options": [
            "Zero-coupon money market instruments with tenors of 91, 182, and 364 days",
            "10-year bonds",
            "Perpetual debentures",
            "5-year infrastructure certificates"
          ],
          "correct": 0,
          "explanation": "Treasury Bills are short-term promissory notes issued at a discount and redeemed at face value by the Central Government in 91-day, 182-day, and 364-day tenors."
        },
        {
          "id": 22,
          "question": "What is the minimum denomination in which Treasury Bills are auctioned in India?",
          "options": [
            "₹25,000 and multiples thereof",
            "₹10,000",
            "₹1,00,000",
            "₹50,000"
          ],
          "correct": 0,
          "explanation": "Treasury bills are available for a minimum amount of ₹25,000 and in multiples of ₹25,000 thereafter."
        },
        {
          "id": 23,
          "question": "Which index measures wholesale price fluctuations and is published by the Office of the Economic Adviser, Ministry of Commerce & Industry?",
          "options": [
            "Wholesale Price Index (WPI)",
            "Consumer Price Index (CPI)",
            "Index of Industrial Production (IIP)",
            "Purchasing Managers' Index (PMI)"
          ],
          "correct": 0,
          "explanation": "WPI tracks headline inflation at the wholesale producer stage, with 2011-12 as its base year."
        },
        {
          "id": 24,
          "question": "What is the base year for the calculation of the Consumer Price Index (CPI) Combined in India?",
          "options": [
            "2012 = 100",
            "2011 = 100",
            "2004 = 100",
            "2015 = 100"
          ],
          "correct": 0,
          "explanation": "The National Statistical Office (NSO) compiles CPI (Rural, Urban, Combined) using 2012 as the base year."
        },
        {
          "id": 25,
          "question": "Which weightage category constitutes the largest share in the Consumer Price Index (CPI) basket in India?",
          "options": [
            "Food and Beverages (approx. 45.86%)",
            "Housing",
            "Fuel and Light",
            "Clothing and Footwear"
          ],
          "correct": 0,
          "explanation": "Food and Beverages carry the highest weight of 45.86% in the CPI Combined basket, making food prices a critical driver of headline retail inflation."
        }
      ]
    },
    "economy_mar2026": {
      "id": "economy_mar2026",
      "category_id": "economy",
      "category_name": "Economy, Banking & Finance",
      "month_id": "mar2026",
      "month_name": "March 2026",
      "title": "Economy Current Affairs - March 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "What milestone record was set by Gross Goods and Services Tax (GST) collections in March/April 2026?",
          "options": [
            "Crossed ₹2.10 lakh crore in a single month",
            "Crossed ₹1.80 lakh crore",
            "Crossed ₹1.50 lakh crore",
            "Crossed ₹2.50 lakh crore"
          ],
          "correct": 0,
          "explanation": "Gross GST collections hit an all-time high of over ₹2.10 lakh crore, driven by strong domestic transactions and economic compliance."
        },
        {
          "id": 2,
          "question": "Which state recorded the highest GST collection among all Indian states and Union Territories?",
          "options": [
            "Maharashtra",
            "Gujarat",
            "Karnataka",
            "Tamil Nadu"
          ],
          "correct": 0,
          "explanation": "Maharashtra consistently contributes the largest share of national GST revenue, contributing over ₹30,000 crore monthly."
        },
        {
          "id": 3,
          "question": "What new settlement mechanism did SEBI launch on an optional basis for 25 scrips in March 2026?",
          "options": [
            "Beta version of T+0 rolling settlement cycle",
            "T+2 settlement cycle",
            "T+3 settlement",
            "Instant continuous block trading"
          ],
          "correct": 0,
          "explanation": "SEBI rolled out the beta version of optional T+0 settlement for select liquid stocks, settling trades on the same day alongside the existing T+1 cycle."
        },
        {
          "id": 4,
          "question": "Who is the Chairperson of the Securities and Exchange Board of India (SEBI)?",
          "options": [
            "Madhabi Puri Buch",
            "Ajay Tyagi",
            "UK Sinha",
            "CB Bhave"
          ],
          "correct": 0,
          "explanation": "Madhabi Puri Buch became the first woman and the first private sector professional to lead the market regulator SEBI."
        },
        {
          "id": 5,
          "question": "India's Foreign Exchange Reserves breached what historic psychological milestone in March 2026?",
          "options": [
            "$650 Billion",
            "$550 Billion",
            "$750 Billion",
            "$500 Billion"
          ],
          "correct": 0,
          "explanation": "India's forex reserves crossed the $650 billion mark, comprising foreign currency assets, gold reserves, SDRs, and reserve tranche in the IMF."
        },
        {
          "id": 6,
          "question": "Which component forms the largest portion of India's Foreign Exchange Reserves?",
          "options": [
            "Foreign Currency Assets (FCA)",
            "Gold",
            "Special Drawing Rights (SDR)",
            "Reserve Tranche Position (RTP)"
          ],
          "correct": 0,
          "explanation": "Foreign Currency Assets (FCAs) expressed in US dollars make up over 85% of India's total foreign exchange reserves."
        },
        {
          "id": 7,
          "question": "Special Drawing Rights (SDR) is an international reserve asset created in 1969 by which multilateral institution?",
          "options": [
            "International Monetary Fund (IMF)",
            "World Bank",
            "Bank for International Settlements (BIS)",
            "Asian Development Bank (ADB)"
          ],
          "correct": 0,
          "explanation": "The IMF created SDRs to supplement member countries' official reserves, based on a basket of 5 currencies (USD, Euro, Yuan, Yen, Pound Sterling)."
        },
        {
          "id": 8,
          "question": "What is the weightiest currency in the IMF's Special Drawing Rights (SDR) valuation basket?",
          "options": [
            "US Dollar (approx. 43.38%)",
            "Euro",
            "Chinese Renminbi",
            "Japanese Yen"
          ],
          "correct": 0,
          "explanation": "The US Dollar carries the largest weight of approximately 43.38% in the SDR basket, followed by the Euro (29.31%)."
        },
        {
          "id": 9,
          "question": "Which Indian regulatory body issues licenses to 'Payments Banks' and 'Small Finance Banks'?",
          "options": [
            "Reserve Bank of India (RBI)",
            "SEBI",
            "NABARD",
            "IRDAI"
          ],
          "correct": 0,
          "explanation": "Under Section 22 of the Banking Regulation Act, 1949, the RBI is the sole licensing authority for differentiated and commercial banks."
        },
        {
          "id": 10,
          "question": "What is the maximum balance that a customer can hold at the end of the day in a Payments Bank account?",
          "options": [
            "₹2,00,000 (Two lakh rupees)",
            "₹1,00,000",
            "₹5,00,000",
            "Unlimited"
          ],
          "correct": 0,
          "explanation": "RBI enhanced the maximum end-of-day deposit limit per individual customer in Payments Banks from ₹1 lakh to ₹2 lakh."
        },
        {
          "id": 11,
          "question": "Can Payments Banks issue credit cards or undertake lending activities under RBI guidelines?",
          "options": [
            "No, they cannot lend or issue credit cards; they can only issue debit cards and accept demand deposits",
            "Yes, up to ₹50,000",
            "Yes, with RBI approval",
            "Yes, for agriculture only"
          ],
          "correct": 0,
          "explanation": "Payments Banks are strictly prohibited from lending money or issuing credit cards; their scope is restricted to acceptance of demand deposits and remittance services."
        },
        {
          "id": 12,
          "question": "What is the minimum percentage of Adjusted Net Bank Credit (ANBC) that Small Finance Banks must lend to Priority Sectors?",
          "options": [
            "75% of ANBC",
            "40% of ANBC",
            "50% of ANBC",
            "60% of ANBC"
          ],
          "correct": 0,
          "explanation": "Small Finance Banks (SFBs) are mandated to allocate at least 75% of their Adjusted Net Bank Credit to the priority sector, compared to 40% for universal banks."
        },
        {
          "id": 13,
          "question": "What is the Priority Sector Lending (PSL) target for domestic scheduled commercial banks (excluding RRBs & SFBs)?",
          "options": [
            "40% of Adjusted Net Bank Credit (ANBC)",
            "50% of ANBC",
            "30% of ANBC",
            "25% of ANBC"
          ],
          "correct": 0,
          "explanation": "Universal commercial banks must direct 40% of their ANBC or credit equivalent of off-balance sheet exposure to priority sectors (agriculture, MSME, housing, etc.)."
        },
        {
          "id": 14,
          "question": "Which institution is the apex regulatory body for housing finance companies in India, supervised by RBI?",
          "options": [
            "National Housing Bank (NHB)",
            "HUDCO",
            "HDFC",
            "SIDBI"
          ],
          "correct": 0,
          "explanation": "NHB is an all-India financial institution under the Department of Financial Services, operating as the apex developmental institution for the housing sector."
        },
        {
          "id": 15,
          "question": "Where are the headquarters of the Small Industries Development Bank of India (SIDBI) situated?",
          "options": [
            "Lucknow, Uttar Pradesh",
            "Mumbai, Maharashtra",
            "New Delhi",
            "Kolkata, West Bengal"
          ],
          "correct": 0,
          "explanation": "SIDBI, established under an Act of Parliament in 1990 as the principal financial institution for MSMEs, is headquartered in Lucknow."
        },
        {
          "id": 16,
          "question": "Where are the headquarters of the National Bank for Agriculture and Rural Development (NABARD) located?",
          "options": [
            "Mumbai, Maharashtra",
            "New Delhi",
            "Pune, Maharashtra",
            "Hyderabad, Telangana"
          ],
          "correct": 0,
          "explanation": "NABARD was established on July 12, 1982, on the recommendations of the B. Sivaraman Committee and has its headquarters in Mumbai."
        },
        {
          "id": 17,
          "question": "The 'B. Sivaraman Committee' was instrumental in the establishment of which apex institution?",
          "options": [
            "NABARD",
            "SEBI",
            "SIDBI",
            "EXIM Bank"
          ],
          "correct": 0,
          "explanation": "The Committee to Review Arrangements for Institutional Credit for Agriculture and Rural Development (CRAFICARD) chaired by B. Sivaraman recommended creating NABARD."
        },
        {
          "id": 18,
          "question": "Which organization publishes the 'Financial Stability Report' (FSR) twice every year in India?",
          "options": [
            "Reserve Bank of India (RBI)",
            "Ministry of Finance",
            "SEBI",
            "NITI Aayog"
          ],
          "correct": 0,
          "explanation": "The RBI publishes the biannual Financial Stability Report reflecting the collective assessment of the Sub-Committee of the Financial Stability and Development Council (FSDC)."
        },
        {
          "id": 19,
          "question": "What does 'NPA' stand for in commercial banking, and after how many days of overdue interest/principal is a loan classified as NPA?",
          "options": [
            "Non-Performing Asset; 90 days overdue",
            "Non-Performing Account; 60 days overdue",
            "Net Profit Asset; 180 days overdue",
            "Non-Payment Asset; 30 days overdue"
          ],
          "correct": 0,
          "explanation": "An asset, including a lease asset, becomes non-performing when it ceases to generate income for the bank; a loan is classified as an NPA if interest or installment remains overdue for more than 90 days."
        },
        {
          "id": 20,
          "question": "What are the three classifications of Non-Performing Assets (NPAs) prescribed by the RBI based on overdue duration?",
          "options": [
            "Sub-standard Assets, Doubtful Assets, and Loss Assets",
            "Mild, Moderate, and Severe NPAs",
            "Class A, Class B, and Class C assets",
            "Performing, Semi-performing, Non-performing"
          ],
          "correct": 0,
          "explanation": "Banks classify NPAs into: Sub-standard (NPA for <= 12 months), Doubtful (exceeded 12 months in sub-standard), and Loss Asset (identified as uncollectible)."
        },
        {
          "id": 21,
          "question": "Under the Insolvency and Bankruptcy Code (IBC) 2016, what is the default time limit for completing the Corporate Insolvency Resolution Process (CIRP)?",
          "options": [
            "180 days (extendable by 90 days, with overall cap of 330 days)",
            "90 days",
            "365 days",
            "120 days"
          ],
          "correct": 0,
          "explanation": "Section 12 of the IBC mandates that the CIRP shall be completed within 180 days, extendable by 90 days, with a mandatory outside limit of 330 days including litigation."
        },
        {
          "id": 22,
          "question": "Which quasi-judicial body adjudicates corporate insolvency matters for companies and LLPs under the IBC?",
          "options": [
            "National Company Law Tribunal (NCLT)",
            "Debt Recovery Tribunal (DRT)",
            "High Court",
            "SEBI Adjudicating Officer"
          ],
          "correct": 0,
          "explanation": "The NCLT is the designated Adjudicating Authority for insolvency resolution and liquidation of corporate persons under Part II of the IBC 2016."
        },
        {
          "id": 23,
          "question": "Which body adjudicates insolvency matters for individuals and partnership firms under Part III of the IBC?",
          "options": [
            "Debt Recovery Tribunal (DRT)",
            "NCLT",
            "Civil Court",
            "Lok Adalat"
          ],
          "correct": 0,
          "explanation": "The Debt Recovery Tribunal (DRT) is the adjudicating authority for insolvency and bankruptcy proceedings of individuals and partnership firms."
        },
        {
          "id": 24,
          "question": "What is the legal name of the bad bank set up by the Government and banks to acquire stressed assets from commercial banks?",
          "options": [
            "National Asset Reconstruction Company Limited (NARCL)",
            "India Debt Resolution Company Limited (IDRCL)",
            "Bad Bank of India",
            "Stressed Asset Relief Fund"
          ],
          "correct": 0,
          "explanation": "NARCL (often termed the 'Bad Bank') was incorporated to consolidate and resolve stressed bank loans above ₹500 crore."
        },
        {
          "id": 25,
          "question": "What is the function of the India Debt Resolution Company Limited (IDRCL) in coordination with NARCL?",
          "options": [
            "Asset management and turnaround company to manage and liquidate assets acquired by NARCL",
            "Financing small startups",
            "Regulating stock exchanges",
            "Issuing credit ratings"
          ],
          "correct": 0,
          "explanation": "While NARCL acquires the non-performing debt, IDRCL acts as the operational turnaround agency to manage, restructure, and maximize asset value."
        }
      ]
    },
    "economy_apr2026": {
      "id": "economy_apr2026",
      "category_id": "economy",
      "category_name": "Economy, Banking & Finance",
      "month_id": "apr2026",
      "month_name": "April 2026",
      "title": "Economy Current Affairs - April 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "What growth rate did the IMF forecast for India's GDP in its World Economic Outlook released in April 2026?",
          "options": [
            "6.8%",
            "6.5%",
            "7.0%",
            "6.2%"
          ],
          "correct": 0,
          "explanation": "The International Monetary Fund (IMF) raised India's GDP growth forecast to 6.8% for FY25, noting robust domestic investment and resilient consumption."
        },
        {
          "id": 2,
          "question": "What was the headline Consumer Price Index (CPI) retail inflation rate reported for March/April 2026?",
          "options": [
            "4.85%",
            "5.60%",
            "3.90%",
            "6.20%"
          ],
          "correct": 0,
          "explanation": "India's retail inflation moderated to 4.85%, staying comfortably within the RBI's target tolerance band of 2% to 6%."
        },
        {
          "id": 3,
          "question": "The Unified Payments Interface (UPI) processed how many billion transactions in a single month as reported by NPCI?",
          "options": [
            "Over 13.4 billion transactions",
            "Over 10 billion transactions",
            "Over 15 billion transactions",
            "Over 8 billion transactions"
          ],
          "correct": 0,
          "explanation": "NPCI reported that UPI crossed 13.4 billion monthly transactions with total transaction value exceeding ₹19.78 lakh crore."
        },
        {
          "id": 4,
          "question": "Who is the umbrella organization for operating retail payments and settlement systems in India?",
          "options": [
            "National Payments Corporation of India (NPCI)",
            "RBI directly",
            "State Bank of India",
            "Indian Banks' Association (IBA)"
          ],
          "correct": 0,
          "explanation": "NPCI is an initiative of RBI and IBA under the Payment and Settlement Systems Act, 2007, operating systems like UPI, IMPS, RuPay, and NETC FASTag."
        },
        {
          "id": 5,
          "question": "In which year was the National Payments Corporation of India (NPCI) incorporated?",
          "options": [
            "2008",
            "2016",
            "2010",
            "2004"
          ],
          "correct": 0,
          "explanation": "NPCI was established in 2008 as a 'Not for Profit' Company under Section 25 of the Companies Act 1956 (now Section 8 of Companies Act 2013)."
        },
        {
          "id": 6,
          "question": "Which country became the first European nation to adopt India's Unified Payments Interface (UPI) for retail payments?",
          "options": [
            "France",
            "Germany",
            "United Kingdom",
            "Italy"
          ],
          "correct": 0,
          "explanation": "France became the first European country to enable UPI payments, allowing Indian tourists to buy tickets for the Eiffel Tower using UPI."
        },
        {
          "id": 7,
          "question": "Between India and Singapore, which systems were linked for real-time cross-border remittances?",
          "options": [
            "UPI and PayNow",
            "UPI and PromptPay",
            "IMPS and NETS",
            "RuPay and NETS"
          ],
          "correct": 0,
          "explanation": "The linkage between India's UPI and Singapore's PayNow enables instant, low-cost cross-border fund transfers between mobile numbers."
        },
        {
          "id": 8,
          "question": "Which cross-border payment platform links India's UPI with the UAE's instant payment platform?",
          "options": [
            "UPI and AANI",
            "UPI and Wafa",
            "RuPay and Benefit",
            "UPI and Mada"
          ],
          "correct": 0,
          "explanation": "India and UAE integrated UPI with the UAE's instant payment platform 'AANI' and domestic debit card 'Jaywan' based on RuPay technology."
        },
        {
          "id": 9,
          "question": "What does 'CBDC' stand for in the context of the Reserve Bank of India's digital currency initiative?",
          "options": [
            "Central Bank Digital Currency (Digital Rupee / e₹)",
            "Certified Banking Deposit Certificate",
            "Commercial Bank Debit Code",
            "Crypto Banking Digital Credit"
          ],
          "correct": 0,
          "explanation": "CBDC is the legal tender issued by the Reserve Bank of India in digital form (e₹-Retail and e₹-Wholesale), appearing as a liability on the RBI balance sheet."
        },
        {
          "id": 10,
          "question": "Under which Section of the Reserve Bank of India Act, 1934, was the legal definition of 'bank note' amended to include digital currency?",
          "options": [
            "Section 22 and Section 26 of the RBI Act",
            "Section 18",
            "Section 42",
            "Section 45"
          ],
          "correct": 0,
          "explanation": "The Finance Act 2022 amended the RBI Act to explicitly encompass digital form currency within the statutory framework of legal tender."
        },
        {
          "id": 11,
          "question": "What is the difference between CBDC (Digital Rupee) and private cryptocurrencies like Bitcoin?",
          "options": [
            "CBDC is sovereign legal tender backed by the central bank; cryptocurrencies are decentralized assets with no sovereign backing",
            "CBDC cannot be transferred digitally",
            "Cryptocurrencies are issued by national governments",
            "CBDC earns 10% guaranteed interest"
          ],
          "correct": 0,
          "explanation": "Unlike decentralized volatile private cryptocurrencies, CBDC is a sovereign fiat currency carrying zero default risk and backed 1:1 by the central bank."
        },
        {
          "id": 12,
          "question": "Does the retail Digital Rupee (e₹-R) earn interest when held in a digital wallet?",
          "options": [
            "No, it does not earn any interest, just like physical cash",
            "Yes, at savings bank rate",
            "Yes, at repo rate",
            "Yes, at 4% fixed"
          ],
          "correct": 0,
          "explanation": "To prevent disintermediation of commercial bank deposits, retail CBDC does not bear any interest, mirroring physical currency notes."
        },
        {
          "id": 13,
          "question": "What is the core mandate of the 'Financial Stability and Development Council' (FSDC)?",
          "options": [
            "Macroprudential surveillance, financial sector development, and inter-regulatory coordination",
            "Direct lending to corporates",
            "Printing bank notes",
            "Fixing GST rates"
          ],
          "correct": 0,
          "explanation": "FSDC is an apex non-statutory council chaired by the Union Finance Minister to maintain financial stability and coordinate between RBI, SEBI, IRDAI, and PFRDA."
        },
        {
          "id": 14,
          "question": "Who is the Chairperson of the Insurance Regulatory and Development Authority of India (IRDAI)?",
          "options": [
            "Debasish Panda",
            "Subhash Chandra Khuntia",
            "TS Vijayan",
            "J. Swaminathan"
          ],
          "correct": 0,
          "explanation": "Former Financial Services Secretary Debasish Panda serves as the Chairperson of the insurance regulator IRDAI headquartered in Hyderabad."
        },
        {
          "id": 15,
          "question": "Where are the headquarters of the Insurance Regulatory and Development Authority of India (IRDAI) located?",
          "options": [
            "Hyderabad, Telangana",
            "Mumbai, Maharashtra",
            "New Delhi",
            "Chennai, Tamil Nadu"
          ],
          "correct": 0,
          "explanation": "IRDAI was constituted under the IRDA Act 1999 and relocated its statutory headquarters from Delhi to Hyderabad in 2001."
        },
        {
          "id": 16,
          "question": "Who regulates the National Pension System (NPS) and Atal Pension Yojana (APY) in India?",
          "options": [
            "Pension Fund Regulatory and Development Authority (PFRDA)",
            "IRDAI",
            "RBI",
            "Ministry of Labour"
          ],
          "correct": 0,
          "explanation": "PFRDA is the statutory regulatory body established under the PFRDA Act, 2013, to regulate and promote pension schemes in India."
        },
        {
          "id": 17,
          "question": "Where are the headquarters of the Pension Fund Regulatory and Development Authority (PFRDA) located?",
          "options": [
            "New Delhi",
            "Mumbai",
            "Kolkata",
            "Bengaluru"
          ],
          "correct": 0,
          "explanation": "PFRDA has its principal headquarters located in New Delhi."
        },
        {
          "id": 18,
          "question": "What is the age eligibility criteria for subscribing to the 'Atal Pension Yojana' (APY)?",
          "options": [
            "18 to 40 years",
            "21 to 50 years",
            "18 to 60 years",
            "25 to 45 years"
          ],
          "correct": 0,
          "explanation": "APY is open to all bank account holders between 18 and 40 years of age, offering a guaranteed minimum pension of ₹1,000 to ₹5,000 per month upon reaching age 60."
        },
        {
          "id": 19,
          "question": "Income taxpayers have been barred from enrolling in the Atal Pension Yojana (APY) starting from which date?",
          "options": [
            "October 1, 2022",
            "April 1, 2023",
            "January 1, 2022",
            "March 31, 2024"
          ],
          "correct": 0,
          "explanation": "The Ministry of Finance notified that any citizen who is or has been an income taxpayer shall not be eligible to join the Atal Pension Yojana post October 1, 2022."
        },
        {
          "id": 20,
          "question": "What is the maximum investment limit under the Senior Citizens Savings Scheme (SCSS) per individual as revised in 2023?",
          "options": [
            "₹30 lakh",
            "₹15 lakh",
            "₹20 lakh",
            "₹50 lakh"
          ],
          "correct": 0,
          "explanation": "The maximum deposit limit for the Senior Citizens Savings Scheme was doubled from ₹15 lakh to ₹30 lakh."
        },
        {
          "id": 21,
          "question": "What is the investment tenure of the Sovereign Gold Bond (SGB) scheme issued by the RBI on behalf of the Government?",
          "options": [
            "8 years (with exit option after 5th year)",
            "5 years",
            "10 years",
            "3 years"
          ],
          "correct": 0,
          "explanation": "SGBs have a total tenure of 8 years, with early encashment/redemption permitted after the fifth year on interest payment dates."
        },
        {
          "id": 22,
          "question": "What is the fixed annual interest rate paid to investors on the initial nominal investment value of Sovereign Gold Bonds?",
          "options": [
            "2.50% per annum payable semi-annually",
            "3.00% per annum",
            "1.50% per annum",
            "4.00% per annum"
          ],
          "correct": 0,
          "explanation": "Investors receive a guaranteed semi-annual interest of 2.50% per annum on the initial issue price, in addition to capital gains on redemption at market gold price."
        },
        {
          "id": 23,
          "question": "Capital gains tax on redemption of Sovereign Gold Bonds by an individual investor at maturity is:",
          "options": [
            "Completely exempt from tax",
            "Taxed at 10% with indexation",
            "Taxed at 20%",
            "Added to income tax slab"
          ],
          "correct": 0,
          "explanation": "Under Section 47 of the Income Tax Act, capital gains tax arising on redemption of SGB to an individual is completely exempt."
        },
        {
          "id": 24,
          "question": "Which agency in India compiles and releases the Index of Industrial Production (IIP)?",
          "options": [
            "National Statistical Office (NSO), MoSPI",
            "Office of Economic Adviser",
            "NITI Aayog",
            "Reserve Bank of India"
          ],
          "correct": 0,
          "explanation": "The NSO under the Ministry of Statistics and Programme Implementation compiles IIP monthly with 2011-12 as the base year."
        },
        {
          "id": 25,
          "question": "What is the weightage of the 'Eight Core Industries' in the Index of Industrial Production (IIP)?",
          "options": [
            "40.27%",
            "50.50%",
            "30.15%",
            "25.00%"
          ],
          "correct": 0,
          "explanation": "The Eight Core Industries (Refinery Products, Electricity, Steel, Coal, Crude Oil, Natural Gas, Cement, and Fertilizers) comprise 40.27% of total weight in IIP."
        }
      ]
    },
    "economy_may2026": {
      "id": "economy_may2026",
      "category_id": "economy",
      "category_name": "Economy, Banking & Finance",
      "month_id": "may2026",
      "month_name": "May 2026",
      "title": "Economy Current Affairs - May 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "Which of the eight core industries carries the highest individual weightage in the Index of Eight Core Industries?",
          "options": [
            "Petroleum Refinery Products (28.04%)",
            "Electricity (19.85%)",
            "Steel (17.92%)",
            "Coal (10.33%)"
          ],
          "correct": 0,
          "explanation": "Petroleum Refinery Products has the highest weight of 28.04%, followed by Electricity at 19.85% and Steel at 17.92%."
        },
        {
          "id": 2,
          "question": "Which core industry carries the lowest weightage in the Index of Eight Core Industries?",
          "options": [
            "Fertilizers (2.63%)",
            "Natural Gas (6.88%)",
            "Cement (5.37%)",
            "Crude Oil (8.98%)"
          ],
          "correct": 0,
          "explanation": "Fertilizers has the smallest weightage of 2.63% among the eight core sectors."
        },
        {
          "id": 3,
          "question": "What is the FDI limit permitted in the insurance sector in India under the automatic route?",
          "options": [
            "74%",
            "49%",
            "100%",
            "26%"
          ],
          "correct": 0,
          "explanation": "Foreign Direct Investment (FDI) in insurance companies is permitted up to 74% under the automatic approval route."
        },
        {
          "id": 4,
          "question": "What is the FDI limit allowed in defence manufacturing under the automatic route in India?",
          "options": [
            "Up to 74% (and up to 100% via government approval route for modern technology)",
            "49%",
            "100% automatic",
            "26%"
          ],
          "correct": 0,
          "explanation": "FDI in defence sector is permitted up to 74% under the automatic route and above 74% through the government route wherever modern technology is accessed."
        },
        {
          "id": 5,
          "question": "Which country was the largest source of Foreign Direct Investment (FDI) equity inflows into India during FY 2023-24 / 2025?",
          "options": [
            "Singapore",
            "Mauritius",
            "USA",
            "Netherlands"
          ],
          "correct": 0,
          "explanation": "Singapore continues to be the largest source country for FDI equity inflows into India, followed by Mauritius and the United States."
        },
        {
          "id": 6,
          "question": "Which sector attracted the highest share of Foreign Direct Investment (FDI) equity inflows in India?",
          "options": [
            "Computer Software & Hardware",
            "Services Sector",
            "Trading",
            "Telecommunications"
          ],
          "correct": 0,
          "explanation": "Computer Software and Hardware attracted the highest volume of foreign equity investments, followed by the financial and business services sector."
        },
        {
          "id": 7,
          "question": "Which Indian state received the highest share of Foreign Direct Investment (FDI) inflows?",
          "options": [
            "Maharashtra",
            "Karnataka",
            "Gujarat",
            "Tamil Nadu"
          ],
          "correct": 0,
          "explanation": "Maharashtra received the largest share of total FDI inflows in India, accounting for over 30% of total national receipts."
        },
        {
          "id": 8,
          "question": "What is the primary function of the 'Trade Receivables Discounting System' (TReDS) regulated by RBI?",
          "options": [
            "Facilitating discounting of trade receivables of MSMEs from corporate and government buyers through multiple financiers",
            "Stock market trading",
            "Currency derivative clearing",
            "Commodity hedging"
          ],
          "correct": 0,
          "explanation": "TReDS is an electronic institutional mechanism that enables MSMEs to auction and discount their trade bills against large corporates, unlocking working capital."
        },
        {
          "id": 9,
          "question": "Which organization operates the 'GeM' (Government e-Marketplace) portal for public procurement in India?",
          "options": [
            "Special Purpose Vehicle (GeM SPV) under Department of Commerce",
            "NITI Aayog",
            "Ministry of Finance",
            "NIC"
          ],
          "correct": 0,
          "explanation": "GeM is an end-to-end online marketplace facilitating transparent procurement of common use goods and services required by central and state government ministries and PSUs."
        },
        {
          "id": 10,
          "question": "What is the mandated annual procurement target from MSEs (Micro and Small Enterprises) for Central Ministries and CPSEs under the Public Procurement Policy?",
          "options": [
            "25% of total annual purchases (including 4% from SC/ST and 3% from Women entrepreneurs)",
            "20%",
            "15%",
            "30%"
          ],
          "correct": 0,
          "explanation": "CPSEs and Central Ministries are mandated to procure a minimum of 25% of their total annual procurement of goods and services from Micro and Small Enterprises."
        },
        {
          "id": 11,
          "question": "What does 'PLI' stand for in the context of government industrial schemes?",
          "options": [
            "Production Linked Incentive Scheme",
            "Public Limited Investment",
            "Primary Loan Insurance",
            "Productivity Leadership Initiative"
          ],
          "correct": 0,
          "explanation": "The Production Linked Incentive (PLI) scheme provides financial incentives on incremental sales of goods manufactured in domestic units across 14 key sectors."
        },
        {
          "id": 12,
          "question": "How many strategic sectors are covered under the Government of India's flagship Production Linked Incentive (PLI) scheme?",
          "options": [
            "14 sectors",
            "10 sectors",
            "12 sectors",
            "16 sectors"
          ],
          "correct": 0,
          "explanation": "The PLI scheme covers 14 champion sectors including Mobile & Electronics, Pharmaceuticals, Automobiles & Auto Components, Telecom, and High-Efficiency Solar PV Modules."
        },
        {
          "id": 13,
          "question": "Which regulatory authority oversees credit rating agencies operating in India?",
          "options": [
            "Securities and Exchange Board of India (SEBI)",
            "Reserve Bank of India",
            "Ministry of Corporate Affairs",
            "Competition Commission of India"
          ],
          "correct": 0,
          "explanation": "SEBI regulates credit rating agencies (such as CRISIL, ICRA, CARE, and India Ratings) under the SEBI (Credit Rating Agencies) Regulations, 1999."
        },
        {
          "id": 14,
          "question": "Which credit rating agency was established in 1987 as the first credit rating agency in India?",
          "options": [
            "CRISIL (Credit Rating Information Services of India Limited)",
            "ICRA",
            "CARE",
            "ONICRA"
          ],
          "correct": 0,
          "explanation": "CRISIL, promoted by ICICI and UTI, was incorporated in 1987 as India's pioneer credit rating institution."
        },
        {
          "id": 15,
          "question": "What does 'CAMELS' rating framework used by the RBI to assess commercial banks stand for?",
          "options": [
            "Capital adequacy, Asset quality, Management, Earnings, Liquidity, and Sensitivity to market risk",
            "Cash, Assets, Margin, Equity, Liability, Solvency",
            "Credit, Audit, Management, Expense, Loans, Security",
            "Capital, Advances, Market, Efficiency, Losses, Stability"
          ],
          "correct": 0,
          "explanation": "CAMELS is an international supervisory rating system examining Capital adequacy, Asset quality, Management efficiency, Earnings ability, Liquidity position, and Sensitivity to market risk."
        },
        {
          "id": 16,
          "question": "What is the maximum guarantee cover available under the Credit Guarantee Fund Trust for Micro and Small Enterprises (CGTMSE)?",
          "options": [
            "Up to ₹5 crore per borrowing unit",
            "Up to ₹2 crore",
            "Up to ₹1 crore",
            "Up to ₹10 crore"
          ],
          "correct": 0,
          "explanation": "The Government and SIDBI enhanced the credit guarantee ceiling under CGTMSE to ₹5 crore with reduced annual guarantee fees."
        },
        {
          "id": 17,
          "question": "Who set up the Credit Guarantee Fund Trust for Micro and Small Enterprises (CGTMSE)?",
          "options": [
            "Ministry of MSME and SIDBI",
            "RBI and SBI",
            "NABARD and Ministry of Finance",
            "NITI Aayog"
          ],
          "correct": 0,
          "explanation": "CGTMSE was jointly established by the Ministry of Micro, Small and Medium Enterprises (MSME) and the Small Industries Development Bank of India (SIDBI) in 2000."
        },
        {
          "id": 18,
          "question": "Under the revised MSME classification effective July 1, 2020, what is the composite criteria for a 'Micro' enterprise?",
          "options": [
            "Investment <= ₹1 crore AND Turnover <= ₹5 crore",
            "Investment <= ₹5 crore AND Turnover <= ₹25 crore",
            "Investment <= ₹25 lakh AND Turnover <= ₹1 crore",
            "Investment <= ₹2 crore"
          ],
          "correct": 0,
          "explanation": "Micro enterprises are defined by Investment in Plant & Machinery <= ₹1 crore and Annual Turnover <= ₹5 crore."
        },
        {
          "id": 19,
          "question": "What is the composite criteria for a 'Small' enterprise under the official MSME classification?",
          "options": [
            "Investment <= ₹10 crore AND Turnover <= ₹50 crore",
            "Investment <= ₹5 crore AND Turnover <= ₹25 crore",
            "Investment <= ₹20 crore AND Turnover <= ₹100 crore",
            "Investment <= ₹15 crore"
          ],
          "correct": 0,
          "explanation": "Small enterprises are defined by Investment in Plant & Machinery <= ₹10 crore and Annual Turnover <= ₹50 crore."
        },
        {
          "id": 20,
          "question": "What is the composite criteria for a 'Medium' enterprise under the official MSME definition?",
          "options": [
            "Investment <= ₹50 crore AND Turnover <= ₹250 crore",
            "Investment <= ₹20 crore AND Turnover <= ₹100 crore",
            "Investment <= ₹100 crore AND Turnover <= ₹500 crore",
            "Investment <= ₹25 crore"
          ],
          "correct": 0,
          "explanation": "Medium enterprises are defined by Investment in Plant & Machinery <= ₹50 crore and Annual Turnover <= ₹250 crore."
        },
        {
          "id": 21,
          "question": "Which portal is the single online registration platform for obtaining an MSME certificate in India?",
          "options": [
            "Udyam Registration Portal",
            "Udyog Aadhaar Portal",
            "Jan Samarth",
            "MSME Databank"
          ],
          "correct": 0,
          "explanation": "Udyam Registration is the sole zero-fee, paperless government portal for formal registration of MSMEs based on self-declaration and Aadhaar/PAN integration."
        },
        {
          "id": 22,
          "question": "Which organization publishes the Global Economic Prospects report biannually in January and June?",
          "options": [
            "The World Bank",
            "International Monetary Fund",
            "OECD",
            "World Economic Forum"
          ],
          "correct": 0,
          "explanation": "The World Bank issues the Global Economic Prospects report examining global economic growth dynamics and emerging market debt trends."
        },
        {
          "id": 23,
          "question": "Which organization releases the 'World Economic Outlook' (WEO) report twice a year?",
          "options": [
            "International Monetary Fund (IMF)",
            "World Bank",
            "WTO",
            "UNCTAD"
          ],
          "correct": 0,
          "explanation": "The IMF publishes the World Economic Outlook in April and October with growth updates in January and July."
        },
        {
          "id": 24,
          "question": "Which institution publishes the 'Trade and Development Report'?",
          "options": [
            "UNCTAD (United Nations Conference on Trade and Development)",
            "WTO",
            "World Bank",
            "International Chamber of Commerce"
          ],
          "correct": 0,
          "explanation": "UNCTAD publishes the annual Trade and Development Report analyzing global trade trends, macroeconomics, and development strategies."
        },
        {
          "id": 25,
          "question": "Where are the headquarters of the New Development Bank (NDB / BRICS Bank) located?",
          "options": [
            "Shanghai, China",
            "Beijing, China",
            "Johannesburg, South Africa",
            "Moscow, Russia"
          ],
          "correct": 0,
          "explanation": "The New Development Bank established by BRICS member states in 2014 is headquartered in Shanghai, China."
        }
      ]
    },
    "economy_jun2026": {
      "id": "economy_jun2026",
      "category_id": "economy",
      "category_name": "Economy, Banking & Finance",
      "month_id": "jun2026",
      "month_name": "June 2026",
      "title": "Economy Current Affairs - June 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "According to the RBI Financial Stability Report released in June 2026, the Gross Non-Performing Assets (GNPA) ratio of Scheduled Commercial Banks fell to what multi-year low?",
          "options": [
            "2.8%",
            "3.5%",
            "4.2%",
            "2.0%"
          ],
          "correct": 0,
          "explanation": "The Gross NPA ratio of commercial banks declined to a 12-year low of 2.8% by March 2024/2026, highlighting the robust health of the Indian banking balance sheet."
        },
        {
          "id": 2,
          "question": "What was the Net Non-Performing Assets (NNPA) ratio of Scheduled Commercial Banks recorded in the RBI Financial Stability Report?",
          "options": [
            "0.6%",
            "1.2%",
            "1.5%",
            "0.9%"
          ],
          "correct": 0,
          "explanation": "The Net NPA ratio of banks dropped to 0.6%, reflecting strong provisioning coverage and sustained asset quality improvements."
        },
        {
          "id": 3,
          "question": "What is the Provisioning Coverage Ratio (PCR) maintained by Indian scheduled commercial banks as per RBI data?",
          "options": [
            "Over 76%",
            "60%",
            "65%",
            "70%"
          ],
          "correct": 0,
          "explanation": "The banking system's Provisioning Coverage Ratio stood healthy at over 76%, safeguarding lenders against potential credit shocks."
        },
        {
          "id": 4,
          "question": "International credit rating agency S&P Global Ratings revised its sovereign rating outlook for India from 'Stable' to what in mid-2026?",
          "options": [
            "Positive (BBB- with Positive Outlook)",
            "Negative",
            "Under Review",
            "Upgraded to AAA"
          ],
          "correct": 0,
          "explanation": "S&P upgraded India's outlook from Stable to Positive on robust economic growth, sound macroeconomic fundamentals, and narrowing fiscal deficit."
        },
        {
          "id": 5,
          "question": "What is India's sovereign credit rating assigned by major global rating agencies (Moody's, S&P, Fitch)?",
          "options": [
            "Lowest investment grade (Baa3 by Moody's; BBB- by S&P and Fitch)",
            "Junk bond status",
            "A+ grade",
            "BB+ speculative"
          ],
          "correct": 0,
          "explanation": "India is currently rated at the lowest investment grade—Baa3 by Moody's and BBB- by S&P and Fitch—with an outlook reflecting positive upward trajectory."
        },
        {
          "id": 6,
          "question": "What does 'G-Sec' stand for in Indian financial markets?",
          "options": [
            "Government Securities",
            "General Securities",
            "Global Securities",
            "Guaranteed Securities"
          ],
          "correct": 0,
          "explanation": "Government Securities (G-Secs) are tradable sovereign instruments issued by the RBI on behalf of the Government to finance fiscal deficit."
        },
        {
          "id": 7,
          "question": "Which global bond index formally included Indian Government Bonds (FAR - Fully Accessible Route securities) starting June 2026?",
          "options": [
            "J.P. Morgan Government Bond Index-Emerging Markets (GBI-EM)",
            "Bloomberg Global Aggregate",
            "FTSE World Government Bond Index",
            "Citigroup World Bond Index"
          ],
          "correct": 0,
          "explanation": "J.P. Morgan officially began phased inclusion of Indian G-Secs in its flagship GBI-EM Global Diversified suite, unlocking billions in foreign debt inflows."
        },
        {
          "id": 8,
          "question": "What is the maximum targeted weightage of Indian Government Bonds in the J.P. Morgan GBI-EM index upon full inclusion?",
          "options": [
            "10% (reached at 1% per month over 10 months)",
            "5%",
            "15%",
            "7.5%"
          ],
          "correct": 0,
          "explanation": "Indian bonds are capped at the maximum index weight of 10%, phasing in at 1% weight addition each month over a 10-month period."
        },
        {
          "id": 9,
          "question": "What is the 'Fully Accessible Route' (FAR) introduced by the RBI in 2020?",
          "options": [
            "A channel allowing non-residents to invest in specified government securities without any quantitative limits",
            "A scheme for foreign equity IPOs",
            "A zero-tax crypto gateway",
            "A cross-border road corridor"
          ],
          "correct": 0,
          "explanation": "The FAR scheme designates specific government dated securities as eligible for unlimited foreign portfolio investment."
        },
        {
          "id": 10,
          "question": "What is the 'RBI Retail Direct' scheme launched to encourage individual investors in government debt?",
          "options": [
            "A portal allowing retail individual investors to directly open Gilt Securities Accounts (RDG Accounts) with RBI to buy G-Secs, T-Bills, and SGBs",
            "A retail shopping app",
            "A consumer loan portal",
            "A credit card platform"
          ],
          "correct": 0,
          "explanation": "RBI Retail Direct enables individual retail investors to open free Gilt accounts directly with the Reserve Bank and participate in primary auctions and secondary trading without intermediaries."
        },
        {
          "id": 11,
          "question": "What is the 'NDS-OM' platform operated by the Clearing Corporation of India Limited (CCIL)?",
          "options": [
            "Negotiated Dealing System-Order Matching (electronic trading platform for government securities)",
            "National Derivatives Settlement",
            "New Deposit Scheme",
            "National Debt System"
          ],
          "correct": 0,
          "explanation": "NDS-OM is the screen-based electronic anonymous order-matching system for trading in government securities in the secondary market."
        },
        {
          "id": 12,
          "question": "Who acts as the Central Counterparty (CCP) for clearing and settlement of trades in G-Secs, money market instruments, and foreign exchange in India?",
          "options": [
            "Clearing Corporation of India Limited (CCIL)",
            "National Securities Clearing Corporation (NSCCL)",
            "Indian Clearing Corporation (ICCL)",
            "RBI directly"
          ],
          "correct": 0,
          "explanation": "CCIL, set up in 2001, provides guaranteed clearing and settlement for transactions in Government securities, repos, interest rate derivatives, and forex."
        },
        {
          "id": 13,
          "question": "What is the minimum maturity period for Commercial Paper (CP) issued in the Indian money market?",
          "options": [
            "7 days",
            "15 days",
            "30 days",
            "1 day"
          ],
          "correct": 0,
          "explanation": "Commercial Paper (CP) is an unsecured money market instrument issued as a promissory note with a minimum maturity of 7 days and maximum of up to one year."
        },
        {
          "id": 14,
          "question": "What is the minimum denomination of Commercial Paper (CP) in India?",
          "options": [
            "₹5 lakh and multiples thereof",
            "₹1 lakh",
            "₹10 lakh",
            "₹25,000"
          ],
          "correct": 0,
          "explanation": "Commercial Paper is issued in denominations of ₹5 lakh and multiples thereof to eligible corporate borrowers and primary dealers."
        },
        {
          "id": 15,
          "question": "What is a 'Certificate of Deposit' (CD) and who can issue it in India?",
          "options": [
            "A negotiable money market instrument issued by Scheduled Commercial Banks and select All-India Financial Institutions",
            "Issued by private corporates",
            "Issued by RBI only",
            "Issued by local co-operative societies only"
          ],
          "correct": 0,
          "explanation": "Certificates of Deposit are negotiable short-term instruments issued in demat form by commercial banks for funds deposited for a specified time period."
        },
        {
          "id": 16,
          "question": "What is the minimum maturity period of a Certificate of Deposit (CD) issued by commercial banks in India?",
          "options": [
            "7 days",
            "15 days",
            "30 days",
            "90 days"
          ],
          "correct": 0,
          "explanation": "CDs issued by banks have a minimum tenor of 7 days and a maximum tenor of up to one year."
        },
        {
          "id": 17,
          "question": "What is 'Call Money' in the Indian inter-bank money market?",
          "options": [
            "Borrowing or lending of funds on an overnight (one-day) basis",
            "Borrowing for 2 to 14 days",
            "Borrowing for more than 14 days",
            "Borrowing for 1 year"
          ],
          "correct": 0,
          "explanation": "Call Money refers to inter-bank funds borrowed or lent for one single day (overnight). Funds for 2 to 14 days are called Notice Money; beyond 14 days is Term Money."
        },
        {
          "id": 18,
          "question": "What is 'Notice Money' in the money market?",
          "options": [
            "Funds borrowed or lent for a period between 2 days and 14 days",
            "Overnight money",
            "Funds for 30 days",
            "Term money for 1 year"
          ],
          "correct": 0,
          "explanation": "In inter-bank money market parlance, borrowing or lending of funds for a duration spanning 2 to 14 days is termed Notice Money."
        },
        {
          "id": 19,
          "question": "What is 'Term Money' in the Indian financial market?",
          "options": [
            "Funds borrowed or lent for a maturity period exceeding 14 days (up to 1 year)",
            "Overnight lending",
            "7-day lending",
            "3-day lending"
          ],
          "correct": 0,
          "explanation": "Borrowing or lending of market funds for tenors greater than 14 days and up to one year is classified as Term Money."
        },
        {
          "id": 20,
          "question": "What is a 'Tri-Party Repo' (TREPS) introduced in the Indian money market?",
          "options": [
            "A repo contract where a third entity (CCIL) acts as an intermediary between borrower and lender for collateral management and settlement",
            "A 3-bank syndicate loan",
            "A loan involving international banks",
            "A loan to three state governments"
          ],
          "correct": 0,
          "explanation": "TREPS is a facilitated repo transaction where CCIL manages collateral, margins, and settlements between borrowing and lending institutions."
        },
        {
          "id": 21,
          "question": "Which body fixes the Maximum Retail Price (MRP) and ceiling prices of essential medicines in India?",
          "options": [
            "National Pharmaceutical Pricing Authority (NPPA)",
            "Drug Controller General of India (DCGI)",
            "Ministry of Health",
            "Medical Council of India"
          ],
          "correct": 0,
          "explanation": "NPPA, an attached office of the Department of Pharmaceuticals, fixes and revises prices of controlled drugs and medical devices under the DPCO 2013."
        },
        {
          "id": 22,
          "question": "What does 'DPCO' stand for in pharmaceutical regulation?",
          "options": [
            "Drugs (Prices Control) Order",
            "Direct Pharmaceutical Clearing Order",
            "Drug Production Control Office",
            "Department of Pharmaceutical Commerce"
          ],
          "correct": 0,
          "explanation": "The Drugs (Prices Control) Order is an order issued by the Central Government under Section 3 of the Essential Commodities Act, 1955, to regulate prices of essential formulations."
        },
        {
          "id": 23,
          "question": "Under which statutory Act does the Central Government declare commodities as 'Essential Commodities'?",
          "options": [
            "Essential Commodities Act, 1955",
            "Consumer Protection Act, 2019",
            "Sale of Goods Act, 1930",
            "FSSAI Act, 2006"
          ],
          "correct": 0,
          "explanation": "The Essential Commodities Act, 1955 empowers the government to regulate the production, supply, and distribution of essential goods to prevent hoarding and black-marketing."
        },
        {
          "id": 24,
          "question": "What is 'Minimum Support Price' (MSP) and who recommends it to the Government of India?",
          "options": [
            "Commission for Agricultural Costs and Prices (CACP)",
            "NITI Aayog",
            "Food Corporation of India (FCI)",
            "NABARD"
          ],
          "correct": 0,
          "explanation": "CACP, an attached office of the Ministry of Agriculture, recommends MSPs for 22 mandated crops and Fair & Remunerative Price (FRP) for sugarcane."
        },
        {
          "id": 25,
          "question": "How many mandated crops are covered under the Minimum Support Price (MSP) framework recommended by CACP?",
          "options": [
            "22 mandated crops (plus Fair & Remunerative Price for sugarcane)",
            "25 crops",
            "18 crops",
            "20 crops"
          ],
          "correct": 0,
          "explanation": "CACP recommends MSPs for 22 mandated agricultural crops (14 Kharif, 6 Rabi, and 2 commercial crops) along with FRP for sugarcane."
        }
      ]
    },
    "economy_jul2026": {
      "id": "economy_jul2026",
      "category_id": "economy",
      "category_name": "Economy, Banking & Finance",
      "month_id": "jul2026",
      "month_name": "July 2026",
      "title": "Economy Current Affairs - July 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "What was the major change in Long Term Capital Gains (LTCG) tax rate on financial assets announced in the Union Budget?",
          "options": [
            "Increased from 10% to 12.5%",
            "Increased to 15%",
            "Reduced to 7.5%",
            "Remained unchanged at 10%"
          ],
          "correct": 0,
          "explanation": "The Union Budget rationalized capital gains: Long Term Capital Gains (LTCG) on financial and non-financial assets was unified at 12.5%."
        },
        {
          "id": 2,
          "question": "What was the revised Short Term Capital Gains (STCG) tax rate on specified listed financial assets under Section 111A?",
          "options": [
            "Increased from 15% to 20%",
            "Increased to 25%",
            "Reduced to 10%",
            "Remained at 15%"
          ],
          "correct": 0,
          "explanation": "STCG tax on specified equity and equity-oriented mutual fund units was increased from 15% to 20%."
        },
        {
          "id": 3,
          "question": "What was the enhanced exemption limit for Long Term Capital Gains (LTCG) on listed equity shares per financial year?",
          "options": [
            "Increased from ₹1 lakh to ₹1.25 lakh",
            "Increased to ₹1.5 lakh",
            "Increased to ₹2 lakh",
            "Removed completely"
          ],
          "correct": 0,
          "explanation": "The annual tax exemption limit for aggregate LTCG from equity shares and equity mutual funds was enhanced from ₹1,00,000 to ₹1,25,000."
        },
        {
          "id": 4,
          "question": "What change was made to the Securities Transaction Tax (STT) on Futures and Options (F&O) in the Budget?",
          "options": [
            "Increased to 0.02% on futures and 0.1% on options premium",
            "Decreased by half",
            "Abolished completely",
            "Doubled on cash delivery"
          ],
          "correct": 0,
          "explanation": "To curb speculative retail trading in equity derivatives, STT on futures was hiked to 0.02% and on options to 0.1%."
        },
        {
          "id": 5,
          "question": "The corporate tax rate on foreign companies operating in India was reduced from 40% to what percentage in the Budget?",
          "options": [
            "35%",
            "30%",
            "25%",
            "22%"
          ],
          "correct": 0,
          "explanation": "To attract foreign capital and multinational corporations, the corporate income tax rate on foreign companies was lowered from 40% to 35%."
        },
        {
          "id": 6,
          "question": "What is the basic customs duty on critical minerals like Lithium, Copper, Nickel, and Cobalt modified to in the Budget?",
          "options": [
            "Fully exempted (0% customs duty)",
            "Reduced to 2.5%",
            "Reduced to 5%",
            "Raised to 10%"
          ],
          "correct": 0,
          "explanation": "The government fully exempted basic customs duty on 25 critical minerals (including lithium, copper, nickel, cobalt, and rare earths) to boost clean energy tech."
        },
        {
          "id": 7,
          "question": "What financial allocation was dedicated to agriculture and allied sectors in the Union Budget for FY 2024-25 / 2026?",
          "options": [
            "₹1.52 lakh crore",
            "₹1.20 lakh crore",
            "₹2.00 lakh crore",
            "₹95,000 crore"
          ],
          "correct": 0,
          "explanation": "The Union Finance Minister earmarked ₹1.52 lakh crore for agriculture and allied sectors to drive farmer welfare, natural farming, and digital public infrastructure."
        },
        {
          "id": 8,
          "question": "Under the 'Digital Public Infrastructure (DPI) for Agriculture', coverage for how many farmers and their lands was announced for digital crop survey?",
          "options": [
            "Digital crop survey for 6 crore farmers across 400 districts",
            "1 crore farmers",
            "10 crore farmers",
            "2 crore farmers"
          ],
          "correct": 0,
          "explanation": "The Budget announced implementation of DPI in agriculture in partnership with states to conduct digital crop surveys for 6 crore farmers."
        },
        {
          "id": 9,
          "question": "What is the total allocation provided for the Ministry of Defence in the Union Budget, maintaining its position as the highest allocated ministry?",
          "options": [
            "₹6.22 lakh crore",
            "₹5.50 lakh crore",
            "₹7.10 lakh crore",
            "₹4.80 lakh crore"
          ],
          "correct": 0,
          "explanation": "The Ministry of Defence received the highest allocation of ₹6.22 lakh crore, constituting 13% of the total Union Budget expenditure."
        },
        {
          "id": 10,
          "question": "What percentage of the defence capital acquisition budget is reserved for procurement from domestic defense industries?",
          "options": [
            "75%",
            "68%",
            "50%",
            "85%"
          ],
          "correct": 0,
          "explanation": "The Defence Ministry earmarked 75% of its capital modernisation budget for domestic procurement under the Atmanirbhar Bharat initiative."
        },
        {
          "id": 11,
          "question": "What is the allocation announced for the Ministry of Railways in the Union Budget?",
          "options": [
            "₹2.52 lakh crore (record capital expenditure)",
            "₹1.80 lakh crore",
            "₹3.00 lakh crore",
            "₹2.00 lakh crore"
          ],
          "correct": 0,
          "explanation": "Indian Railways was allocated a record capital outlay of ₹2.52 lakh crore to upgrade passenger safety, build dedicated freight corridors, and deploy Kavach."
        },
        {
          "id": 12,
          "question": "What is 'Kavach' developed indigenously by Indian Railways?",
          "options": [
            "An Automatic Train Protection (ATP) system to prevent train collisions",
            "A high-speed luxury coach",
            "A rail bridge monitoring app",
            "A ticketing platform"
          ],
          "correct": 0,
          "explanation": "Kavach is an indigenously developed SIL-4 certified Automatic Train Protection system designed to avert signal passing at danger and head-on collisions."
        },
        {
          "id": 13,
          "question": "Which organization developed the indigenous Kavach train protection technology?",
          "options": [
            "Research Designs and Standards Organisation (RDSO), Lucknow",
            "IIT Delhi",
            "BHEL",
            "COFMOW"
          ],
          "correct": 0,
          "explanation": "Kavach was designed and tested by the Research Designs and Standards Organisation (RDSO) in collaboration with Indian technology partners."
        },
        {
          "id": 14,
          "question": "What is the primary aim of the PM GatiShakti National Master Plan?",
          "options": [
            "Multi-modal connectivity infrastructure to reduce logistics costs and break departmental silos",
            "Free internet for rural areas",
            "Subsidized cargo ships",
            "Privatizing major ports"
          ],
          "correct": 0,
          "explanation": "PM GatiShakti brings 16 ministries together on a GIS platform for synchronized planning and execution of multi-modal connectivity projects."
        },
        {
          "id": 15,
          "question": "What is the target for India's logistics cost as a percentage of GDP under the National Logistics Policy?",
          "options": [
            "Reduce from 13-14% to single digits (around 8%) by 2030",
            "5%",
            "10%",
            "12%"
          ],
          "correct": 0,
          "explanation": "The National Logistics Policy aims to reduce logistics costs to global benchmarks (around 8% of GDP) to enhance trade competitiveness."
        },
        {
          "id": 16,
          "question": "Which international index published by the World Bank evaluates national logistics performance, where India improved to 38th rank?",
          "options": [
            "Logistics Performance Index (LPI)",
            "Global Competitiveness Index",
            "Ease of Doing Business",
            "Enabling Trade Index"
          ],
          "correct": 0,
          "explanation": "India moved up to 38th position out of 139 nations in the World Bank's Logistics Performance Index (LPI), driven by port modernization and digitalization."
        },
        {
          "id": 17,
          "question": "Which major container transshipment port in Kerala commenced commercial operations in July 2026?",
          "options": [
            "Vizhinjam International Transshipment Deepwater Multipurpose Seaport",
            "Kochi Port",
            "Kollam Port",
            "Beypore Port"
          ],
          "correct": 0,
          "explanation": "Vizhinjam International Seaport in Thiruvananthapuram, Kerala, developed by Adani Ports, welcomed its first mother vessels, positioning India as a global bunkering hub."
        },
        {
          "id": 18,
          "question": "What is the natural draft depth of the Vizhinjam International Seaport, enabling it to berth the world's largest ultra-large container vessels?",
          "options": [
            "Over 18 to 20 metres natural depth",
            "12 metres",
            "14 metres",
            "10 metres"
          ],
          "correct": 0,
          "explanation": "Vizhinjam boasts a natural water depth of up to 20 metres, requiring minimal dredging and allowing 24,000+ TEU mega container vessels to dock directly."
        },
        {
          "id": 19,
          "question": "Which Indian port was renamed as 'Syama Prasad Mookerjee Port' in 2020?",
          "options": [
            "Kolkata Port Trust",
            "Kandla Port",
            "Tuticorin Port",
            "Paradip Port"
          ],
          "correct": 0,
          "explanation": "Kolkata Port Trust, India's oldest operational riverine port, was rechristened as Syama Prasad Mookerjee Port on its 150th anniversary."
        },
        {
          "id": 20,
          "question": "Which Indian port was rechristened as 'Deendayal Port'?",
          "options": [
            "Kandla Port (Gujarat)",
            "Mormugao Port",
            "JNPA Mumbai",
            "Ennore Port"
          ],
          "correct": 0,
          "explanation": "Kandla Port in Kutch, Gujarat, was officially renamed Deendayal Port in honor of Pandit Deendayal Upadhyaya."
        },
        {
          "id": 21,
          "question": "Which port was named as 'V.O. Chidambaranar Port'?",
          "options": [
            "Tuticorin Port (Tamil Nadu)",
            "Cochin Port",
            "Mangalore Port",
            "Chennai Port"
          ],
          "correct": 0,
          "explanation": "The Major Port of Tuticorin was renamed V.O. Chidambaranar Port in memory of the freedom fighter who pioneered indigenous merchant shipping."
        },
        {
          "id": 22,
          "question": "How many 'Major Ports' are there in India under the administrative jurisdiction of the Central Government?",
          "options": [
            "12 Major Ports (plus Vadhavan Port approved as the 13th)",
            "10 Major Ports",
            "14 Major Ports",
            "8 Major Ports"
          ],
          "correct": 0,
          "explanation": "There are 12 operational Major Ports in India, with the Union Cabinet giving approval for the 13th major greenfield port at Vadhavan in Maharashtra."
        },
        {
          "id": 23,
          "question": "Where is the newly approved ₹76,220 crore greenfield mega port project 'Vadhavan Port' located?",
          "options": [
            "Palghar district, Maharashtra",
            "Sindhudurg, Maharashtra",
            "Bharuch, Gujarat",
            "Udupi, Karnataka"
          ],
          "correct": 0,
          "explanation": "The all-weather Vadhavan deep-water port is located in Palghar district, Maharashtra, designed to rank among the top 10 container ports globally."
        },
        {
          "id": 24,
          "question": "What is the equity shareholding structure in the Vadhavan Port Project SPV?",
          "options": [
            "JNPA holds 74% and Maharashtra Maritime Board (MMB) holds 26%",
            "Centre 100%",
            "Private concessionaire 51%",
            "JNPA 50% and Adani 50%"
          ],
          "correct": 0,
          "explanation": "The project is developed by Vadhavan Port Project Limited (VPPL), an SPV formed by Jawaharlal Nehru Port Authority (74%) and Maharashtra Maritime Board (26%)."
        },
        {
          "id": 25,
          "question": "Which port is the largest container handling port in India, accounting for over 50% of the nation's total containerized cargo?",
          "options": [
            "Jawaharlal Nehru Port Authority (JNPA) / Nhava Sheva",
            "Chennai Port",
            "Mundra Port only",
            "Visakhapatnam Port"
          ],
          "correct": 0,
          "explanation": "JNPA (Nhava Sheva) in Navi Mumbai is the premier public container port in India, achieving record throughput of over 6.4 million TEUs."
        }
      ]
    },
    "economy_aug2026": {
      "id": "economy_aug2026",
      "category_id": "economy",
      "category_name": "Economy, Banking & Finance",
      "month_id": "aug2026",
      "month_name": "August 2026",
      "title": "Economy Current Affairs - August 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "The Reserve Bank of India in its August 2026 Monetary Policy Committee (MPC) review projected India's real GDP growth for FY 2024-25 / 2026-27 at what rate?",
          "options": [
            "7.2%",
            "6.5%",
            "6.8%",
            "7.5%"
          ],
          "correct": 0,
          "explanation": "The RBI projected real GDP growth at 7.2% with balanced risks, driven by rural demand recovery and high manufacturing capacity utilization."
        },
        {
          "id": 2,
          "question": "What retail CPI inflation projection did the RBI maintain for the full fiscal year in August 2026?",
          "options": [
            "4.5%",
            "4.0%",
            "5.1%",
            "3.8%"
          ],
          "correct": 0,
          "explanation": "The RBI estimated retail headline CPI inflation at 4.5% for the year, anticipating favourable monsoon impact on food prices."
        },
        {
          "id": 3,
          "question": "What is the total Assets Under Management (AUM) crossed by the National Pension System (NPS) and Atal Pension Yojana as of August 2026?",
          "options": [
            "Over ₹12.5 lakh crore",
            "₹10 lakh crore",
            "₹8 lakh crore",
            "₹15 lakh crore"
          ],
          "correct": 0,
          "explanation": "PFRDA announced that aggregate pension assets under management under NPS and APY crossed ₹12.5 lakh crore, reflecting rapid growth in non-government corporate subscribers."
        },
        {
          "id": 4,
          "question": "What is the minimum pension guaranteed under the Unified Pension Scheme (UPS) approved by the Union Cabinet in August 2026 for central government employees?",
          "options": [
            "₹10,000 per month for employees with minimum 10 years of service",
            "₹5,000 per month",
            "₹15,000 per month",
            "₹7,500 per month"
          ],
          "correct": 0,
          "explanation": "The Union Cabinet approved the Unified Pension Scheme (UPS) ensuring an assured minimum pension of ₹10,000 per month for central employees with at least 10 years of service."
        },
        {
          "id": 5,
          "question": "Under the Unified Pension Scheme (UPS), what percentage of average basic pay drawn over the last 12 months is guaranteed as an assured pension?",
          "options": [
            "50% of average basic pay for minimum 25 years of qualifying service",
            "40%",
            "60%",
            "33%"
          ],
          "correct": 0,
          "explanation": "Under UPS, employees with at least 25 years of service receive an assured pension of 50% of the average basic pay drawn in the last 12 months prior to superannuation."
        },
        {
          "id": 6,
          "question": "Under the Unified Pension Scheme (UPS), what is the increased contribution rate of the Central Government towards employees' pension?",
          "options": [
            "Increased from 14% to 18.5%",
            "Increased from 10% to 14%",
            "Increased to 20%",
            "Remains 14%"
          ],
          "correct": 0,
          "explanation": "The Central Government increased its contribution from 14% to 18.5% of basic pay + DA under the UPS framework, while employee contribution remains unchanged at 10%."
        },
        {
          "id": 7,
          "question": "From which date will the Unified Pension Scheme (UPS) take effect for Central Government employees?",
          "options": [
            "April 1, 2025 / 2026",
            "January 1, 2025",
            "August 15, 2025",
            "October 2, 2025"
          ],
          "correct": 0,
          "explanation": "The Unified Pension Scheme takes effect from April 1, offering employees the choice to opt between NPS and the new assured UPS."
        },
        {
          "id": 8,
          "question": "Who chaired the committee constituted by the Finance Ministry to review the pension system that led to the formulation of UPS?",
          "options": [
            "Dr. T.V. Somanathan (former Finance Secretary)",
            "Dr. Arvind Panagariya",
            "Dr. Bibek Debroy",
            "Shri N.K. Singh"
          ],
          "correct": 0,
          "explanation": "The committee was chaired by Dr. T.V. Somanathan (then Finance Secretary, later appointed Cabinet Secretary of India)."
        },
        {
          "id": 9,
          "question": "What is the family pension percentage assured to the spouse of a deceased employee under the Unified Pension Scheme (UPS)?",
          "options": [
            "60% of the pension of the employee immediately before his or her demise",
            "50%",
            "75%",
            "100%"
          ],
          "correct": 0,
          "explanation": "Under UPS, an assured family pension at the rate of 60% of the employee's pension is provided to the spouse upon the pensioner's demise."
        },
        {
          "id": 10,
          "question": "What indexation benefit is provided to pensioners under the Unified Pension Scheme (UPS)?",
          "options": [
            "Dearness Relief indexation based on All India Consumer Price Index for Industrial Workers (AICPI-IW)",
            "No indexation",
            "Fixed 3% annual hike",
            "CPI Urban indexation"
          ],
          "correct": 0,
          "explanation": "Pensions under UPS feature Dearness Relief indexation linked to AICPI-IW, mirroring the inflation-protection of the Old Pension Scheme (OPS)."
        },
        {
          "id": 11,
          "question": "Which organization releases the All India Consumer Price Index for Industrial Workers (CPI-IW)?",
          "options": [
            "Labour Bureau, Ministry of Labour and Employment",
            "National Statistical Office",
            "RBI",
            "Ministry of Commerce"
          ],
          "correct": 0,
          "explanation": "The Labour Bureau, an attached office of the Ministry of Labour & Employment, compiles and releases CPI-IW with base year 2016 = 100."
        },
        {
          "id": 12,
          "question": "Where are the headquarters of the Labour Bureau located?",
          "options": [
            "Shimla / Chandigarh",
            "New Delhi",
            "Kolkata",
            "Mumbai"
          ],
          "correct": 0,
          "explanation": "The Labour Bureau functions with operational headquarters at Chandigarh and Shimla, responsible for industrial wages and consumer price index series."
        },
        {
          "id": 13,
          "question": "What is the base year currently used for the Consumer Price Index for Agricultural Labourers (CPI-AL)?",
          "options": [
            "1986-87 = 100",
            "2004-05 = 100",
            "2011-12 = 100",
            "2016 = 100"
          ],
          "correct": 0,
          "explanation": "CPI for Agricultural Labourers (CPI-AL) and Rural Labourers (CPI-RL) are compiled by the Labour Bureau with base year 1986-87 = 100."
        },
        {
          "id": 14,
          "question": "What is the minimum wages revision mechanism used by the Central Government under the Code on Wages, 2019?",
          "options": [
            "National Floor Minimum Wage",
            "Discretionary state ceiling",
            "Poverty line index",
            "Fixed ₹200 daily rate"
          ],
          "correct": 0,
          "explanation": "The Code on Wages empowers the Central Government to determine a statutory National Floor Minimum Wage, below which no State Government can set minimum wages."
        },
        {
          "id": 15,
          "question": "How many central labour laws were consolidated and subsumed into the Four Labour Codes?",
          "options": [
            "29 central labour laws",
            "44 labour laws",
            "15 labour laws",
            "35 labour laws"
          ],
          "correct": 0,
          "explanation": "The Government of India simplified 29 existing central labour enactments into four streamlined codes: Wages, Social Security, Industrial Relations, and OSH."
        },
        {
          "id": 16,
          "question": "What are the names of the Four Labour Codes enacted by Parliament?",
          "options": [
            "Code on Wages; Industrial Relations Code; Social Security Code; Occupational Safety, Health & Working Conditions Code",
            "Labour Code 1, 2, 3, 4",
            "Employment Code, Factory Code, Wage Code, Pension Code",
            "National Worker Codes"
          ],
          "correct": 0,
          "explanation": "The Four Labour Codes are: Code on Wages (2019), Industrial Relations Code (2020), Code on Social Security (2020), and OSH&WC Code (2020)."
        },
        {
          "id": 17,
          "question": "Under the Code on Social Security, 2020, what novel category of non-traditional workers was granted statutory social security recognition for the first time?",
          "options": [
            "Gig workers and Platform workers",
            "Government tenured staff",
            "Corporate CEOs",
            "Foreign diplomatic staff"
          ],
          "correct": 0,
          "explanation": "The Code on Social Security legally recognized gig workers and platform workers, mandating a Social Security Fund financed by platform aggregators (1-2% of turnover)."
        },
        {
          "id": 18,
          "question": "Which state in India enacted the pioneering 'Platform Based Gig Workers (Registration and Welfare) Act' in 2023?",
          "options": [
            "Rajasthan",
            "Karnataka",
            "Maharashtra",
            "Kerala"
          ],
          "correct": 0,
          "explanation": "Rajasthan became the first state in India to pass dedicated legislation setting up a Welfare Board and social security cess for platform gig workers."
        },
        {
          "id": 19,
          "question": "Which state announced a ₹5 lakh accidental and life insurance scheme for gig workers in 2023-24 / 2026?",
          "options": [
            "Karnataka and Telangana",
            "Punjab",
            "Bihar",
            "Uttar Pradesh"
          ],
          "correct": 0,
          "explanation": "Southern states including Karnataka and Telangana rolled out dedicated social security insurance covers for registered gig and delivery personnel."
        },
        {
          "id": 20,
          "question": "What is the primary function of the 'e-Shram' portal developed by the Ministry of Labour and Employment?",
          "options": [
            "Creating a comprehensive national database of unorganized workers seeded with Aadhaar",
            "Stock market trading for workers",
            "Disbursing micro-loans directly",
            "Online job exams"
          ],
          "correct": 0,
          "explanation": "The e-Shram portal registers unorganized workers across informal sectors, issuing a 12-digit Universal Account Number (UAN) for delivery of welfare schemes."
        },
        {
          "id": 21,
          "question": "How many unorganized workers have registered on the e-Shram portal as of 2024-2026?",
          "options": [
            "Over 30 crore workers",
            "15 crore workers",
            "20 crore workers",
            "45 crore workers"
          ],
          "correct": 0,
          "explanation": "Over 30 crore informal and unorganized workers have enrolled on e-Shram, enabling seamless portability of social security benefits."
        },
        {
          "id": 22,
          "question": "What is the monthly contribution amount under the 'Pradhan Mantri Shram Yogi Maan-dhan' (PM-SYM) pension scheme for eligible unorganized workers?",
          "options": [
            "₹55 to ₹200 per month depending on entry age (matched 50:50 by Central Government)",
            "Fixed ₹1,000",
            "Fixed ₹500",
            "₹10 to ₹50"
          ],
          "correct": 0,
          "explanation": "PM-SYM requires a monthly voluntary contribution of ₹55 to ₹200 (age 18 to 40), with an equal 50% matching contribution by the Central Government, ensuring a ₹3,000 monthly pension."
        },
        {
          "id": 23,
          "question": "What is the guaranteed monthly pension provided under the PM-SYM scheme after attaining the age of 60 years?",
          "options": [
            "₹3,000 per month",
            "₹1,000 per month",
            "₹5,000 per month",
            "₹2,500 per month"
          ],
          "correct": 0,
          "explanation": "PM-SYM guarantees a minimum monthly pension of ₹3,000 to beneficiaries upon attaining the age of 60 years."
        },
        {
          "id": 24,
          "question": "Which agency serves as the pension fund manager and oversees pension payout for PM-SYM beneficiaries?",
          "options": [
            "Life Insurance Corporation of India (LIC)",
            "State Bank of India",
            "UTI Mutual Fund",
            "Employees' Provident Fund Organisation (EPFO)"
          ],
          "correct": 0,
          "explanation": "LIC is the designated Pension Fund Manager responsible for pension fund management and direct pension disbursements under PM-SYM."
        },
        {
          "id": 25,
          "question": "What is the statutory interest rate credited on Employees' Provident Fund (EPF) accumulations for active members?",
          "options": [
            "8.25% per annum",
            "8.15% per annum",
            "7.50% per annum",
            "8.50% per annum"
          ],
          "correct": 0,
          "explanation": "The Central Board of Trustees of EPFO recommended and the Finance Ministry ratified an 8.25% annual interest rate for EPF subscribers."
        }
      ]
    },
    "science_tech_defence_feb2026": {
      "id": "science_tech_defence_feb2026",
      "category_id": "science_tech_defence",
      "category_name": "Science, Technology & Defence",
      "month_id": "feb2026",
      "month_name": "February 2026",
      "title": "Science & Defence Current Affairs - February 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "Prime Minister Narendra Modi announced the names of the four astronaut designates for India's maiden human spaceflight mission 'Gaganyaan' in February 2026 at VSSC, Thiruvananthapuram. Who among the following is NOT one of them?",
          "options": [
            "Wing Commander Rakesh Sharma",
            "Group Captain Prashanth Balakrishnan Nair",
            "Group Captain Ajit Krishnan",
            "Wing Commander Shubhanshu Shukla"
          ],
          "correct": 0,
          "explanation": "The four selected IAF astronaut designates are Group Captain Prashanth Balakrishnan Nair, Group Captain Ajit Krishnan, Group Captain Angad Pratap, and Wing Commander Shubhanshu Shukla. (Rakesh Sharma was India's first cosmonaut in 1984)."
        },
        {
          "id": 2,
          "question": "Which IAF astronaut designate was selected to fly to the International Space Station (ISS) on the Axiom-4 (Ax-4) commercial mission with NASA?",
          "options": [
            "Wing Commander Shubhanshu Shukla",
            "Group Captain Prashanth Nair",
            "Group Captain Ajit Krishnan",
            "Group Captain Angad Pratap"
          ],
          "correct": 0,
          "explanation": "ISRO and NASA finalized that Group Captain Shubhanshu Shukla will serve as the primary mission pilot on the Axiom-4 mission to the ISS, with Prashanth Nair as backup."
        },
        {
          "id": 3,
          "question": "What was the official focal theme of National Science Day celebrated across India on February 28, 2026?",
          "options": [
            "Indigenous Technologies for Viksit Bharat",
            "Global Science for Global Wellbeing",
            "Future of STI: Impacts on Education",
            "Integrated Approach in Science and Technology"
          ],
          "correct": 0,
          "explanation": "The theme 'Indigenous Technologies for Viksit Bharat' underscored domestic scientific innovation, Atmanirbharta, and grassroots technological breakthroughs."
        },
        {
          "id": 4,
          "question": "National Science Day on February 28 commemorates which pathbreaking scientific discovery by Sir C.V. Raman in 1928?",
          "options": [
            "The Raman Effect (inelastic scattering of photons)",
            "Raman-Nath theory",
            "Cosmic rays absorption",
            "Theory of Superconductivity"
          ],
          "correct": 0,
          "explanation": "National Science Day marks the discovery of the 'Raman Effect' on February 28, 1928, for which Sir C.V. Raman was awarded the Nobel Prize in Physics in 1930."
        },
        {
          "id": 5,
          "question": "What is the financial allocation approved by the Union Cabinet for the comprehensive 'IndiaAI Mission' to build domestic compute infrastructure?",
          "options": [
            "₹10,372 crore",
            "₹5,000 crore",
            "₹15,000 crore",
            "₹8,000 crore"
          ],
          "correct": 0,
          "explanation": "The Union Cabinet approved the IndiaAI Mission with a financial outlay of ₹10,372 crore to procure 10,000+ GPUs and establish foundational multi-modal AI models."
        },
        {
          "id": 6,
          "question": "Which city hosted the mega multilateral naval exercise 'MILAN 2026' featuring navies from over 50 friendly foreign countries?",
          "options": [
            "Visakhapatnam, Andhra Pradesh",
            "Kochi, Kerala",
            "Mumbai, Maharashtra",
            "Port Blair, Andaman & Nicobar"
          ],
          "correct": 0,
          "explanation": "Exercise MILAN 2026 was hosted by the Eastern Naval Command in Visakhapatnam ('City of Destiny'), featuring sea-phase drills and an International City Parade."
        },
        {
          "id": 7,
          "question": "What was the theme of the Multilateral Naval Exercise 'MILAN 2026'?",
          "options": [
            "Forging Naval Alliances: Dynamic, Synergy, Cohesion",
            "Camaraderie, Cohesion, Collaboration",
            "Bridges of Friendship",
            "Security and Growth for All in the Region"
          ],
          "correct": 0,
          "explanation": "The core theme of MILAN 2026 centered on 'Forging Naval Alliances: Dynamic, Synergy, Cohesion' to promote maritime safety and open sea lines of communication."
        },
        {
          "id": 8,
          "question": "Which indigenous surface-to-air missile system was successfully demonstrated during Indian Air Force exercises, engaging multiple targets simultaneously?",
          "options": [
            "SAMAR (Surface to Air Missile for Assured Retaliation)",
            "Akash-NG",
            "VL-SRSAM",
            "QRSAM"
          ],
          "correct": 0,
          "explanation": "The IAF operationalized SAMAR, an indigenous short-range air defence system developed by IAF base repair depots using refurbished Vympel R-73 missiles."
        },
        {
          "id": 9,
          "question": "What is the maximum strike range of the DRDO-developed 'Akash-NG' (New Generation) surface-to-air missile system?",
          "options": [
            "Up to 70-80 km",
            "Up to 30 km",
            "Up to 150 km",
            "Up to 25 km"
          ],
          "correct": 0,
          "explanation": "Akash-NG is an advanced air defence missile with an active RF seeker, dual-pulse solid rocket motor, and an interception range of around 70-80 km."
        },
        {
          "id": 10,
          "question": "Which research institute under the Department of Atomic Energy operates the 'Dhruva' high-flux research reactor at Trombay?",
          "options": [
            "Bhabha Atomic Research Centre (BARC)",
            "Indira Gandhi Centre for Atomic Research (IGCAR)",
            "Raja Ramanna Centre (RRCAT)",
            "Variable Energy Cyclotron Centre (VECC)"
          ],
          "correct": 0,
          "explanation": "BARC in Trombay, Mumbai, operates the 100 MWth Dhruva reactor, which produces medical radioisotopes and supports basic nuclear research."
        },
        {
          "id": 11,
          "question": "Where is the Indira Gandhi Centre for Atomic Research (IGCAR) located, specializing in Fast Breeder Reactor technologies?",
          "options": [
            "Kalpakkam, Tamil Nadu",
            "Rawatbhata, Rajasthan",
            "Kudankulam, Tamil Nadu",
            "Narora, Uttar Pradesh"
          ],
          "correct": 0,
          "explanation": "IGCAR is located at Kalpakkam, south of Chennai, home to the Fast Breeder Test Reactor (FBTR) and the 500 MWe Prototype Fast Breeder Reactor (PFBR)."
        },
        {
          "id": 12,
          "question": "What nuclear fuel cycle technology does India's Fast Breeder Reactor (PFBR) at Kalpakkam utilize as part of Stage II of India's Nuclear Power Programme?",
          "options": [
            "Plutonium-239 and Uranium-238 (MOX fuel)",
            "Enriched Uranium only",
            "Natural Thorium without fissile material",
            "Heavy water with Deuterium"
          ],
          "correct": 0,
          "explanation": "Stage II utilizes Mixed Oxide (MOX) fuel of Plutonium-239 (from Stage 1 spent fuel) and Uranium-238 to breed more fissile material than it consumes."
        },
        {
          "id": 13,
          "question": "Who is regarded as the Father of India's Three-Stage Nuclear Power Programme?",
          "options": [
            "Dr. Homi Jehangir Bhabha",
            "Dr. Vikram Sarabhai",
            "Dr. APJ Abdul Kalam",
            "Dr. Raja Ramanna"
          ],
          "correct": 0,
          "explanation": "Dr. Homi Bhabha envisioned the 3-stage programme to sequentially utilize India's modest uranium reserves and vast thorium deposits (monazite sands of Kerala)."
        },
        {
          "id": 14,
          "question": "What fuel will be primarily utilized in the third stage of India's nuclear power programme to achieve long-term energy independence?",
          "options": [
            "Thorium-232 bred into Uranium-233",
            "Enriched Uranium-235",
            "Heavy water",
            "Plutonium-240"
          ],
          "correct": 0,
          "explanation": "Stage 3 focuses on Advanced Heavy Water Reactors (AHWR) using Thorium-232, which absorbs neutrons to transmute into fissile Uranium-233."
        },
        {
          "id": 15,
          "question": "Which Indian state has the largest known reserves of Thorium in its monazite beach sands?",
          "options": [
            "Kerala",
            "Andhra Pradesh",
            "Odisha",
            "Tamil Nadu"
          ],
          "correct": 0,
          "explanation": "Kerala's coastal placer sands, along with deposits in Andhra Pradesh and Odisha, contain the world's richest monazite sands yielding thorium."
        },
        {
          "id": 16,
          "question": "Which propulsion module does the launch vehicle LVM3 (Geosynchronous Satellite Launch Vehicle Mk III) use for its cryogenic upper stage?",
          "options": [
            "CE-20 Cryogenic Engine",
            "Vikas Engine",
            "CE-7.5 Engine",
            "C-25 Cryogenic Stage"
          ],
          "correct": 0,
          "explanation": "ISRO's heavy-lift LVM3 uses the indigenous CE-20 cryogenic engine in its C25 upper stage, powered by liquid oxygen (LOX) and liquid hydrogen (LH2)."
        },
        {
          "id": 17,
          "question": "What is the human-rated version of the LVM3 rocket designated as for the Gaganyaan mission?",
          "options": [
            "HLVM3 (Human-Rated LVM3)",
            "GSLV-H",
            "PSLV-Crew",
            "LVM-Crew1"
          ],
          "correct": 0,
          "explanation": "ISRO modified all systems, avionics, and safety margins of LVM3 to create the Human-Rated LVM3 (HLVM3) to carry the orbital module."
        },
        {
          "id": 18,
          "question": "What is the name of the humanoid robot developed by ISRO to fly on uncrewed Gaganyaan test missions ahead of human astronauts?",
          "options": [
            "Vyommitra",
            "Gaganmitra",
            "Mitra-1",
            "Shaktiman"
          ],
          "correct": 0,
          "explanation": "Vyommitra is a female spacefaring humanoid robot designed to monitor capsule environmental parameters, operate switch panels, and simulate crew functions."
        },
        {
          "id": 19,
          "question": "Where is ISRO's second spaceport for commercial small satellite launches being established?",
          "options": [
            "Kulasekarapattinam, Thoothukudi district, Tamil Nadu",
            "Sriharikota, Andhra Pradesh",
            "Thumba, Kerala",
            "Wheeler Island, Odisha"
          ],
          "correct": 0,
          "explanation": "The second spaceport is coming up at Kulasekarapattinam in Tamil Nadu, offering a direct southward trajectory for SSLV without having to dogleg around Sri Lanka."
        },
        {
          "id": 20,
          "question": "Why does launching polar satellites from Kulasekarapattinam provide a major operational advantage over Sriharikota?",
          "options": [
            "Allows a straight southward flight path over the ocean without requiring an expensive eastward dogleg manoeuvre to avoid Sri Lankan airspace",
            "Nearer to equator",
            "Higher altitude",
            "Cheaper fuel"
          ],
          "correct": 0,
          "explanation": "Launches from Sriharikota must dogleg eastward to bypass Sri Lanka's landmass, consuming rocket payload fuel; Kulasekarapattinam allows a direct straight trajectory."
        },
        {
          "id": 21,
          "question": "Which small satellite launch vehicle was developed by ISRO specifically for on-demand low-cost launches of mini-satellites up to 500 kg?",
          "options": [
            "SSLV (Small Satellite Launch Vehicle)",
            "PSLV-Nano",
            "ASLV",
            "Sounding Rocket Rohini"
          ],
          "correct": 0,
          "explanation": "SSLV is a 3-stage all-solid rocket with a liquid velocity trimming module (VTM), requiring minimal launch infrastructure and a turnaround of days."
        },
        {
          "id": 22,
          "question": "Who is the current Chairman of the Indian Space Research Organisation (ISRO) and Secretary, Department of Space?",
          "options": [
            "S. Somanath",
            "K. Sivan",
            "A.S. Kiran Kumar",
            "K. Radhakrishnan"
          ],
          "correct": 0,
          "explanation": "Eminent aerospace engineer S. Somanath serves as the Chairman of ISRO and Secretary of the Department of Space."
        },
        {
          "id": 23,
          "question": "Who is the current Chairman of the Defence Research and Development Organisation (DRDO)?",
          "options": [
            "Dr. Samir V. Kamat",
            "Dr. G. Satheesh Reddy",
            "Dr. S. Christopher",
            "Dr. Tessy Thomas"
          ],
          "correct": 0,
          "explanation": "Distinguished scientist Dr. Samir V. Kamat serves as the Secretary, Department of Defence R&D and Chairman of DRDO."
        },
        {
          "id": 24,
          "question": "Who is known as the 'Missile Woman of India' for her leading role as Project Director for the Agni-IV missile?",
          "options": [
            "Dr. Tessy Thomas",
            "Dr. Ritu Karidhal",
            "Dr. N. Valarmathi",
            "Moumita Dutta"
          ],
          "correct": 0,
          "explanation": "Dr. Tessy Thomas is celebrated as India's 'Missile Woman' for directing key Agni series missile development programmes at DRDO."
        },
        {
          "id": 25,
          "question": "Who was the Project Director of the historic Chandrayaan-3 mission that landed at the lunar south polar region?",
          "options": [
            "P. Veeramuthuvel",
            "M. Vanitha",
            "K. Sivan",
            "M. Annadurai"
          ],
          "correct": 0,
          "explanation": "Senior ISRO scientist P. Veeramuthuvel served as the Project Director of the triumphant Chandrayaan-3 mission."
        }
      ]
    },
    "science_tech_defence_mar2026": {
      "id": "science_tech_defence_mar2026",
      "category_id": "science_tech_defence",
      "category_name": "Science, Technology & Defence",
      "month_id": "mar2026",
      "month_name": "March 2026",
      "title": "Science & Defence Current Affairs - March 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "In March 2026, DRDO successfully conducted the first flight test of the indigenous Agni-5 missile equipped with MIRV technology under which mission name?",
          "options": [
            "Mission Divyastra",
            "Mission Shakti",
            "Mission Sudarshan",
            "Mission Vajra"
          ],
          "correct": 0,
          "explanation": "Prime Minister Narendra Modi announced the success of 'Mission Divyastra'—the maiden flight test of the Agni-5 intercontinental ballistic missile with Multiple Independently Targetable Re-entry Vehicle (MIRV) technology."
        },
        {
          "id": 2,
          "question": "What does 'MIRV' stand for in strategic missile technology?",
          "options": [
            "Multiple Independently Targetable Re-entry Vehicle",
            "Multi-stage Intercontinental Rocket Vehicle",
            "Miniaturized Infrared Radar Vehicle",
            "Military Integrated Reconnaissance Vector"
          ],
          "correct": 0,
          "explanation": "MIRV technology allows a single ballistic missile to deliver multiple nuclear warheads directed at distinct, widely separated targets hundreds of kilometres apart."
        },
        {
          "id": 3,
          "question": "With the success of Mission Divyastra, India joined an elite club of which nations possessing operational MIRV missile capability?",
          "options": [
            "USA, Russia, China, UK, France, and India",
            "USA and Russia only",
            "NATO countries only",
            "Five permanent UNSC members and North Korea"
          ],
          "correct": 0,
          "explanation": "Only the US, Russia, the UK, France, and China previously possessed tested operational MIRV technology."
        },
        {
          "id": 4,
          "question": "What is the estimated strike range of India's indigenous Agni-5 intercontinental ballistic missile?",
          "options": [
            "Over 5,000 kilometres",
            "3,500 kilometres",
            "2,500 kilometres",
            "10,000 kilometres"
          ],
          "correct": 0,
          "explanation": "Agni-5 is a three-stage solid-fueled road-mobile ICBM with an operational range exceeding 5,000 km, bringing all of Asia and parts of Europe within strike reach."
        },
        {
          "id": 5,
          "question": "From which location off the coast of Odisha did DRDO conduct the historic Mission Divyastra test flight?",
          "options": [
            "Dr. APJ Abdul Kalam Island (Wheeler Island)",
            "Chandipur Integrated Test Range (ITR)",
            "Sriharikota",
            "Balasore Sea Range"
          ],
          "correct": 0,
          "explanation": "The test was conducted from the Integrated Test Range at Dr. APJ Abdul Kalam Island off the coast of Bhadrak, Odisha."
        },
        {
          "id": 6,
          "question": "Which joint military exercise was conducted between the Indian Army and the Uzbekistan Armed Forces in March-April 2026?",
          "options": [
            "Exercise DUSTLIK",
            "Exercise NOMADIC ELEPHANT",
            "Exercise KHANJAR",
            "Exercise KAZIND"
          ],
          "correct": 0,
          "explanation": "Exercise DUSTLIK is the annual bilateral military drill between India and Uzbekistan focusing on counter-terrorism in semi-urban and mountainous terrain."
        },
        {
          "id": 7,
          "question": "Where was the 5th edition of Exercise DUSTLIK conducted?",
          "options": [
            "Termez, Uzbekistan",
            "Pithoragarh, Uttarakhand",
            "Belagavi, Karnataka",
            "Tashkent, Uzbekistan"
          ],
          "correct": 0,
          "explanation": "The 5th edition of Exercise DUSTLIK was held at Termez District in the Surxondaryo Region of Uzbekistan."
        },
        {
          "id": 8,
          "question": "What is 'Exercise Tiger Triumph' conducted in March 2026 in Visakhapatnam and Kakinada?",
          "options": [
            "Bilateral Tri-Services Humanitarian Assistance and Disaster Relief (HADR) exercise between India and the United States",
            "Indo-French naval drill",
            "Indo-Russian tank exercise",
            "Quad maritime patrol"
          ],
          "correct": 0,
          "explanation": "Tiger Triumph is a comprehensive Tri-Service amphibious exercise between the Indian Armed Forces and the United States military."
        },
        {
          "id": 9,
          "question": "Where was the foundation stone laid for India's first commercial semiconductor wafer fabrication facility (Fab) partnered by Tata Electronics and PSMC?",
          "options": [
            "Dholera, Gujarat",
            "Sanand, Gujarat",
            "Morigaon, Assam",
            "Jewar, Uttar Pradesh"
          ],
          "correct": 0,
          "explanation": "Tata Electronics partnered with Taiwan's Powerchip Semiconductor Manufacturing Corp (PSMC) to build India's premier ₹91,000 crore semiconductor fab in Dholera Special Investment Region."
        },
        {
          "id": 10,
          "question": "Where is the greenfield semiconductor assembly and testing (OSAT) facility of Tata Semiconductor Assembly and Test (TSAT) being constructed?",
          "options": [
            "Jagiroad, Morigaon district, Assam",
            "Guwahati, Assam",
            "Sanand, Gujarat",
            "Dharwad, Karnataka"
          ],
          "correct": 0,
          "explanation": "The ₹27,000 crore semiconductor packaging facility is being established at Jagiroad in Assam, marking the northeast region's first high-tech fab facility."
        },
        {
          "id": 11,
          "question": "Which project by CG Power in partnership with Renesas Electronics is establishing an OSAT facility in Gujarat?",
          "options": [
            "Sanand Semiconductor OSAT facility",
            "Dholera Fab",
            "Surat Chip Park",
            "Vadodara Electronics Zone"
          ],
          "correct": 0,
          "explanation": "CG Power, Renesas (Japan), and Stars Microelectronics (Thailand) partnered to establish a commercial semiconductor packaging facility in Sanand."
        },
        {
          "id": 12,
          "question": "What is the total financial support approved by the Government of India under the 'Semicon India Programme'?",
          "options": [
            "₹76,000 crore",
            "₹50,000 crore",
            "₹1,00,000 crore",
            "₹25,000 crore"
          ],
          "correct": 0,
          "explanation": "The Semicon India Programme offers 50% fiscal support on equal terms for setting up Silicon Semiconductor Fabs, Display Fabs, and OSAT units with a ₹76,000 crore outlay."
        },
        {
          "id": 13,
          "question": "Which is India's fastest and most powerful AI supercomputer, installed at C-DAC Pune and ranked among the world's top 100 supercomputers?",
          "options": [
            "AIRAWAT (AI Research Analytics and Knowledge Dissemination Platform)",
            "PARAM Siddhi-AI",
            "PARAM Shivay",
            "Pratyush"
          ],
          "correct": 0,
          "explanation": "AIRAWAT, installed under the National AI Mission at C-DAC Pune, delivers 13,170 teraflops of AI compute and ranked among the top 100 fastest AI systems globally."
        },
        {
          "id": 14,
          "question": "Where is the weather supercomputing facility 'Pratyush' and 'Mihir' situated in India?",
          "options": [
            "Indian Institute of Tropical Meteorology (IITM), Pune and NCMRWF, Noida",
            "ISRO Bengaluru",
            "IIT Delhi",
            "BARC Mumbai"
          ],
          "correct": 0,
          "explanation": "Pratyush (4 Petaflops) is located at IITM Pune and Mihir (2.8 Petaflops) at the National Centre for Medium Range Weather Forecasting (NCMRWF) in Noida."
        },
        {
          "id": 15,
          "question": "Under the National Supercomputing Mission (NSM), which apex agencies oversee the deployment of indigenous 'PARAM' supercomputers?",
          "options": [
            "Department of Science and Technology (DST) and Ministry of Electronics and IT (MeitY), implemented by C-DAC and IISc",
            "ISRO and DRDO",
            "CSIR and UGC",
            "NITI Aayog"
          ],
          "correct": 0,
          "explanation": "NSM is jointly steered by DST and MeitY, and executed by the Centre for Development of Advanced Computing (C-DAC) and Indian Institute of Science (IISc)."
        },
        {
          "id": 16,
          "question": "What is the name of the indigenous microprocessor series developed by IIT Madras under the Microprocessor Development Programme?",
          "options": [
            "SHAKTI",
            "AJIT",
            "VEGA",
            "DHRUV"
          ],
          "correct": 0,
          "explanation": "The SHAKTI processor family was designed by the RISE group at IIT Madras based on the open-source RISC-V Instruction Set Architecture (ISA)."
        },
        {
          "id": 17,
          "question": "Which microprocessor was developed indigenously by IIT Bombay?",
          "options": [
            "AJIT",
            "SHAKTI",
            "PARAM",
            "VIKAS"
          ],
          "correct": 0,
          "explanation": "AJIT is the first microprocessor designed and conceptualized entirely by engineers and researchers at IIT Bombay."
        },
        {
          "id": 18,
          "question": "Which Indian Navy stealth frigate was deployed to the Gulf of Aden and Red Sea for anti-piracy and maritime security operations under 'Operation Sankalp'?",
          "options": [
            "INS Kolkata, INS Kochi, and INS Visakhapatnam",
            "INS Vikrant only",
            "INS Viraat",
            "INS Chakra"
          ],
          "correct": 0,
          "explanation": "Indian Navy guided-missile destroyers INS Kolkata, INS Kochi, and INS Visakhapatnam executed daring rescue operations against Somali pirates, securing merchant ships."
        },
        {
          "id": 19,
          "question": "In a major anti-piracy operation 1,400 nautical miles off the Indian coast, the Indian Navy intercepted which hijacked ex-merchant ship and rescued 17 crew members?",
          "options": [
            "MV Ruen",
            "MV True Confidence",
            "MV Chem Pluto",
            "MV Genco Picardy"
          ],
          "correct": 0,
          "explanation": "INS Kolkata, assisted by patrol vessel INS Subhadra, Sea Guardian drones, and MARCOS commandos dropped from C-17 aircraft, forced all 35 Somali pirates aboard MV Ruen to surrender."
        },
        {
          "id": 20,
          "question": "What is the elite special operations force of the Indian Navy called?",
          "options": [
            "MARCOS (Marine Commandos)",
            "Garud Commandos",
            "Para SF",
            "NSG Black Cats"
          ],
          "correct": 0,
          "explanation": "MARCOS (officially Marine Commando Force - MCF) is the Indian Navy's specialized maritime combat and counter-terrorism unit."
        },
        {
          "id": 21,
          "question": "What is the special forces unit of the Indian Air Force called?",
          "options": [
            "Garud Commando Force",
            "MARCOS",
            "Para SF",
            "Special Frontier Force"
          ],
          "correct": 0,
          "explanation": "The Garud Commando Force, raised in 2004, is the special operations unit of the Indian Air Force tasked with airfield defence, radar busting, and combat search & rescue."
        },
        {
          "id": 22,
          "question": "What is the special forces wing of the Indian Army called?",
          "options": [
            "Para SF (Special Forces)",
            "MARCOS",
            "Garud",
            "Rashtriya Rifles"
          ],
          "correct": 0,
          "explanation": "The Parachute Regiment's Para SF battalions are the specialized strike commandos of the Indian Army."
        },
        {
          "id": 23,
          "question": "Who is the Supreme Commander of the Indian Armed Forces under Article 53(2) of the Constitution?",
          "options": [
            "The President of India",
            "The Prime Minister of India",
            "The Chief of Defence Staff",
            "The Minister of Defence"
          ],
          "correct": 0,
          "explanation": "Article 53(2) states that the supreme command of the Defence Forces of the Union shall be vested in the President of India and the exercise thereof shall be regulated by law."
        },
        {
          "id": 24,
          "question": "Who is the current Chief of Defence Staff (CDS) of India?",
          "options": [
            "General Anil Chauhan",
            "General Bipin Rawat",
            "General Manoj Pande",
            "General Upendra Dwivedi"
          ],
          "correct": 0,
          "explanation": "General Anil Chauhan serves as the second Chief of Defence Staff (CDS) of India, succeeding the late General Bipin Rawat."
        },
        {
          "id": 25,
          "question": "Who is the current Chief of the Army Staff (COAS) of the Indian Army?",
          "options": [
            "General Upendra Dwivedi",
            "General Manoj Pande",
            "General MM Naravane",
            "General Bipin Rawat"
          ],
          "correct": 0,
          "explanation": "General Upendra Dwivedi assumed charge as the 30th Chief of the Army Staff on June 30, 2024."
        }
      ]
    },
    "science_tech_defence_apr2026": {
      "id": "science_tech_defence_apr2026",
      "category_id": "science_tech_defence",
      "category_name": "Science, Technology & Defence",
      "month_id": "apr2026",
      "month_name": "April 2026",
      "title": "Science & Defence Current Affairs - April 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "Who was appointed as the Chief of the Naval Staff (CNS) of the Indian Navy in April 2026?",
          "options": [
            "Admiral Dinesh Kumar Tripathi",
            "Admiral R. Hari Kumar",
            "Admiral Karambir Singh",
            "Admiral Sunil Lanba"
          ],
          "correct": 0,
          "explanation": "Admiral Dinesh Kumar Tripathi assumed charge as the 26th Chief of the Naval Staff, succeeding Admiral R. Hari Kumar."
        },
        {
          "id": 2,
          "question": "Which country conducted the joint military exercise 'Nomadic Elephant' with the Indian Army?",
          "options": [
            "Mongolia",
            "Kazakhstan",
            "Kyrgyzstan",
            "Tajikistan"
          ],
          "correct": 0,
          "explanation": "Exercise Nomadic Elephant is an annual bilateral training exercise between the Indian Army and the Mongolian Armed Forces."
        },
        {
          "id": 3,
          "question": "Which indigenous aircraft carrier completed all carrier integration sea trials in the Arabian Sea?",
          "options": [
            "INS Vikrant (IAC-1)",
            "INS Vikramaditya",
            "INS Viraat",
            "INS Vishal"
          ],
          "correct": 0,
          "explanation": "INS Vikrant, India's first indigenously designed and constructed aircraft carrier (built by Cochin Shipyard), successfully integrated MiG-29K and LCA Navy flight operations."
        },
        {
          "id": 4,
          "question": "What is the ski-jump aircraft launch configuration used on INS Vikrant and INS Vikramaditya called?",
          "options": [
            "STOBAR (Short Take-Off But Arrested Recovery)",
            "CATOBAR",
            "STOVL",
            "VTOL"
          ],
          "correct": 0,
          "explanation": "Both operational Indian aircraft carriers feature STOBAR configuration, using an upward-angled ski-jump bow ramp for take-off and arrester wires for landing."
        },
        {
          "id": 5,
          "question": "What is the proposed displacement of the planned second indigenous aircraft carrier (IAC-2) approved for repeat order?",
          "options": [
            "Approximately 45,000 tonnes (sister ship to INS Vikrant)",
            "65,000 tonnes",
            "30,000 tonnes",
            "80,000 tonnes"
          ],
          "correct": 0,
          "explanation": "The Defence Acquisition Council cleared plans for a repeat order of a 45,000-tonne Vikrant-class carrier from Cochin Shipyard to ensure three operational carriers."
        },
        {
          "id": 6,
          "question": "Which air-to-air missile developed by DRDO has an operational range of 110+ km and travels at speeds beyond Mach 4.5?",
          "options": [
            "Astra Mk-1",
            "Python-5",
            "R-73",
            "MICA"
          ],
          "correct": 0,
          "explanation": "Astra Mk-1 is India's indigenous Beyond Visual Range Air-to-Air Missile (BVRAAM), integrated on Su-30MKI and LCA Tejas fighters."
        },
        {
          "id": 7,
          "question": "What is the extended range of the advanced 'Astra Mk-2' air-to-air missile being developed by DRDO?",
          "options": [
            "160 km with dual-pulse motor",
            "80 km",
            "50 km",
            "300 km"
          ],
          "correct": 0,
          "explanation": "Astra Mk-2 features an optical/RF proximity fuse and dual-pulse solid rocket motor capable of engaging aerial targets up to 160 km away."
        },
        {
          "id": 8,
          "question": "Which defence PSU manufactures the Light Combat Aircraft (LCA) Tejas in India?",
          "options": [
            "Hindustan Aeronautics Limited (HAL)",
            "Bharat Electronics Limited",
            "Bharat Dynamics Limited",
            "Mazagon Dock"
          ],
          "correct": 0,
          "explanation": "Hindustan Aeronautics Limited (HAL) manufactures the LCA Tejas fighter jets at its Aircraft Division facilities in Bengaluru, Karnataka."
        },
        {
          "id": 9,
          "question": "Which engine powers the LCA Tejas Mk-1 and Mk-1A fighter aircraft?",
          "options": [
            "General Electric GE F404-IN20 engine",
            "GE F414",
            "Kaveri engine",
            "Rolls-Royce Trent"
          ],
          "correct": 0,
          "explanation": "The Tejas Mk-1 and Mk-1A are powered by the GE F404 turbofan engine, while the upcoming Tejas Mk-2 will use the higher-thrust GE F414-INS6 engine."
        },
        {
          "id": 10,
          "question": "Under which joint agreement will HAL and GE Aerospace co-produce the F414 jet engine in India with 80% technology transfer?",
          "options": [
            "India-US Initiative on Critical and Emerging Technology (iCET)",
            "BECA agreement",
            "COMCASA",
            "LEMOA"
          ],
          "correct": 0,
          "explanation": "Under the iCET framework, the US approved full operational co-production of GE F414 engines in India with an unprecedented 80% transfer of technology."
        },
        {
          "id": 11,
          "question": "Which country partners with India on the BrahMos supersonic cruise missile joint venture?",
          "options": [
            "Russia (NPO Mashinostroyeniya)",
            "France",
            "Israel",
            "United States"
          ],
          "correct": 0,
          "explanation": "BrahMos Aerospace is an Indo-Russian joint venture formed in 1998, named after the Brahmaputra (India) and Moskva (Russia) rivers."
        },
        {
          "id": 12,
          "question": "What is the speed of the BrahMos supersonic cruise missile?",
          "options": [
            "Mach 2.8 to Mach 3.0",
            "Mach 1.2",
            "Mach 5.0",
            "Subsonic at Mach 0.8"
          ],
          "correct": 0,
          "explanation": "BrahMos travels at Mach 2.8 (nearly three times the speed of sound), making it the world's fastest operational cruise missile."
        },
        {
          "id": 13,
          "question": "Which Southeast Asian country became the first export customer for India's shore-based BrahMos missile system?",
          "options": [
            "The Philippines",
            "Vietnam",
            "Indonesia",
            "Malaysia"
          ],
          "correct": 0,
          "explanation": "The Philippines acquired three batteries of the shore-based anti-ship BrahMos missile system in a $375 million export contract."
        },
        {
          "id": 14,
          "question": "What is the extended range of the modern BrahMos missile following India's entry into the MTCR?",
          "options": [
            "Up to 450 to 500 kilometres",
            "290 km restricted",
            "150 km",
            "800 km"
          ],
          "correct": 0,
          "explanation": "Following India's formal accession to the Missile Technology Control Regime (MTCR) in 2016, BrahMos range was upgraded from 290 km to 450–500 km."
        },
        {
          "id": 15,
          "question": "What is 'Pralay' missile developed by DRDO for conventional battlefield strikes?",
          "options": [
            "Short-range quasi-ballistic surface-to-surface missile with 150-500 km range",
            "Intercontinental ballistic missile",
            "Anti-submarine missile",
            "Air-to-air missile"
          ],
          "correct": 0,
          "explanation": "Pralay is a solid-propellant battlefield missile that can change its path in mid-air to evade interceptor missiles, carrying 500-1000 kg conventional warheads."
        },
        {
          "id": 16,
          "question": "Which shipyard constructed the Kalvari-class (Scorpene) diesel-electric attack submarines in India under Project 75?",
          "options": [
            "Mazagon Dock Shipbuilders Limited (MDL), Mumbai",
            "Garden Reach Shipbuilders, Kolkata",
            "Cochin Shipyard",
            "Goa Shipyard"
          ],
          "correct": 0,
          "explanation": "MDL constructed all six Project 75 Scorpene submarines (Kalvari, Khanderi, Karanj, Vela, Vagir, and Vagsheer) in technology partnership with Naval Group of France."
        },
        {
          "id": 17,
          "question": "What is the name of the sixth and final Scorpene submarine commissioned under Project 75?",
          "options": [
            "INS Vagsheer",
            "INS Vagir",
            "INS Karanj",
            "INS Vela"
          ],
          "correct": 0,
          "explanation": "INS Vagsheer (named after the sandfish) completed all rigorous weapon and sensor trials, concluding the Project 75 submarine series."
        },
        {
          "id": 18,
          "question": "What technology is being retrofitted onto Kalvari-class submarines by DRDO to allow them to remain submerged for extended durations?",
          "options": [
            "Air Independent Propulsion (AIP) system",
            "Nuclear reactor",
            "Lithium battery only",
            "Solar sails"
          ],
          "correct": 0,
          "explanation": "DRDO's Naval Materials Research Laboratory (NMRL) developed a fuel-cell based AIP module that enables conventional submarines to remain underwater for up to two weeks."
        },
        {
          "id": 19,
          "question": "Which Indian nuclear-powered ballistic missile submarine (SSBN) completed its deterrence patrol, solidifying India's nuclear triad?",
          "options": [
            "INS Arihant (SSBN-80)",
            "INS Chakra",
            "INS Shishumar",
            "INS Sindhurakshak"
          ],
          "correct": 0,
          "explanation": "INS Arihant completed its inaugural deterrence patrol, giving India an operational, survivable second-strike nuclear capability across air, land, and sea."
        },
        {
          "id": 20,
          "question": "What is the name of India's second nuclear-powered ballistic missile submarine (SSBN) commissioned at Visakhapatnam?",
          "options": [
            "INS Arighaat (SSBN-81)",
            "INS Aridhaman",
            "INS Khanderi",
            "INS Chakra III"
          ],
          "correct": 0,
          "explanation": "INS Arighaat was formally commissioned into the Strategic Forces Command in August 2024 at Visakhapatnam, enhancing strategic deterrence."
        },
        {
          "id": 21,
          "question": "Which submarine-launched ballistic missile (SLBM) is carried by INS Arihant?",
          "options": [
            "K-15 Sagarika (range ~750 km) and K-4 (range ~3,500 km)",
            "Prithvi-III",
            "BrahMos-ER",
            "Agni-1"
          ],
          "correct": 0,
          "explanation": "The 'K' family of SLBMs (named after Dr. APJ Abdul Kalam) includes K-15 (Sagarika) and the advanced K-4 missile."
        },
        {
          "id": 22,
          "question": "What is India's official nuclear doctrine adopted in 2003 regarding the use of nuclear weapons?",
          "options": [
            "No First Use (NFU) and Credible Minimum Deterrence",
            "Preemptive first strike",
            "Massive early retaliation",
            "Flexible response doctrine"
          ],
          "correct": 0,
          "explanation": "India's nuclear doctrine maintains 'No First Use' against nuclear states and non-use against non-nuclear states, with guaranteed massive punitive second-strike retaliation."
        },
        {
          "id": 23,
          "question": "Who is the Chairman of the Political Council of the Nuclear Command Authority (NCA) of India?",
          "options": [
            "The Prime Minister of India",
            "The National Security Advisor",
            "The Chief of Defence Staff",
            "The Defence Minister"
          ],
          "correct": 0,
          "explanation": "The Prime Minister chairs the Political Council of the NCA, which is the sole authority that can authorize the operational use of nuclear weapons."
        },
        {
          "id": 24,
          "question": "Who heads the Executive Council of the Nuclear Command Authority (NCA)?",
          "options": [
            "The National Security Advisor (NSA)",
            "The Cabinet Secretary",
            "The Chief of Defence Staff",
            "The Foreign Secretary"
          ],
          "correct": 0,
          "explanation": "The National Security Advisor (NSA) chairs the Executive Council, which provides inputs to the Political Council and executes directives issued by it."
        },
        {
          "id": 25,
          "question": "Who is the current National Security Advisor (NSA) of India?",
          "options": [
            "Ajit Doval",
            "Brajesh Mishra",
            "Shivshankar Menon",
            "J.N. Dixit"
          ],
          "correct": 0,
          "explanation": "Ajit Doval was re-appointed as the National Security Advisor for a historic third term with the rank of a Union Cabinet Minister."
        }
      ]
    },
    "science_tech_defence_may2026": {
      "id": "science_tech_defence_may2026",
      "category_id": "science_tech_defence",
      "category_name": "Science, Technology & Defence",
      "month_id": "may2026",
      "month_name": "May 2026",
      "title": "Science & Defence Current Affairs - May 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "National Technology Day is observed in India every year on May 11 to celebrate which historic event?",
          "options": [
            "Pokhran-II nuclear tests (Operation Shakti) conducted on May 11, 1998",
            "First satellite Aryabhata launch",
            "First test of Agni missile",
            "First heart transplant"
          ],
          "correct": 0,
          "explanation": "National Technology Day commemorates the successful underground nuclear tests in Pokhran on May 11, 1998, as well as the maiden flight of the indigenous Hansa-3 aircraft."
        },
        {
          "id": 2,
          "question": "Which indigenously developed anti-radiation missile was successfully test-fired by DRDO from a Su-30MKI fighter?",
          "options": [
            "Rudram-1 / Rudram-2",
            "Astra",
            "Nag",
            "Helina"
          ],
          "correct": 0,
          "explanation": "Rudram is India's first indigenous New Generation Anti-Radiation Missile (NGARM) designed to neutralize enemy surveillance radars and tracking stations."
        },
        {
          "id": 3,
          "question": "What is the primary role of an 'Anti-Radiation Missile' like Rudram?",
          "options": [
            "To track and home in on enemy radar transmissions, air defence systems, and communication emitters",
            "To shoot down satellites",
            "To intercept ballistic missiles in space",
            "To destroy tanks"
          ],
          "correct": 0,
          "explanation": "Anti-radiation missiles use passive homing heads to locate radio-frequency and microwave emissions from hostile radar and jamming installations."
        },
        {
          "id": 4,
          "question": "Which air-to-surface anti-tank guided missile (ATGM) was developed by DRDO for integration on ALH Dhruv and LCH Prachand helicopters?",
          "options": [
            "HELINA (Helicopter-launched Nag) / Dhruvastra",
            "Amogha",
            "Sant",
            "Man-Portable ATGM"
          ],
          "correct": 0,
          "explanation": "HELINA (army version) and Dhruvastra (air force version) are third-generation fire-and-forget ATGMs equipped with imaging infrared (IIR) seekers."
        },
        {
          "id": 5,
          "question": "What is the operational strike range of the HELINA anti-tank guided missile?",
          "options": [
            "Up to 7 to 8 kilometres",
            "Up to 2 km",
            "Up to 15 km",
            "Up to 20 km"
          ],
          "correct": 0,
          "explanation": "HELINA can engage battlefield targets from a standoff distance of up to 7-8 km in direct hit and top-attack modes."
        },
        {
          "id": 6,
          "question": "Which Light Combat Helicopter (LCH) developed by HAL is the world's only attack helicopter capable of landing and taking off at an altitude of 5,000 metres?",
          "options": [
            "Prachand",
            "Rudra",
            "Chetak",
            "Cheetah"
          ],
          "correct": 0,
          "explanation": "LCH Prachand, inducted by the Army and IAF, is engineered specifically for high-altitude combat in Siachen and eastern Ladakh."
        },
        {
          "id": 7,
          "question": "Which multi-role combat helicopter was developed as the armed weaponized version of HAL's Advanced Light Helicopter (ALH Dhruv)?",
          "options": [
            "HAL Rudra (ALH-WSI)",
            "Prachand",
            "Kamov Ka-226T",
            "Apache AH-64E"
          ],
          "correct": 0,
          "explanation": "HAL Rudra is the Weapon System Integrated (WSI) variant of the ALH Dhruv, fitted with 20mm turret guns, 70mm rockets, and Mistral missiles."
        },
        {
          "id": 8,
          "question": "Which foreign aerospace major manufactures the Apache AH-64E attack helicopters acquired by the Indian Air Force and Indian Army?",
          "options": [
            "Boeing (United States)",
            "Airbus (Europe)",
            "Lockheed Martin",
            "Dassault Aviation"
          ],
          "correct": 0,
          "explanation": "Boeing manufactures the AH-64E Apache Guardian, with fuselages produced by Tata Boeing Aerospace Limited (TBAL) in Hyderabad."
        },
        {
          "id": 9,
          "question": "Where is Tata Boeing Aerospace Limited (TBAL) facility located in India?",
          "options": [
            "Hyderabad, Telangana",
            "Bengaluru, Karnataka",
            "Nagpur, Maharashtra",
            "Pune, Maharashtra"
          ],
          "correct": 0,
          "explanation": "TBAL operates its advanced aerospace manufacturing facility at Adibatla in Hyderabad, producing AH-64 Apache fuselages for global customers."
        },
        {
          "id": 10,
          "question": "Which military aircraft manufacturer produces the C-295 medium tactical transport aircraft for the Indian Air Force?",
          "options": [
            "Airbus Defence and Space in partnership with Tata Advanced Systems (TASL)",
            "Boeing and HAL",
            "Lockheed Martin",
            "Embraer"
          ],
          "correct": 0,
          "explanation": "Airbus and Tata Advanced Systems established India's first private sector military aircraft Final Assembly Line (FAL) in Vadodara, Gujarat."
        },
        {
          "id": 11,
          "question": "Where was the Final Assembly Line (FAL) plant for C-295 transport aircraft inaugurated in Gujarat?",
          "options": [
            "Vadodara, Gujarat",
            "Ahmedabad",
            "Surat",
            "Rajkot"
          ],
          "correct": 0,
          "explanation": "The C-295 FAL in Vadodara will manufacture 40 of the 56 contracted aircraft, creating an indigenous defense aerospace manufacturing hub."
        },
        {
          "id": 12,
          "question": "What aircraft did the Airbus C-295 primarily replace in the Indian Air Force fleet?",
          "options": [
            "Aging Avro-748 (Hawker Siddeley HS 748) fleet",
            "AN-32",
            "IL-76",
            "Dornier 228"
          ],
          "correct": 0,
          "explanation": "The 5-10 tonne capacity C-295 aircraft replaces the legacy fleet of British-origin Avro-748 transport planes in service since the 1960s."
        },
        {
          "id": 13,
          "question": "What is the primary function of the 'DRDO SMART' system successfully test-fired off the coast of Odisha in May 2026?",
          "options": [
            "Supersonic Missile Assisted Release of Torpedo (long-range anti-submarine warfare)",
            "Satellite tracking radar",
            "Mine sweeping system",
            "Naval artillery shell"
          ],
          "correct": 0,
          "explanation": "SMART is a canisterized hybrid missile system that delivers a lightweight torpedo at supersonic speeds over 600 km to engage enemy submarines."
        },
        {
          "id": 14,
          "question": "Which lightweight torpedo is integrated into the SMART missile system?",
          "options": [
            "TAL (Torpedo Advanced Lightweight) Shyena",
            "Varunastra",
            "Takshak",
            "Advanced Heavy Torpedo"
          ],
          "correct": 0,
          "explanation": "SMART carries the indigenous TAL Shyena lightweight torpedo, parachuted into the water in the vicinity of target coordinates."
        },
        {
          "id": 15,
          "question": "What is 'Varunastra' developed by DRDO and manufactured by Bharat Dynamics Limited?",
          "options": [
            "Ship-launched, electrically propelled Heavyweight Anti-Submarine Torpedo",
            "Lightweight air-dropped torpedo",
            "Submarine rescue vehicle",
            "Sonar decoy"
          ],
          "correct": 0,
          "explanation": "Varunastra is a state-of-the-art 1.5-tonne heavyweight anti-submarine torpedo capable of striking quiet submarines in deep and shallow waters at 40 knots."
        },
        {
          "id": 16,
          "question": "Which indigenous long-range glide bomb was test-fired by DRDO from a Sukhoi-30MKI fighter in May 2026?",
          "options": [
            "Gaurav (Long Range Glide Bomb - LRGB)",
            "SAAW",
            "Garuda",
            "Vajra-LR"
          ],
          "correct": 0,
          "explanation": "DRDO conducted successful flight tests of 'Gaurav', a 1,000 kg class winged glide bomb using GPS/NavIC satellite guidance with a 100 km standoff range."
        },
        {
          "id": 17,
          "question": "What is 'SAAW' developed by DRDO for airfield neutralization?",
          "options": [
            "Smart Anti-Airfield Weapon",
            "Standard Aerial Assault Weapon",
            "Surface Air Armament Wing",
            "Supersonic Air Artillery Weapon"
          ],
          "correct": 0,
          "explanation": "SAAW is a 125 kg high-precision guided stand-off glide bomb designed to destroy ground targets like runways, bunkers, and aircraft hangars up to 100 km away."
        },
        {
          "id": 18,
          "question": "What is India's indigenous satellite navigation system developed by ISRO called?",
          "options": [
            "NavIC (Navigation with Indian Constellation / IRNSS)",
            "GAGAN",
            "Bhuvan",
            "Disha"
          ],
          "correct": 0,
          "explanation": "NavIC is an autonomous regional satellite navigation system covering India and an area extending 1,500 km around its borders."
        },
        {
          "id": 19,
          "question": "How many satellites constitute the operational baseline constellation of NavIC (IRNSS)?",
          "options": [
            "7 satellites (3 in geostationary orbit, 4 in geosynchronous orbit)",
            "4 satellites",
            "10 satellites",
            "24 satellites"
          ],
          "correct": 0,
          "explanation": "NavIC uses a constellation of 7 satellites: 3 in Geostationary Earth Orbit (GEO) at 32.5°E, 83°E, and 129.5°E, and 4 in inclined Geosynchronous Orbit (GSO)."
        },
        {
          "id": 20,
          "question": "What frequency bands does the second-generation NavIC satellite series (NVS) utilize?",
          "options": [
            "L1, L5, and S bands",
            "Ku band only",
            "C band only",
            "X band and Ka band"
          ],
          "correct": 0,
          "explanation": "NVS series satellites incorporate the interoperable L1 civilian band (1575.42 MHz) alongside L5 and S bands, making NavIC accessible in commercial smartphones."
        },
        {
          "id": 21,
          "question": "What atomic clock technology is incorporated aboard the indigenous NVS-01 navigation satellite?",
          "options": [
            "Indigenous Rubidium Atomic Clock developed by Space Applications Centre (SAC) Ahmedabad",
            "Cesium fountain clock",
            "Hydrogen maser",
            "Quartz crystal only"
          ],
          "correct": 0,
          "explanation": "NVS-01 is powered by an indigenous space-qualified rubidium atomic frequency standard developed by ISRO's SAC in Ahmedabad."
        },
        {
          "id": 22,
          "question": "What is 'GAGAN' developed jointly by ISRO and the Airports Authority of India (AAI)?",
          "options": [
            "GPS Aided GEO Augmented Navigation (Satellite-Based Augmentation System - SBAS)",
            "Weather radar system",
            "Drone traffic management",
            "Air traffic simulator"
          ],
          "correct": 0,
          "explanation": "GAGAN provides seamless, precision satellite-guided navigation over Indian airspace for civil aviation, making India the fourth nation with operational SBAS."
        },
        {
          "id": 23,
          "question": "Which was the first commercial airline in Asia to use GAGAN satellite-based technology for landing an aircraft?",
          "options": [
            "IndiGo Airlines (at Kishangarh Airport, Rajasthan)",
            "Air India",
            "SpiceJet",
            "Singapore Airlines"
          ],
          "correct": 0,
          "explanation": "IndiGo successfully landed an ATR-72 aircraft at Kishangarh using the Localizer Performance with Vertical Guidance (LPV) approach powered by GAGAN."
        },
        {
          "id": 24,
          "question": "Where are the headquarters of the Airports Authority of India (AAI) located?",
          "options": [
            "Rajiv Gandhi Bhawan, Safdarjung Airport, New Delhi",
            "Mumbai",
            "Bengaluru",
            "Hyderabad"
          ],
          "correct": 0,
          "explanation": "AAI, a statutory body under the Ministry of Civil Aviation, is headquartered at Rajiv Gandhi Bhawan in New Delhi."
        },
        {
          "id": 25,
          "question": "What is 'Bhuvan' developed by ISRO?",
          "options": [
            "A national Geoportal providing multi-sensor satellite imagery and spatial data services",
            "A remote sensing satellite",
            "A rocket motor",
            "A weather forecasting balloon"
          ],
          "correct": 0,
          "explanation": "Bhuvan is ISRO's indigenous web-based 2D and 3D GIS platform providing earth observation data, natural disaster maps, and governance planning layers."
        }
      ]
    },
    "science_tech_defence_jun2026": {
      "id": "science_tech_defence_jun2026",
      "category_id": "science_tech_defence",
      "category_name": "Science, Technology & Defence",
      "month_id": "jun2026",
      "month_name": "June 2026",
      "title": "Science & Defence Current Affairs - June 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "ISRO unveiled the design architecture for the first module of the 'Bharatiya Antariksh Station' (BAS-1). What is the targeted launch year for BAS-1?",
          "options": [
            "2028 (with full station operational by 2035)",
            "2030",
            "2026",
            "2040"
          ],
          "correct": 0,
          "explanation": "ISRO plans to launch BAS-1 (a 52-tonne space station module) by 2028, with the complete multi-module space station operational by 2035, ahead of a planned crewed lunar landing by 2040."
        },
        {
          "id": 2,
          "question": "By which target year has India set the national goal to land an Indian astronaut on the Moon?",
          "options": [
            "2040",
            "2035",
            "2030",
            "2045"
          ],
          "correct": 0,
          "explanation": "Prime Minister Narendra Modi set two visionary space milestones: setting up the Bharatiya Antariksh Station by 2035 and landing an Indian astronaut on the Moon by 2040."
        },
        {
          "id": 3,
          "question": "What is the name of the next-generation heavy launch vehicle being developed by ISRO to support the Moon landing and space station modules?",
          "options": [
            "NGLV (Next Generation Launch Vehicle / Soorya)",
            "LVM4",
            "Super PSLV",
            "GSLV Mk IV"
          ],
          "correct": 0,
          "explanation": "The Union Cabinet approved development of the Next Generation Launch Vehicle (NGLV, named 'Soorya'), featuring semi-cryogenic and reusable methane-liquid oxygen stages."
        },
        {
          "id": 4,
          "question": "What payload capacity to Low Earth Orbit (LEO) is the Next Generation Launch Vehicle (NGLV) designed to deliver in its reusable configuration?",
          "options": [
            "Up to 30 tonnes to LEO",
            "10 tonnes",
            "15 tonnes",
            "50 tonnes"
          ],
          "correct": 0,
          "explanation": "NGLV will deliver up to 30 tonnes to LEO in expendable mode and around 20 tonnes in reusable booster mode, three times the capacity of LVM3."
        },
        {
          "id": 5,
          "question": "Which multi-nation air combat exercise, the largest ever conducted on Indian soil, was scheduled by the Indian Air Force in two phases in mid-2026?",
          "options": [
            "Exercise Tarang Shakti 2026",
            "Exercise Garuda",
            "Exercise Desert Knight",
            "Exercise Pitch Black"
          ],
          "correct": 0,
          "explanation": "Exercise Tarang Shakti brought together air forces from over 30 countries at Sulur (Tamil Nadu) and Jodhpur (Rajasthan) with fighter jets from Germany, France, UK, and US."
        },
        {
          "id": 6,
          "question": "Which European nation deployed Eurofighter Typhoons to India for the first time to participate in Exercise Tarang Shakti?",
          "options": [
            "Germany (Luftwaffe)",
            "Italy",
            "Spain",
            "Austria"
          ],
          "correct": 0,
          "explanation": "The German Air Force deployed Eurofighter Typhoon fighter jets and A400M transport aircraft to India for the inaugural phase of Tarang Shakti."
        },
        {
          "id": 7,
          "question": "Where was the joint military exercise 'MAITREE' between the Indian Army and the Royal Thai Army conducted?",
          "options": [
            "Tak Province, Thailand",
            "Umroi, Meghalaya",
            "Chaubattia, Uttarakhand",
            "Phuket, Thailand"
          ],
          "correct": 0,
          "explanation": "Exercise MAITREE 2026 was conducted at the Fort Vachiraprakan in Tak Province, Thailand, focusing on counter-insurgency and counter-terror tactics."
        },
        {
          "id": 8,
          "question": "Which bilateral naval exercise is conducted annually between the Indian Navy and the French Navy?",
          "options": [
            "Exercise VARUNA",
            "Exercise SHAKTI",
            "Exercise GARUDA",
            "Exercise SAMPRITI"
          ],
          "correct": 0,
          "explanation": "Varuna is the bilateral maritime exercise between the Indian and French navies. (Shakti is the army exercise, and Garuda is the air force exercise)."
        },
        {
          "id": 9,
          "question": "What is the name of the bilateral army exercise conducted between India and France?",
          "options": [
            "Exercise SHAKTI",
            "Exercise VARUNA",
            "Exercise GARUDA",
            "Exercise FRINJEX"
          ],
          "correct": 0,
          "explanation": "Exercise SHAKTI is the joint military exercise conducted between the Indian Army and the French Army."
        },
        {
          "id": 10,
          "question": "What is the joint military exercise conducted between the Indian Army and the Singapore Army called?",
          "options": [
            "Exercise BOLD KURUKSHETRA",
            "Exercise SIMBEX",
            "Exercise AGNI WARRIOR",
            "Both Bold Kurukshetra and Agni Warrior"
          ],
          "correct": 3,
          "explanation": "India and Singapore conduct Exercise Bold Kurukshetra (armour/infantry) and Exercise Agni Warrior (artillery), while SIMBEX is their bilateral naval exercise."
        },
        {
          "id": 11,
          "question": "What does 'SIMBEX' stand for in bilateral defence engagements?",
          "options": [
            "Singapore-India Maritime Bilateral Exercise",
            "South India Maritime Border Exercise",
            "Strategic India-Malaysia Border Exercise",
            "Submarine Interception Maritime Base Exercise"
          ],
          "correct": 0,
          "explanation": "SIMBEX is the annual maritime warfare exercise conducted between the Indian Navy and the Republic of Singapore Navy (RSN) since 1994."
        },
        {
          "id": 12,
          "question": "Which bilateral naval exercise is conducted between the Indian Navy and the Royal Navy of the United Kingdom?",
          "options": [
            "Exercise KONKAN",
            "Exercise INDRADHANUSH",
            "Exercise AJEYA WARRIOR",
            "Exercise PASSEX"
          ],
          "correct": 0,
          "explanation": "Exercise Konkan is the annual naval drill between India and the UK. (Ajeya Warrior is their army exercise, and Indradhanush is their air exercise)."
        },
        {
          "id": 13,
          "question": "What is the name of the annual bilateral military exercise between the Indian Army and the British Army?",
          "options": [
            "Exercise AJEYA WARRIOR",
            "Exercise KONKAN",
            "Exercise INDRADHANUSH",
            "Exercise AL NAJAH"
          ],
          "correct": 0,
          "explanation": "Exercise Ajeya Warrior is the biennial joint army training exercise between India and the United Kingdom."
        },
        {
          "id": 14,
          "question": "Which joint military exercise is conducted between India and Oman?",
          "options": [
            "Exercise AL NAJAH (Army), NASEEM AL BAHR (Navy), EASTERN BRIDGE (Air Force)",
            "Exercise Desert Eagle",
            "Exercise Zayed Talwar",
            "Exercise Desert Flag"
          ],
          "correct": 0,
          "explanation": "India and Oman conduct tripartite cooperation: Al Najah (Army), Naseem Al Bahr (Navy), and Eastern Bridge (Air Force)."
        },
        {
          "id": 15,
          "question": "Which bilateral military exercise is conducted between India and Japan?",
          "options": [
            "DHARMA GUARDIAN (Army), JIMEX (Navy), SHINYUU MAITRI (Air Force)",
            "Malabar only",
            "Sahayog Kaijin",
            "Yudh Abhyas"
          ],
          "correct": 0,
          "explanation": "India-Japan defense cooperation spans Dharma Guardian (Army), JIMEX (Navy), Shinyuu Maitri (transport aircraft), and Veer Guardian (fighter jets)."
        },
        {
          "id": 16,
          "question": "What is the bilateral army exercise between India and the United States known as?",
          "options": [
            "Exercise YUDH ABHYAS",
            "Exercise VAJRA PRAHAR",
            "Exercise TIGER TRIUMPH",
            "Both Yudh Abhyas and Vajra Prahar"
          ],
          "correct": 3,
          "explanation": "Yudh Abhyas is the battalion-level conventional warfare exercise, while Vajra Prahar is the specialized joint training between Indian and US Special Forces."
        },
        {
          "id": 17,
          "question": "Which multinational air combat exercise is hosted biennially by the Royal Australian Air Force (RAAF) in Darwin, where the IAF participates?",
          "options": [
            "Exercise PITCH BLACK",
            "Exercise Red Flag",
            "Exercise Cope India",
            "Exercise Blue Flag"
          ],
          "correct": 0,
          "explanation": "Exercise Pitch Black is Australia's premier multilateral air warfare exercise in the Northern Territory, featuring complex night-flying and strike simulations."
        },
        {
          "id": 18,
          "question": "What is 'Deep Ocean Mission' (Samudrayaan) approved by the Ministry of Earth Sciences?",
          "options": [
            "A mission to explore deep-sea resources and develop a 3-person submersible 'Matsya 6000' to reach 6,000 metres depth",
            "A coastal fishing scheme",
            "A coral bleaching study only",
            "A desalination project"
          ],
          "correct": 0,
          "explanation": "The Samudrayaan project under the Deep Ocean Mission develops an indigenous human submersible (Matsya-6000) to carry 3 scientists to a depth of 6 km for polymetallic nodules exploration."
        },
        {
          "id": 19,
          "question": "Which institute developed the 'Matsya 6000' human submersible under the Deep Ocean Mission?",
          "options": [
            "National Institute of Ocean Technology (NIOT), Chennai",
            "National Centre for Polar and Ocean Research (NCPOR), Goa",
            "INCOIS, Hyderabad",
            "CSIR-NIO, Goa"
          ],
          "correct": 0,
          "explanation": "NIOT in Chennai designed the titanium alloy manned sphere and sub-systems for the Matsya-6000 deep-sea submersible."
        },
        {
          "id": 20,
          "question": "Where is the National Centre for Polar and Ocean Research (NCPOR) located?",
          "options": [
            "Vasco da Gama, Goa",
            "Thiruvananthapuram, Kerala",
            "Kochi, Kerala",
            "Port Blair"
          ],
          "correct": 0,
          "explanation": "NCPOR is the premier R&D institution under the Ministry of Earth Sciences located in Goa, managing India's Antarctic and Arctic research stations."
        },
        {
          "id": 21,
          "question": "What are the names of India's active permanent research stations in Antarctica?",
          "options": [
            "Maitri and Bharati",
            "Dakshin Gangotri and Maitri",
            "Himadri and Bharati",
            "Indira and Maitri"
          ],
          "correct": 0,
          "explanation": "India's active scientific research bases in Antarctica are Maitri (commissioned 1989) and Bharati (commissioned 2012). (Dakshin Gangotri was decommissioned in 1990)."
        },
        {
          "id": 22,
          "question": "What is the name of India's permanent research station in the Arctic, established in 2008 at Ny-Alesund, Svalbard, Norway?",
          "options": [
            "Himadri",
            "IndARC",
            "Bharati",
            "Gangotri"
          ],
          "correct": 0,
          "explanation": "Himadri is India's dedicated Arctic research station located at the International Arctic Research base in Spitsbergen, Svalbard, Norway."
        },
        {
          "id": 23,
          "question": "What is 'IndARC' deployed by India in the Arctic Ocean?",
          "options": [
            "India's first multi-sensor moored underwater observatory in Kongsfjorden, Svalbard",
            "An icebreaker ship",
            "A weather satellite",
            "A radar plane"
          ],
          "correct": 0,
          "explanation": "IndARC is an underwater oceanographic observatory moored at 192 metres depth in the Arctic fjord to monitor Arctic climate impact on the Indian monsoon."
        },
        {
          "id": 24,
          "question": "What is the name of the research station operated by India in the high Himalayas at Chandra Basin, Himachal Pradesh?",
          "options": [
            "Himansh",
            "Himadri",
            "Shakti",
            "Trishul"
          ],
          "correct": 0,
          "explanation": "Himansh is India's high-altitude research station established by NCPOR at Sutri Dhaka in the Chandra basin (Spiti valley) to study Himalayan glaciology."
        },
        {
          "id": 25,
          "question": "Under which statutory Act is the legal framework for Indian activities in Antarctica governed?",
          "options": [
            "Indian Antarctic Act, 2022",
            "Environment Protection Act, 1986",
            "Territorial Waters Act",
            "Maritime Zones of India Act"
          ],
          "correct": 0,
          "explanation": "The Indian Antarctic Act, 2022 provides a comprehensive domestic legal framework to protect the Antarctic environment and regulate Indian research expeditions."
        }
      ]
    },
    "science_tech_defence_jul2026": {
      "id": "science_tech_defence_jul2026",
      "category_id": "science_tech_defence",
      "category_name": "Science, Technology & Defence",
      "month_id": "jul2026",
      "month_name": "July 2026",
      "title": "Science & Defence Current Affairs - July 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "ISRO announced the multi-module mission profile of 'Chandrayaan-4'. What is the primary objective of the Chandrayaan-4 mission?",
          "options": [
            "Lunar Sample Return Mission (collecting lunar soil samples and returning them safely to Earth)",
            "Manned landing on Moon",
            "Deploying permanent rover",
            "Mapping water ice from orbit"
          ],
          "correct": 0,
          "explanation": "Chandrayaan-4 is a complex 5-module lunar sample-return mission that will collect core samples near the lunar south pole, dock in lunar orbit, and return them to Earth."
        },
        {
          "id": 2,
          "question": "How many spacecraft modules make up the Chandrayaan-4 mission architecture across two rocket launches?",
          "options": [
            "5 modules (Propulsion, Lander, Ascender, Transfer, and Re-entry Module)",
            "3 modules",
            "4 modules",
            "2 modules"
          ],
          "correct": 0,
          "explanation": "The architecture involves two LVM3 launches carrying 5 integrated modules: Lander Module, Ascender Module, Transfer Module, Re-entry Module, and Propulsion Module."
        },
        {
          "id": 3,
          "question": "What is 'LUPEX' (Lunar Polar Exploration) mission planned jointly by ISRO and JAXA (Japan Aerospace Exploration Agency)?",
          "options": [
            "A joint mission to send a lunar rover and lander to explore water ice in the permanently shadowed regions of the Moon's south pole",
            "A mission to Mars",
            "An asteroid sample mission",
            "A space telescope"
          ],
          "correct": 0,
          "explanation": "LUPEX is an Indo-Japanese joint lunar mission where JAXA provides the rocket and rover, while ISRO develops the lander system to prospect for water ice."
        },
        {
          "id": 4,
          "question": "Which Earth Observation Satellite was launched by ISRO aboard SSLV-D3 in its final developmental flight in mid-2026?",
          "options": [
            "EOS-08",
            "EOS-06",
            "Cartosat-3",
            "Risat-2B"
          ],
          "correct": 0,
          "explanation": "ISRO successfully launched the Earth Observation Satellite EOS-08 aboard the Small Satellite Launch Vehicle (SSLV-D3) from Sriharikota, operationalizing the rocket."
        },
        {
          "id": 5,
          "question": "What three primary payloads are carried by ISRO's EOS-08 microsatellite?",
          "options": [
            "Electro-Optical Infrared (EOIR), Global Navigation Satellite System-Reflectometry (GNSS-R), and SiC UV Dosimeter",
            "Synthetic Aperture Radar only",
            "Camera only",
            "Atmospheric probe only"
          ],
          "correct": 0,
          "explanation": "EOS-08 features EOIR for thermal/wildfire monitoring, GNSS-R for ocean surface wind and soil moisture measurement, and a Silicon Carbide UV Dosimeter for Gaganyaan crew safety."
        },
        {
          "id": 6,
          "question": "What milestone did the Small Satellite Launch Vehicle (SSLV) achieve with the successful SSLV-D3 launch?",
          "options": [
            "Successful completion of the SSLV Development Programme, paving the way for commercial production by Indian industry / NSIL",
            "First manned flight",
            "Lunar orbit insertion",
            "Deep space escape"
          ],
          "correct": 0,
          "explanation": "SSLV-D3 marked the full operationalization of the launcher, enabling NewSpace India Limited (NSIL) to license technology to private industrial consortia."
        },
        {
          "id": 7,
          "question": "What is the commercial arm of ISRO incorporated under the administrative control of the Department of Space?",
          "options": [
            "NewSpace India Limited (NSIL)",
            "Antrix Corporation Limited",
            "IN-SPACe",
            "ISRO Telemetry"
          ],
          "correct": 0,
          "explanation": "NSIL, incorporated in 2019, is the central public sector commercial entity responsible for marketing ISRO space products, building satellites, and operating commercial launch services."
        },
        {
          "id": 8,
          "question": "What is the single-window nodal agency established to authorize, facilitate, and supervise space activities of non-government private entities (NGEs) in India?",
          "options": [
            "IN-SPACe (Indian National Space Promotion and Authorization Centre)",
            "NSIL",
            "Antrix",
            "Department of Science and Technology"
          ],
          "correct": 0,
          "explanation": "IN-SPACe acts as an autonomous single-window regulator and promoter for private space companies, startups, and academic institutions in India."
        },
        {
          "id": 9,
          "question": "Where are the headquarters of IN-SPACe located?",
          "options": [
            "Bopal, Ahmedabad, Gujarat",
            "Bengaluru, Karnataka",
            "Hyderabad, Telangana",
            "New Delhi"
          ],
          "correct": 0,
          "explanation": "The headquarters of IN-SPACe were inaugurated by Prime Minister Modi at Bopal in Ahmedabad."
        },
        {
          "id": 10,
          "question": "Which private Indian space-tech startup launched 'Agnibaan SOrTeD', India's first rocket powered by a single-piece 3D-printed semi-cryogenic engine?",
          "options": [
            "Agnikul Cosmos",
            "Skyroot Aerospace",
            "Pixxel",
            "Bellatrix Aerospace"
          ],
          "correct": 0,
          "explanation": "Chennai-based startup Agnikul Cosmos achieved the milestone launch of Agnibaan SOrTeD from India's first private launchpad (ALP-1) at Sriharikota."
        },
        {
          "id": 11,
          "question": "What is the name of the world's first single-piece 3D-printed rocket engine developed by Agnikul Cosmos?",
          "options": [
            "Agnilet Engine",
            "Dhawan-1",
            "Vikas Engine",
            "Raman Engine"
          ],
          "correct": 0,
          "explanation": "Agnilet is an indigenous semi-cryogenic rocket engine 3D-printed in one single piece using Inconel superalloy, eliminating hundreds of welded joints."
        },
        {
          "id": 12,
          "question": "Which was the first private Indian company to launch a privately developed rocket ('Vikram-S') into space in 2022 under Mission Prarambh?",
          "options": [
            "Skyroot Aerospace",
            "Agnikul Cosmos",
            "Dhruva Space",
            "TeamIndus"
          ],
          "correct": 0,
          "explanation": "Hyderabad-based Skyroot Aerospace made history on November 18, 2022, by launching the sub-orbital rocket Vikram-S from ISRO's spaceport at Sriharikota."
        },
        {
          "id": 13,
          "question": "Which Indian startup is launching a constellation of hyperspectral imaging satellites named 'Fireflies'?",
          "options": [
            "Pixxel",
            "Agnikul",
            "Skyroot",
            "Satellize"
          ],
          "correct": 0,
          "explanation": "Bengaluru-based space-tech startup Pixxel is deploying hyperspectral imaging satellites to detect gas leaks, crop diseases, and mining illegalities."
        },
        {
          "id": 14,
          "question": "What is 'Aditya-L1' launched by ISRO to study the Sun, and around which point in space is it halo-orbiting?",
          "options": [
            "Sun-Earth Lagrange Point 1 (L1), approximately 1.5 million km from Earth",
            "Lagrange Point 2 (L2)",
            "Low Earth Orbit",
            "Geostationary orbit"
          ],
          "correct": 0,
          "explanation": "Aditya-L1 was successfully inserted into a halo orbit around the first Lagrangian point (L1), providing an uninterrupted 24x7 view of the Sun without eclipses."
        },
        {
          "id": 15,
          "question": "What are the primary solar instruments aboard Aditya-L1 for observing the solar corona and chromosphere?",
          "options": [
            "VELC (Visible Emission Line Coronagraph) and SUIT (Solar Ultraviolet Imaging Telescope)",
            "ASTROSAT camera",
            "NavIC receiver",
            "Chandrayaan camera"
          ],
          "correct": 0,
          "explanation": "VELC (developed by Indian Institute of Astrophysics Bengaluru) and SUIT (developed by IUCAA Pune) observe solar flares, coronal mass ejections, and space weather."
        },
        {
          "id": 16,
          "question": "What is 'XPoSat' (X-ray Polarimeter Satellite) launched by ISRO in 2024?",
          "options": [
            "India's first dedicated polarimetry mission to study the dynamics of bright astronomical X-ray sources in extreme conditions",
            "Solar flare monitor",
            "Earth observation satellite",
            "Communications satellite"
          ],
          "correct": 0,
          "explanation": "XPoSat is only the world's second satellite-based X-ray polarimetry mission (after NASA's IXPE), carrying POLIX and XSPECT payloads built with Raman Research Institute."
        },
        {
          "id": 17,
          "question": "What is 'NISAR' satellite developed jointly by NASA and ISRO?",
          "options": [
            "NASA-ISRO Synthetic Aperture Radar (dual-frequency L-band and S-band radar satellite for global land and ice deformation monitoring)",
            "Mars orbiter",
            "Lunar rover",
            "Asteroid deflection satellite"
          ],
          "correct": 0,
          "explanation": "NISAR is an advanced Earth-observing satellite featuring dual-frequency SweepSAR technology (L-band from NASA, S-band from ISRO) to track natural hazards and ecosystem changes."
        },
        {
          "id": 18,
          "question": "Where is the Satellite Integration and Test Facility for the NISAR satellite located ahead of launch aboard GSLV?",
          "options": [
            "U R Rao Satellite Centre (URSC), Bengaluru",
            "Space Applications Centre, Ahmedabad",
            "VSSC, Thiruvananthapuram",
            "Satish Dhawan Space Centre, Sriharikota"
          ],
          "correct": 0,
          "explanation": "NASA's Jet Propulsion Laboratory (JPL) shipped the L-band radar payload to URSC in Bengaluru, where ISRO completed integration with the S-band payload and satellite bus."
        },
        {
          "id": 19,
          "question": "Which organization operates the Indian Deep Space Network (IDSN) antennas at Byalalu near Bengaluru for communicating with lunar and interplanetary probes?",
          "options": [
            "ISRO Telemetry, Tracking and Command Network (ISTRAC)",
            "VSSC",
            "National Remote Sensing Centre (NRSC)",
            "Liquid Propulsion Systems Centre (LPSC)"
          ],
          "correct": 0,
          "explanation": "ISTRAC manages the 18m and 32m deep-space antennas at Byalalu, tracking Chandrayaan, Mangalyaan, and Aditya-L1 missions across deep space."
        },
        {
          "id": 20,
          "question": "What is the primary role of the National Remote Sensing Centre (NRSC) situated in Hyderabad?",
          "options": [
            "Acquisition, processing, and dissemination of satellite data from remote sensing satellites",
            "Designing rocket engines",
            "Training astronauts",
            "Managing cryogenic fuels"
          ],
          "correct": 0,
          "explanation": "NRSC in Hyderabad is ISRO's lead center for satellite data acquisition from Indian and foreign remote sensing constellations, operating ground stations at Shadnagar."
        },
        {
          "id": 21,
          "question": "Where is the Master Control Facility (MCF) of ISRO located, which monitors and controls geostationary satellites?",
          "options": [
            "Hassan (Karnataka) and Bhopal (Madhya Pradesh)",
            "Sriharikota and Bengaluru",
            "Hyderabad and Thiruvananthapuram",
            "Ahmedabad and Pune"
          ],
          "correct": 0,
          "explanation": "ISRO's MCF operates two stations at Hassan in Karnataka (established 1982) and Bhopal in Madhya Pradesh (established 2005) for round-the-clock geostationary orbit operations."
        },
        {
          "id": 22,
          "question": "Where is the Vikram Sarabhai Space Centre (VSSC) situated, serving as the lead center for launch vehicle design and development?",
          "options": [
            "Thiruvananthapuram, Kerala",
            "Bengaluru, Karnataka",
            "Sriharikota, Andhra Pradesh",
            "Mahendragiri, Tamil Nadu"
          ],
          "correct": 0,
          "explanation": "VSSC at Thumba, Thiruvananthapuram, is ISRO's premier center for rocket technology, responsible for PSLV, GSLV, and LVM3 launch vehicles."
        },
        {
          "id": 23,
          "question": "Where is the ISRO Propulsion Complex (IPRC) located, where high-thrust cryogenic engines and stages are tested?",
          "options": [
            "Mahendragiri, Tirunelveli district, Tamil Nadu",
            "Valiamala, Kerala",
            "Aluva, Kerala",
            "Sriharikota, Andhra Pradesh"
          ],
          "correct": 0,
          "explanation": "IPRC Mahendragiri houses state-of-the-art testing complexes for liquid engines (Vikas, CE-7.5, CE-20) and high-altitude simulation facilities."
        },
        {
          "id": 24,
          "question": "Where is the Liquid Propulsion Systems Centre (LPSC) of ISRO headquartered?",
          "options": [
            "Valiamala near Thiruvananthapuram, Kerala",
            "Mahendragiri",
            "Bengaluru",
            "Ahmedabad"
          ],
          "correct": 0,
          "explanation": "LPSC is the center for design and development of liquid and cryogenic propulsion stages, with facilities at Valiamala in Kerala and Bengaluru in Karnataka."
        },
        {
          "id": 25,
          "question": "Where is the Space Applications Centre (SAC) of ISRO located, specializing in communication and optical/microwave imaging sensors?",
          "options": [
            "Ahmedabad, Gujarat",
            "Bengaluru, Karnataka",
            "Dehradun, Uttarakhand",
            "Pune, Maharashtra"
          ],
          "correct": 0,
          "explanation": "SAC in Ahmedabad designs communication payloads, transponders, meteorological cameras, and synthetic aperture radars for ISRO satellites."
        }
      ]
    },
    "science_tech_defence_aug2026": {
      "id": "science_tech_defence_aug2026",
      "category_id": "science_tech_defence",
      "category_name": "Science, Technology & Defence",
      "month_id": "aug2026",
      "month_name": "August 2026",
      "title": "Science & Defence Current Affairs - August 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "On which date was National Space Day celebrated for the second/third time across India, commemorating the historic soft landing of Chandrayaan-3?",
          "options": [
            "August 23",
            "August 15",
            "August 20",
            "August 29"
          ],
          "correct": 0,
          "explanation": "National Space Day is celebrated annually on August 23 to commemorate the soft landing of Chandrayaan-3's Vikram lander on the lunar surface on August 23, 2023."
        },
        {
          "id": 2,
          "question": "What was the official theme for National Space Day 2026?",
          "options": [
            "Touching Lives while Touching the Moon: India's Space Saga",
            "Viksit Bharat through Space Technology",
            "To the Moon and Beyond",
            "Indigenous Innovations in Orbit"
          ],
          "correct": 0,
          "explanation": "The theme highlighted the dual dimension of space exploration: planetary milestones and societal benefits like disaster management, agriculture, and communication."
        },
        {
          "id": 3,
          "question": "What is the official name given to the Chandrayaan-3 lunar landing site near the lunar south pole?",
          "options": [
            "Shiv Shakti Point",
            "Tiranga Point",
            "Jawahar Point",
            "Atal Point"
          ],
          "correct": 0,
          "explanation": "Prime Minister Narendra Modi named the touchdown point of Chandrayaan-3's lander as 'Shiv Shakti Point'."
        },
        {
          "id": 4,
          "question": "What was the impact point of Chandrayaan-2's Vikram lander in 2019 named as?",
          "options": [
            "Tiranga Point",
            "Shiv Shakti Point",
            "Jawahar Point",
            "Shakti Sthal"
          ],
          "correct": 0,
          "explanation": "The location where Chandrayaan-2 crash-landed on the Moon in September 2019 was designated as 'Tiranga Point'."
        },
        {
          "id": 5,
          "question": "What was the impact site of Chandrayaan-1's Moon Impact Probe (MIP) in November 2008 named as?",
          "options": [
            "Jawahar Point",
            "Tiranga Point",
            "Shiv Shakti Point",
            "Kalam Point"
          ],
          "correct": 0,
          "explanation": "The Moon Impact Probe touched down near Shackleton Crater on November 14, 2008 (Jawaharlal Nehru's birth anniversary), and the site was named 'Jawahar Point'."
        },
        {
          "id": 6,
          "question": "Which rover was deployed by Chandrayaan-3's Vikram lander to conduct in-situ chemical and elemental analysis of lunar regolith?",
          "options": [
            "Pragyan Rover",
            "Vigyan Rover",
            "Sojourner",
            "Yutu"
          ],
          "correct": 0,
          "explanation": "The 26 kg, 6-wheeled Pragyan rover rolled down Vikram's ramp, travelling over 100 metres and discovering sulfur on the lunar surface using its LIBS payload."
        },
        {
          "id": 7,
          "question": "What payload aboard Chandrayaan-3's Pragyan rover confirmed the presence of Sulfur (S) on the lunar surface near the south pole?",
          "options": [
            "Laser-Induced Breakdown Spectroscopy (LIBS)",
            "APXS",
            "ILSA",
            "ChaSTE"
          ],
          "correct": 0,
          "explanation": "The LIBS instrument, developed by Laboratory for Electro-Optics Systems (LEOS) Bengaluru, confirmed unambiguous sulfur signatures in lunar soil."
        },
        {
          "id": 8,
          "question": "What was the scientific objective of the 'ChaSTE' (Chandra's Surface Thermophysical Experiment) payload on the Vikram lander?",
          "options": [
            "To measure the thermal conductivity and temperature gradient of lunar topsoil up to 10 cm depth",
            "To measure moonquakes",
            "To detect water vapor",
            "To photograph landing site"
          ],
          "correct": 0,
          "explanation": "ChaSTE recorded a sharp temperature difference between the surface (around 50°C) and 8 cm underneath (-10°C), demonstrating the high insulating properties of lunar regolith."
        },
        {
          "id": 9,
          "question": "Which instrument aboard the Vikram lander recorded lunar seismic activity and vibrations generated by Pragyan rover movements?",
          "options": [
            "ILSA (Instrument for Lunar Seismic Activity)",
            "RAMBHA-LP",
            "ChaSTE",
            "APXS"
          ],
          "correct": 0,
          "explanation": "ILSA, a micro-electromechanical systems (MEMS) based seismometer developed by LEOS, detected lunar ground movements and micro-tremors."
        },
        {
          "id": 10,
          "question": "What unexpected milestone did ISRO achieve with the Vikram lander before the onset of the lunar night?",
          "options": [
            "A successful hop experiment (firing engines to elevate 40 cm and landing safely 30-40 cm away)",
            "Flying back into lunar orbit",
            "Deploying a satellite",
            "Surviving lunar night"
          ],
          "correct": 0,
          "explanation": "The successful hop test demonstrated restartable thruster capabilities and vertical takeoff, vital for future sample-return and human lunar missions."
        },
        {
          "id": 11,
          "question": "What is the primary role of DRDO's Hypersonic Technology Demonstrator Vehicle (HSTDV)?",
          "options": [
            "To demonstrate autonomous scramjet engine flight at speeds exceeding Mach 6 in the atmosphere",
            "Rocket booster for satellites",
            "Nuclear submarine engine",
            "Helicopter rotor test"
          ],
          "correct": 0,
          "explanation": "HSTDV is an unmanned scramjet demonstration aircraft capable of cruising at Mach 6 (over 2 km per second) using atmospheric oxygen for combustion."
        },
        {
          "id": 12,
          "question": "What type of air-breathing engine operates efficiently only at hypersonic speeds (above Mach 5) by combusting fuel in supersonic airflow?",
          "options": [
            "Scramjet (Supersonic Combusting Ramjet)",
            "Turbojet",
            "Turbofan",
            "Pulse-detonation engine"
          ],
          "correct": 0,
          "explanation": "Unlike turbojets or ramjets that decelerate intake air to subsonic speeds, a scramjet combusts fuel directly in supersonic airflow, enabling sustained hypersonic flight."
        },
        {
          "id": 13,
          "question": "What is 'Project Kusha' being undertaken by DRDO for the Indian Air Force?",
          "options": [
            "Indigenous Long-Range Surface-to-Air Defence Missile System (LR-SAM) with 350-400 km interception range, comparable to S-400",
            "Stealth fighter project",
            "Nuclear submarine development",
            "Cyber defense system"
          ],
          "correct": 0,
          "explanation": "Project Kusha will field a three-tier surface-to-air missile system capable of taking down stealth fighters, cruise missiles, precision-guided munitions, and ballistic missiles up to 350 km away."
        },
        {
          "id": 14,
          "question": "From which country did India procure the 'S-400 Triumf' air defence missile squadrons?",
          "options": [
            "Russia",
            "United States",
            "Israel",
            "France"
          ],
          "correct": 0,
          "explanation": "India signed a $5.43 billion contract with Russia in 2018 for five squadrons of the advanced S-400 Triumf long-range surface-to-air missile system."
        },
        {
          "id": 15,
          "question": "What is the operational designation given by the Indian Air Force to the deployed S-400 air defence missile systems?",
          "options": [
            "Sudarshan Chakra",
            "Vajra",
            "Akash",
            "Garuda"
          ],
          "correct": 0,
          "explanation": "The Indian Air Force named its deployed S-400 missile systems 'Sudarshan', invoking Lord Krishna's mythical defensive weapon."
        },
        {
          "id": 16,
          "question": "Which air base in Punjab received the first deployed squadron of the S-400 Sudarshan system to protect the northern and western skies?",
          "options": [
            "Halwara and Pathankot / Adampur air base sector",
            "Ambala",
            "Jodhpur",
            "Gwalior"
          ],
          "correct": 0,
          "explanation": "The first S-400 squadron was deployed along the Punjab sector to counter aerial threats across the western border."
        },
        {
          "id": 17,
          "question": "Which French fighter aircraft are operated by the Indian Air Force's Golden Arrows (No. 17 Squadron) at Ambala?",
          "options": [
            "Dassault Rafale",
            "Mirage 2000",
            "MiG-29",
            "Sukhoi Su-30MKI"
          ],
          "correct": 0,
          "explanation": "The IAF operates 36 Dassault Rafale 4.5-generation multi-role combat aircraft based at Ambala (No. 17 Golden Arrows) and Hasimara (No. 101 Falcons)."
        },
        {
          "id": 18,
          "question": "What long-range air-to-air missile gives the Rafale fighter unmatched beyond-visual-range combat superiority?",
          "options": [
            "Meteor Missile (ramjet powered with 150+ km range)",
            "SCALP cruise missile",
            "Hammer weapon",
            "Astra Mk-1"
          ],
          "correct": 0,
          "explanation": "The Meteor missile, powered by a solid-fuel variable-flow ducted ramjet, has a 'no-escape zone' more than three times greater than conventional air-to-air missiles."
        },
        {
          "id": 19,
          "question": "What is the stealth stand-off deep strike cruise missile carried by the IAF's Rafale aircraft?",
          "options": [
            "SCALP EG / Storm Shadow (range ~300-500 km)",
            "Meteor",
            "Hammer",
            "BrahMos-A"
          ],
          "correct": 0,
          "explanation": "SCALP is a long-range, air-launched, precision-guided cruise missile capable of striking hardened underground bunkers and high-value strategic targets."
        },
        {
          "id": 20,
          "question": "What precision-guided munition kit fitted on Rafale aircraft was rapidly acquired by India for high-altitude bunker busting?",
          "options": [
            "HAMMER (Highly Agile Modular Munition Extended Range)",
            "Spice 2000",
            "JDAM kit",
            "Paveway"
          ],
          "correct": 0,
          "explanation": "AASM Hammer is a rocket-assisted, modular precision standoff guidance kit produced by Safran, adaptable to various bomb bodies."
        },
        {
          "id": 21,
          "question": "Which DRDO laboratory in Hyderabad is the nodal center for the design and development of missile systems including Agni and Prithvi?",
          "options": [
            "Defence Research and Development Laboratory (DRDL)",
            "Research Centre Imarat (RCI)",
            "Advanced Systems Laboratory (ASL)",
            "All of the above (part of Dr. APJ Abdul Kalam Missile Complex)"
          ],
          "correct": 3,
          "explanation": "The Dr. APJ Abdul Kalam Missile Complex in Hyderabad comprises DRDL, RCI (founded by Kalam for avionics and navigation), and ASL (propulsion and composites)."
        },
        {
          "id": 22,
          "question": "Who founded the Research Centre Imarat (RCI) in Hyderabad in 1988 to spearhead indigenous missile guidance and navigation systems?",
          "options": [
            "Dr. APJ Abdul Kalam",
            "Dr. Homi Bhabha",
            "Dr. Vikram Sarabhai",
            "Dr. Raja Ramanna"
          ],
          "correct": 0,
          "explanation": "Dr. APJ Abdul Kalam conceptualized and founded RCI as a world-class avionics and seeker development laboratory under the Integrated Guided Missile Development Programme (IGMDP)."
        },
        {
          "id": 23,
          "question": "Which five missile systems were developed under the historic Integrated Guided Missile Development Programme (IGMDP) launched in 1983?",
          "options": [
            "PATNA: Prithvi, Agni, Trishul, Nag, and Akash",
            "Prithvi, Prahaar, Pinaka, Pralay, Nirbhay",
            "Agni, Astra, Akash, Arjun, Amogha",
            "BrahMos, Shaurya, Sagarika, Dhanush, K-15"
          ],
          "correct": 0,
          "explanation": "IGMDP, steered by Dr. Kalam, successfully developed the 'PATNA' missiles: Prithvi (surface-to-surface), Agni (re-entry ballistic), Trishul (short SAM), Nag (anti-tank), and Akash (medium SAM)."
        },
        {
          "id": 24,
          "question": "What is 'Pinaka' developed by DRDO and in service with the Indian Army?",
          "options": [
            "Multi-Barrel Rocket Launcher (MBRL) system",
            "Main Battle Tank",
            "Armoured personnel carrier",
            "Combat drone"
          ],
          "correct": 0,
          "explanation": "Pinaka is an indigenous all-weather multi-barrel rocket artillery system that can fire a salvo of 12 HE rockets in 44 seconds, with guided versions reaching up to 75-90 km."
        },
        {
          "id": 25,
          "question": "Which European nation placed a major defense export order to procure indigenous Pinaka multi-barrel rocket systems from India?",
          "options": [
            "Armenia",
            "Greece",
            "Poland",
            "Cyprus"
          ],
          "correct": 0,
          "explanation": "Armenia signed landmark government-to-government defense contracts to procure indigenous Pinaka rocket systems, Swathi radars, and ammunition from Indian manufacturers."
        }
      ]
    },
    "international_feb2026": {
      "id": "international_feb2026",
      "category_id": "international",
      "category_name": "International Affairs & Summits",
      "month_id": "feb2026",
      "month_name": "February 2026",
      "title": "International Affairs Current Affairs - February 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "Prime Minister Narendra Modi was invited as the Guest of Honour at the World Government Summit 2026 held in which city?",
          "options": [
            "Dubai, United Arab Emirates",
            "Riyadh, Saudi Arabia",
            "Doha, Qatar",
            "Abu Dhabi, UAE"
          ],
          "correct": 0,
          "explanation": "Prime Minister Narendra Modi addressed the World Government Summit in Dubai as the Guest of Honour, emphasizing the theme 'Shaping Future Governments'."
        },
        {
          "id": 2,
          "question": "Where was the first traditional stone Hindu temple in the Middle East—the BAPS Hindu Mandir—inaugurated by PM Modi in February 2026?",
          "options": [
            "Abu Dhabi, United Arab Emirates",
            "Dubai, UAE",
            "Muscat, Oman",
            "Manama, Bahrain"
          ],
          "correct": 0,
          "explanation": "The historic BAPS Hindu Mandir built on 27 acres of land gifted by UAE President Sheikh Mohamed bin Zayed Al Nahyan was consecrated at Abu Mreikhah in Abu Dhabi."
        },
        {
          "id": 3,
          "question": "Which country hosted the 13th Ministerial Conference (MC13) of the World Trade Organization (WTO) in February 2026?",
          "options": [
            "Abu Dhabi, United Arab Emirates",
            "Geneva, Switzerland",
            "Buenos Aires, Argentina",
            "Nairobi, Kenya"
          ],
          "correct": 0,
          "explanation": "The WTO MC13 was held in Abu Dhabi under the chairmanship of UAE Minister of State for Foreign Trade Dr. Thani bin Ahmed Al Zeyoudi."
        },
        {
          "id": 4,
          "question": "Who is the Director-General of the World Trade Organization (WTO)?",
          "options": [
            "Ngozi Okonjo-Iweala",
            "Kristalina Georgieva",
            "Tedros Adhanom Ghebreyesus",
            "Rebeca Grynspan"
          ],
          "correct": 0,
          "explanation": "Dr. Ngozi Okonjo-Iweala of Nigeria is the first woman and first African to serve as the Director-General of the World Trade Organization."
        },
        {
          "id": 5,
          "question": "Where are the headquarters of the World Trade Organization (WTO) located?",
          "options": [
            "Geneva, Switzerland",
            "New York, USA",
            "Vienna, Austria",
            "Paris, France"
          ],
          "correct": 0,
          "explanation": "The WTO, established on January 1, 1995, pursuant to the 1994 Marrakesh Agreement, is headquartered at the Centre William Rappard in Geneva."
        },
        {
          "id": 6,
          "question": "Which international security conference held its 60th/62nd annual session in February 2026, often described as the 'Davos of Defence'?",
          "options": [
            "Munich Security Conference (MSC)",
            "Shangri-La Dialogue",
            "Raisina Dialogue",
            "Halifax International Security Forum"
          ],
          "correct": 0,
          "explanation": "The Munich Security Conference is the world's leading forum for debating international security policy, held annually at the Hotel Bayerischer Hof in Munich, Germany."
        },
        {
          "id": 7,
          "question": "Which country held the rotating G20 Presidency during 2024, leading into the G20 Sherpa and foreign ministers meetings?",
          "options": [
            "Brazil",
            "South Africa",
            "India",
            "Indonesia"
          ],
          "correct": 0,
          "explanation": "Brazil held the G20 Presidency under the theme 'Building a Just World and a Sustainable Planet', succeeded by South Africa."
        },
        {
          "id": 8,
          "question": "What is the 'Troika' in G20 terminology?",
          "options": [
            "The grouping consisting of the previous, current, and incoming G20 Presidencies",
            "The three founding nations",
            "The three permanent secretariats",
            "The heads of IMF, World Bank, and WTO"
          ],
          "correct": 0,
          "explanation": "The G20 Troika represents continuity in governance and consists of the previous host country (India), current host (Brazil), and next host (South Africa)."
        },
        {
          "id": 9,
          "question": "Which continental body was formally inducted as a permanent member of the G20 during the New Delhi Summit in 2023 under India's Presidency?",
          "options": [
            "The African Union (AU)",
            "ASEAN",
            "European Union",
            "Organization of American States"
          ],
          "correct": 0,
          "explanation": "The 55-nation African Union was formally inducted as a permanent member of the G20 at the historic New Delhi Summit under Prime Minister Modi."
        },
        {
          "id": 10,
          "question": "Who is the Chairperson of the African Union Commission?",
          "options": [
            "Moussa Faki Mahamat",
            "Cyril Ramaphosa",
            "William Ruto",
            "Paul Kagame"
          ],
          "correct": 0,
          "explanation": "Moussa Faki Mahamat of Chad serves as the Chairperson of the African Union Commission, headquartered in Addis Ababa, Ethiopia."
        },
        {
          "id": 11,
          "question": "Where are the permanent headquarters of the African Union (AU) located?",
          "options": [
            "Addis Ababa, Ethiopia",
            "Nairobi, Kenya",
            "Cairo, Egypt",
            "Johannesburg, South Africa"
          ],
          "correct": 0,
          "explanation": "The African Union was established in 2002 (replacing the Organization of African Unity) and is based in Addis Ababa, Ethiopia."
        },
        {
          "id": 12,
          "question": "Which country officially joined the NATO alliance in early 2024 as its 32nd member, completing its historic accession process?",
          "options": [
            "Sweden",
            "Finland",
            "Ukraine",
            "Georgia"
          ],
          "correct": 0,
          "explanation": "Sweden formally became the 32nd member of the North Atlantic Treaty Organization (NATO) after depositing its instrument of accession in Washington, following Finland's accession as the 31st member."
        },
        {
          "id": 13,
          "question": "Who serves as the Secretary General of NATO, succeeding Jens Stoltenberg in 2024?",
          "options": [
            "Mark Rutte (former Prime Minister of the Netherlands)",
            "Jens Stoltenberg",
            "Alexander Stubb",
            "Kaja Kallas"
          ],
          "correct": 0,
          "explanation": "Former Dutch Prime Minister Mark Rutte was unanimously appointed as the new Secretary General of NATO, taking office in October 2024."
        },
        {
          "id": 14,
          "question": "Where are the political headquarters of the North Atlantic Treaty Organization (NATO) located?",
          "options": [
            "Brussels, Belgium",
            "The Hague, Netherlands",
            "Strasbourg, France",
            "Geneva, Switzerland"
          ],
          "correct": 0,
          "explanation": "NATO's political headquarters are located on Boulevard Léopold III in Brussels, Belgium."
        },
        {
          "id": 15,
          "question": "Which bilateral payment linkage was launched between India and Sri Lanka and Mauritius via virtual ceremony in February 2026?",
          "options": [
            "Unified Payments Interface (UPI) and RuPay card services",
            "SWIFT alternate network",
            "Asian Clearing Union digital dollar",
            "Crypto gateway"
          ],
          "correct": 0,
          "explanation": "Prime Minister Modi, Sri Lankan President Ranil Wickremesinghe, and Mauritian PM Pravind Jugnauth launched UPI and RuPay connectivity in Sri Lanka and Mauritius."
        },
        {
          "id": 16,
          "question": "On which island did India inaugurate a newly upgraded airstrip and marine jetty constructed under bilateral grant assistance with Mauritius?",
          "options": [
            "Agalega Island",
            "Rodriguez Island",
            "Diego Garcia",
            "Chagos Archipelago"
          ],
          "correct": 0,
          "explanation": "India and Mauritius jointly inaugurated the 3,000-metre airstrip and St. James Jetty on North Agalega Island to enhance maritime domain awareness."
        },
        {
          "id": 17,
          "question": "Which country withdrew its military personnel operating civilian medical helicopters in the Maldives following a request by President Mohamed Muizzu?",
          "options": [
            "India (replaced by Indian civilian technical teams)",
            "United States",
            "China",
            "United Kingdom"
          ],
          "correct": 0,
          "explanation": "India agreed to replace active military personnel operating two ALH Dhruv helicopters and a Dornier aircraft in the Maldives with competent civilian technical operators."
        },
        {
          "id": 18,
          "question": "What is the capital city of the Maldives?",
          "options": [
            "Male",
            "Addu City",
            "Fuvahmulah",
            "Kulhudhuffushi"
          ],
          "correct": 0,
          "explanation": "Male is the densely populated capital city and financial hub of the Republic of Maldives."
        },
        {
          "id": 19,
          "question": "Which international organization publishes the annual 'Corruption Perceptions Index' (CPI)?",
          "options": [
            "Transparency International",
            "World Justice Project",
            "Amnesty International",
            "World Bank"
          ],
          "correct": 0,
          "explanation": "Berlin-based global civil society organization Transparency International publishes the annual Corruption Perceptions Index ranking 180 countries."
        },
        {
          "id": 20,
          "question": "Where are the headquarters of Transparency International located?",
          "options": [
            "Berlin, Germany",
            "London, UK",
            "Geneva, Switzerland",
            "Paris, France"
          ],
          "correct": 0,
          "explanation": "Transparency International was founded in 1993 and is headquartered in Berlin, Germany."
        },
        {
          "id": 21,
          "question": "Which country consistently ranks first (least corrupt) in Transparency International's Corruption Perceptions Index?",
          "options": [
            "Denmark",
            "Finland",
            "New Zealand",
            "Norway"
          ],
          "correct": 0,
          "explanation": "Denmark has maintained the top ranking for several consecutive years as the country perceived to have the cleanest public sector."
        },
        {
          "id": 22,
          "question": "What is the name of the naval exercise conducted in the Arabian Sea under the Combined Maritime Forces (CMF) coalition in which Indian Navy participates as an associate/full partner?",
          "options": [
            "Combined Task Force 150 / 151 (CTF 150)",
            "Operation Prosperity Guardian",
            "Operation Atalanta",
            "Operation Sentinel"
          ],
          "correct": 0,
          "explanation": "The Combined Maritime Forces (CMF), based in Bahrain, coordinates multinational maritime security and counter-piracy patrols across the Western Indian Ocean."
        },
        {
          "id": 23,
          "question": "Where are the headquarters of the United States Fifth Fleet located?",
          "options": [
            "Manama, Bahrain",
            "Doha, Qatar",
            "Abu Dhabi, UAE",
            "Muscat, Oman"
          ],
          "correct": 0,
          "explanation": "The United States Naval Forces Central Command / Fifth Fleet is based at Naval Support Activity Bahrain in Manama."
        },
        {
          "id": 24,
          "question": "Which body within the United Nations has the primary responsibility for the maintenance of international peace and security under Article 24 of the UN Charter?",
          "options": [
            "UN Security Council (UNSC)",
            "UN General Assembly",
            "International Court of Justice",
            "UN Secretariat"
          ],
          "correct": 0,
          "explanation": "The UN Security Council has primary responsibility for maintaining international peace and security and is the only UN organ with authority to issue binding resolutions."
        },
        {
          "id": 25,
          "question": "How many permanent and non-permanent members comprise the United Nations Security Council (UNSC)?",
          "options": [
            "15 members (5 permanent members: US, UK, France, Russia, China; and 10 non-permanent members elected for 2-year terms)",
            "20 members",
            "10 members",
            "12 members"
          ],
          "correct": 0,
          "explanation": "The UNSC consists of 5 veto-wielding permanent members (P5) and 10 non-permanent members elected by the General Assembly for staggered two-year mandates."
        }
      ]
    },
    "international_mar2026": {
      "id": "international_mar2026",
      "category_id": "international",
      "category_name": "International Affairs & Summits",
      "month_id": "mar2026",
      "month_name": "March 2026",
      "title": "International Affairs Current Affairs - March 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "The 9th/10th edition of the 'Raisina Dialogue', India's premier conference on geopolitics and geo-economics, was held in New Delhi in March. Who was the Chief Guest and Keynote Speaker?",
          "options": [
            "Kyriakos Mitsotakis (Prime Minister of Greece)",
            "Giorgia Meloni (Prime Minister of Italy)",
            "Emmanuel Macron (President of France)",
            "Ursula von der Leyen"
          ],
          "correct": 0,
          "explanation": "Prime Minister of Greece Kyriakos Mitsotakis was the Chief Guest at the Raisina Dialogue, organized by the Observer Research Foundation (ORF) in partnership with MEA."
        },
        {
          "id": 2,
          "question": "What was the overarching theme of the Raisina Dialogue 2026?",
          "options": [
            "Chaturanga: Conflict, Contest, Cooperate, Create",
            "Provocation, Uncertainty, Turbulence",
            "Terra Nova: Insular, Impassioned, Imperilled",
            "Building Bridges across Oceans"
          ],
          "correct": 0,
          "explanation": "The theme 'Chaturanga: Conflict, Contest, Cooperate, Create' explored evolving global balance of power and emerging security architectures."
        },
        {
          "id": 3,
          "question": "India signed a historic Trade and Economic Partnership Agreement (TEPA) in March 2026 with which European intergovernmental organization, unlocking a commitment of $100 billion in investment?",
          "options": [
            "EFTA (European Free Trade Association comprising Iceland, Liechtenstein, Norway, and Switzerland)",
            "European Union",
            "OECD",
            "Commonwealth of Nations"
          ],
          "correct": 0,
          "explanation": "India signed the TEPA with EFTA, marking the first time in an Indian trade pact that partner countries legally committed to investing $100 billion over 15 years to generate 1 million direct jobs."
        },
        {
          "id": 4,
          "question": "Which four nations comprise the European Free Trade Association (EFTA)?",
          "options": [
            "Switzerland, Norway, Iceland, and Liechtenstein",
            "Switzerland, Sweden, Norway, Denmark",
            "Austria, Switzerland, Norway, Finland",
            "UK, Switzerland, Norway, Ireland"
          ],
          "correct": 0,
          "explanation": "EFTA was founded in 1960 and consists of four non-EU European countries: Iceland, Liechtenstein, Norway, and Switzerland."
        },
        {
          "id": 5,
          "question": "Where are the headquarters of the European Free Trade Association (EFTA) located?",
          "options": [
            "Geneva, Switzerland",
            "Brussels, Belgium",
            "Vaduz, Liechtenstein",
            "Oslo, Norway"
          ],
          "correct": 0,
          "explanation": "The EFTA Secretariat is located in Geneva, Switzerland, with additional offices in Brussels and Luxembourg."
        },
        {
          "id": 6,
          "question": "Which country hosted the 6th NSA-Level Meeting of the 'Colombo Security Conclave' (CSC) in March 2026?",
          "options": [
            "Mauritius",
            "Maldives",
            "Sri Lanka",
            "India"
          ],
          "correct": 0,
          "explanation": "Mauritius hosted the meeting, with member states (India, Sri Lanka, Mauritius, and Maldives) signing the Founding Charter and MoU establishing the permanent CSC Secretariat in Colombo."
        },
        {
          "id": 7,
          "question": "Which country officially signed the CSC Charter in 2024 to become the 5th full member of the Colombo Security Conclave?",
          "options": [
            "Bangladesh",
            "Seychelles",
            "Madagascar",
            "Oman"
          ],
          "correct": 0,
          "explanation": "Bangladesh joined the regional security grouping as its fifth full member alongside India, Sri Lanka, Mauritius, and Maldives (with Seychelles as observer)."
        },
        {
          "id": 8,
          "question": "What are the five core pillars of cooperation under the Colombo Security Conclave?",
          "options": [
            "Maritime safety, counter-terrorism, combating trafficking, cyber security, and critical infrastructure protection",
            "Trade tariff reduction only",
            "Fisheries dispute resolution",
            "Sports exchanges"
          ],
          "correct": 0,
          "explanation": "CSC focuses on: 1) Maritime Safety & Security, 2) Countering Terrorism & Radicalization, 3) Combating Trafficking & Transnational Crime, 4) Cyber Security & Critical Infrastructure, and 5) HADR."
        },
        {
          "id": 9,
          "question": "Who is the current Secretary-General of the United Nations, serving his second five-year term?",
          "options": [
            "Antonio Guterres (former Prime Minister of Portugal)",
            "Ban Ki-moon",
            "Kofi Annan",
            "Boutros Boutros-Ghali"
          ],
          "correct": 0,
          "explanation": "Antonio Guterres was appointed as the ninth Secretary-General of the United Nations by the General Assembly in 2017 and was re-elected for a second term commencing January 2022."
        },
        {
          "id": 10,
          "question": "Where are the headquarters of the United Nations situated?",
          "options": [
            "New York City, United States (Manhattan)",
            "Geneva, Switzerland",
            "The Hague, Netherlands",
            "Vienna, Austria"
          ],
          "correct": 0,
          "explanation": "The official world headquarters of the United Nations is an international zone located along First Avenue in Manhattan, New York City."
        },
        {
          "id": 11,
          "question": "Where is the principal judicial organ of the United Nations—the International Court of Justice (ICJ)—located?",
          "options": [
            "The Peace Palace in The Hague, Netherlands",
            "Geneva, Switzerland",
            "New York City",
            "Strasbourg, France"
          ],
          "correct": 0,
          "explanation": "The ICJ is the only one of the six principal organs of the United Nations not located in New York City, holding its seat at the Peace Palace in The Hague."
        },
        {
          "id": 12,
          "question": "How many judges serve on the International Court of Justice (ICJ), and what is their term of office?",
          "options": [
            "15 judges elected for 9-year terms by the UN General Assembly and Security Council",
            "10 judges for 5 years",
            "12 judges for 7 years",
            "9 judges for life"
          ],
          "correct": 0,
          "explanation": "The ICJ consists of 15 judges elected for nine-year terms, with one-third of the court (5 judges) retiring every three years."
        },
        {
          "id": 13,
          "question": "Who is the sitting Indian judge at the International Court of Justice (ICJ)?",
          "options": [
            "Justice Dalveer Bhandari",
            "Justice Nagendra Singh",
            "Justice B.N. Rau",
            "Justice R.S. Pathak"
          ],
          "correct": 0,
          "explanation": "Justice Dalveer Bhandari was first elected to the ICJ in 2012 and was re-elected in 2017 for a second full nine-year term ending in 2027."
        },
        {
          "id": 14,
          "question": "Who was the first Indian to serve as the President of the International Court of Justice (ICJ)?",
          "options": [
            "Dr. Nagendra Singh",
            "Sir B.N. Rau",
            "Justice R.S. Pathak",
            "Justice Dalveer Bhandari"
          ],
          "correct": 0,
          "explanation": "Dr. Nagendra Singh served as a Judge at the ICJ from 1973 and was elected as its President from 1985 to 1988."
        },
        {
          "id": 15,
          "question": "Which country hosted the 3rd Summit for Democracy in March 2026?",
          "options": [
            "Seoul, South Korea",
            "Tokyo, Japan",
            "Washington D.C., USA",
            "London, UK"
          ],
          "correct": 0,
          "explanation": "South Korea hosted the 3rd Summit for Democracy in Seoul, focusing on 'Democracy for Future Generations' and AI impacts on electoral integrity."
        },
        {
          "id": 16,
          "question": "Which country officially legalized same-sex marriage in March 2026, becoming the first Southeast Asian nation to do so?",
          "options": [
            "Thailand",
            "Vietnam",
            "Singapore",
            "The Philippines"
          ],
          "correct": 0,
          "explanation": "The Thai Senate overwhelmingly passed the marriage equality bill, making Thailand the third jurisdiction in Asia (after Taiwan and Nepal) to legalize same-sex marriage."
        },
        {
          "id": 17,
          "question": "Which country became the newest member of the International Solar Alliance (ISA) in early 2024?",
          "options": [
            "Panama and Spain (surpassing 100 ratified members)",
            "China",
            "Russia",
            "Brazil"
          ],
          "correct": 0,
          "explanation": "Panama ratified the ISA Framework Agreement, with ISA membership expanding rapidly to over 100 full ratified member states globally."
        },
        {
          "id": 18,
          "question": "Where are the interim/permanent headquarters of the International Solar Alliance (ISA) located?",
          "options": [
            "National Institute of Solar Energy (NISE) campus, Gurugram, Haryana, India",
            "New Delhi",
            "Paris, France",
            "Abu Dhabi, UAE"
          ],
          "correct": 0,
          "explanation": "ISA, launched jointly by India and France at COP21 in Paris, is the first international treaty-based intergovernmental organization headquartered in India (Gurugram)."
        },
        {
          "id": 19,
          "question": "Who is the Director General of the International Solar Alliance (ISA)?",
          "options": [
            "Dr. Ajay Mathur / Ashish Khanna",
            "Upendra Tripathy",
            "Sultan Al Jaber",
            "Fatih Birol"
          ],
          "correct": 0,
          "explanation": "Dr. Ajay Mathur led the ISA Secretariat, followed by leadership transitions overseen by the Ministry of New and Renewable Energy."
        },
        {
          "id": 20,
          "question": "What is the visionary global initiative promoted by India through the ISA to create an interconnected green power grid?",
          "options": [
            "OSOWOG (One Sun One World One Grid)",
            "Solar Grid 2030",
            "Global Sun Mission",
            "SunPower Interconnect"
          ],
          "correct": 0,
          "explanation": "OSOWOG aims to interconnect regional electrical grids across continents so that 'The Sun Never Sets' on clean renewable energy production."
        },
        {
          "id": 21,
          "question": "Where are the headquarters of the Coalition for Disaster Resilient Infrastructure (CDRI), launched by India at the UN Climate Action Summit?",
          "options": [
            "New Delhi, India",
            "Geneva, Switzerland",
            "Tokyo, Japan",
            "Nairobi, Kenya"
          ],
          "correct": 0,
          "explanation": "CDRI is an international coalition headquartered in New Delhi, focusing on climate-resilient roads, telecom, and power systems in developing nations."
        },
        {
          "id": 22,
          "question": "Which country's capital hosted the ASEAN-India Senior Officials' Meeting (AISOM) in March 2026?",
          "options": [
            "Vientiane, Laos",
            "Jakarta, Indonesia",
            "Hanoi, Vietnam",
            "Bangkok, Thailand"
          ],
          "correct": 0,
          "explanation": "Laos, holding the ASEAN Chairmanship for 2024, hosted high-level ASEAN-India meetings in its capital Vientiane."
        },
        {
          "id": 23,
          "question": "Where are the headquarters of the Association of Southeast Asian Nations (ASEAN) located?",
          "options": [
            "Jakarta, Indonesia",
            "Singapore",
            "Manila, Philippines",
            "Kuala Lumpur, Malaysia"
          ],
          "correct": 0,
          "explanation": "The ASEAN Secretariat is situated in Jakarta, Indonesia. ASEAN was founded in August 1967 with the Bangkok Declaration."
        },
        {
          "id": 24,
          "question": "How many member countries currently constitute ASEAN, with which nation slated as its 11th member?",
          "options": [
            "10 members, with Timor-Leste admitted in principle as the 11th member",
            "9 members",
            "12 members",
            "8 members"
          ],
          "correct": 0,
          "explanation": "ASEAN has 10 members: Brunei, Cambodia, Indonesia, Laos, Malaysia, Myanmar, Philippines, Singapore, Thailand, and Vietnam; Timor-Leste holds observer status progressing toward full membership."
        },
        {
          "id": 25,
          "question": "Where are the headquarters of the Bay of Bengal Initiative for Multi-Sectoral Technical and Economic Cooperation (BIMSTEC) located?",
          "options": [
            "Dhaka, Bangladesh",
            "New Delhi, India",
            "Colombo, Sri Lanka",
            "Bangkok, Thailand"
          ],
          "correct": 0,
          "explanation": "The BIMSTEC Permanent Secretariat was established in Dhaka, Bangladesh, in 2014."
        }
      ]
    },
    "international_apr2026": {
      "id": "international_apr2026",
      "category_id": "international",
      "category_name": "International Affairs & Summits",
      "month_id": "apr2026",
      "month_name": "April 2026",
      "title": "International Affairs Current Affairs - April 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "How many member states constitute BIMSTEC?",
          "options": [
            "7 member states (Bangladesh, Bhutan, India, Myanmar, Nepal, Sri Lanka, and Thailand)",
            "5 member states",
            "8 member states",
            "10 member states"
          ],
          "correct": 0,
          "explanation": "BIMSTEC brings together five South Asian nations (India, Nepal, Bhutan, Bangladesh, Sri Lanka) and two Southeast Asian nations (Myanmar, Thailand)."
        },
        {
          "id": 2,
          "question": "In which year was BIMSTEC established through the Bangkok Declaration?",
          "options": [
            "1997 (June 6, 1997)",
            "1985",
            "2001",
            "1992"
          ],
          "correct": 0,
          "explanation": "BIMSTEC was founded in 1997 initially as BIST-EC (Bangladesh, India, Sri Lanka, Thailand Economic Cooperation), expanding later to include Myanmar, Nepal, and Bhutan."
        },
        {
          "id": 3,
          "question": "Which country held the Chairmanship of BIMSTEC leading up to the 6th BIMSTEC Summit in 2024-2026?",
          "options": [
            "Thailand",
            "Sri Lanka",
            "Nepal",
            "India"
          ],
          "correct": 0,
          "explanation": "Thailand held the Chair of BIMSTEC, hosting ministerial and leaders' conclaves in Bangkok under the theme 'Prosperous, Resilient and Open BIMSTEC'."
        },
        {
          "id": 4,
          "question": "Where are the headquarters of the South Asian Association for Regional Cooperation (SAARC) located?",
          "options": [
            "Kathmandu, Nepal",
            "New Delhi, India",
            "Dhaka, Bangladesh",
            "Islamabad, Pakistan"
          ],
          "correct": 0,
          "explanation": "The SAARC Secretariat was set up in Kathmandu on January 16, 1987. SAARC was founded in Dhaka in 1985."
        },
        {
          "id": 5,
          "question": "How many member countries are there in SAARC?",
          "options": [
            "8 countries (Afghanistan, Bangladesh, Bhutan, India, Maldives, Nepal, Pakistan, Sri Lanka)",
            "7 countries",
            "9 countries",
            "6 countries"
          ],
          "correct": 0,
          "explanation": "SAARC comprises 8 member nations, with Afghanistan joining as the eighth member at the 14th SAARC Summit in New Delhi in 2007."
        },
        {
          "id": 6,
          "question": "Where are the headquarters of the Shanghai Cooperation Organisation (SCO) Secretariat located?",
          "options": [
            "Beijing, China",
            "Tashkent, Uzbekistan",
            "Astana, Kazakhstan",
            "Moscow, Russia"
          ],
          "correct": 0,
          "explanation": "The permanent Secretariat of the SCO is located in Beijing, China, while its counter-terrorism body RATS is in Tashkent."
        },
        {
          "id": 7,
          "question": "Where are the headquarters of the Regional Anti-Terrorist Structure (RATS) of the SCO situated?",
          "options": [
            "Tashkent, Uzbekistan",
            "Beijing, China",
            "Bishkek, Kyrgyzstan",
            "Dushanbe, Tajikistan"
          ],
          "correct": 0,
          "explanation": "Executive Committee of SCO RATS is a permanent body based in Tashkent, Uzbekistan, coordinating intelligence-sharing on terrorism, separatism, and extremism."
        },
        {
          "id": 8,
          "question": "Which country officially joined as the 10th full member state of the Shanghai Cooperation Organisation (SCO) in 2024?",
          "options": [
            "Belarus",
            "Iran",
            "Mongolia",
            "Turkey"
          ],
          "correct": 0,
          "explanation": "Belarus officially joined the SCO as its 10th member state at the Astana Summit in July 2024, following Iran's induction as the 9th member in 2023."
        },
        {
          "id": 9,
          "question": "In which year did India and Pakistan formally become full members of the Shanghai Cooperation Organisation (SCO)?",
          "options": [
            "2017 (Astana Summit)",
            "2015",
            "2019",
            "2020"
          ],
          "correct": 0,
          "explanation": "India and Pakistan were formally inducted as full members of the SCO during the historical Astana Summit in Kazakhstan in June 2017."
        },
        {
          "id": 10,
          "question": "Which country hosted the SCO Defence Ministers Meeting in April 2026?",
          "options": [
            "Astana, Kazakhstan",
            "New Delhi, India",
            "Beijing, China",
            "Tashkent, Uzbekistan"
          ],
          "correct": 0,
          "explanation": "Kazakhstan held the 2024 rotating Presidency of the SCO and hosted the Defence Ministers and Foreign Ministers in Astana."
        },
        {
          "id": 11,
          "question": "What magnitude earthquake struck Hualien County on Taiwan's eastern coast in April 2026, triggering international search & rescue responses?",
          "options": [
            "Magnitude 7.4",
            "Magnitude 6.2",
            "Magnitude 8.1",
            "Magnitude 6.9"
          ],
          "correct": 0,
          "explanation": "A powerful 7.4-magnitude earthquake struck Hualien, Taiwan's strongest quake in 25 years, with strict seismic building codes keeping casualties remarkably low."
        },
        {
          "id": 12,
          "question": "Where are the headquarters of the International Atomic Energy Agency (IAEA) situated?",
          "options": [
            "Vienna, Austria",
            "Geneva, Switzerland",
            "Paris, France",
            "Helsinki, Finland"
          ],
          "correct": 0,
          "explanation": "The IAEA ('Atoms for Peace and Development') is headquartered at the Vienna International Centre in Austria."
        },
        {
          "id": 13,
          "question": "Who is the Director General of the International Atomic Energy Agency (IAEA)?",
          "options": [
            "Rafael Mariano Grossi (Argentina)",
            "Yukiya Amano",
            "Mohamed ElBaradei",
            "Hans Blix"
          ],
          "correct": 0,
          "explanation": "Argentine diplomat Rafael Mariano Grossi has served as Director General of the IAEA since 2019."
        },
        {
          "id": 14,
          "question": "Where are the headquarters of the Organization of the Petroleum Exporting Countries (OPEC) located?",
          "options": [
            "Vienna, Austria",
            "Riyadh, Saudi Arabia",
            "Kuwait City",
            "Abu Dhabi, UAE"
          ],
          "correct": 0,
          "explanation": "OPEC was founded in Baghdad in 1960 and relocated its headquarters to Vienna, Austria in 1965 (even though Austria is not an OPEC member)."
        },
        {
          "id": 15,
          "question": "Which African oil-producing nation officially announced its withdrawal from OPEC in early 2024 following disagreements over output quotas?",
          "options": [
            "Angola",
            "Nigeria",
            "Gabon",
            "Equatorial Guinea"
          ],
          "correct": 0,
          "explanation": "Angola exited OPEC after 16 years of membership, rejecting production quota cuts imposed by the cartel."
        },
        {
          "id": 16,
          "question": "What does 'OPEC+' denote in global energy markets?",
          "options": [
            "OPEC member countries plus 10 non-OPEC oil producing nations led by Russia",
            "OPEC and OECD combined",
            "OPEC plus USA and Canada",
            "OPEC with African Union"
          ],
          "correct": 0,
          "explanation": "OPEC+ was formed in late 2016 by 12 OPEC members and 10 non-OPEC allies (including Russia, Kazakhstan, Oman, and Mexico) to coordinate oil supply."
        },
        {
          "id": 17,
          "question": "Where are the headquarters of the International Energy Agency (IEA) located?",
          "options": [
            "Paris, France",
            "Vienna, Austria",
            "London, UK",
            "Brussels, Belgium"
          ],
          "correct": 0,
          "explanation": "The IEA was created in 1974 within the OECD framework following the 1973 oil crisis and is headquartered in Paris."
        },
        {
          "id": 18,
          "question": "What is India's formal association status with the International Energy Agency (IEA)?",
          "options": [
            "Association Country (since 2017, with talks underway for full membership)",
            "Permanent Member",
            "Founding Member",
            "No official ties"
          ],
          "correct": 0,
          "explanation": "India became an Associate Member of the IEA in March 2017 and entered formal discussions for full membership in 2023-2024."
        },
        {
          "id": 19,
          "question": "Where are the headquarters of the International Maritime Organization (IMO) situated?",
          "options": [
            "London, United Kingdom",
            "Geneva, Switzerland",
            "Rotterdam, Netherlands",
            "Monaco"
          ],
          "correct": 0,
          "explanation": "The IMO, the specialized UN agency responsible for the safety of shipping and marine pollution prevention, is headquartered in London along the River Thames."
        },
        {
          "id": 20,
          "question": "Who is the Secretary-General of the International Maritime Organization (IMO)?",
          "options": [
            "Arsenio Dominguez (Panama)",
            "Kitack Lim",
            "Koji Sekimizu",
            "Efthimios Mitropoulos"
          ],
          "correct": 0,
          "explanation": "Arsenio Dominguez of Panama assumed office as the Secretary-General of the IMO on January 1, 2024."
        },
        {
          "id": 21,
          "question": "Where are the headquarters of the International Civil Aviation Organization (ICAO) located?",
          "options": [
            "Montreal, Canada",
            "Chicago, USA",
            "Geneva, Switzerland",
            "Paris, France"
          ],
          "correct": 0,
          "explanation": "ICAO was established by the 1944 Chicago Convention on International Civil Aviation and has its headquarters in Montreal, Quebec, Canada."
        },
        {
          "id": 22,
          "question": "Where are the headquarters of the Universal Postal Union (UPU) located?",
          "options": [
            "Bern, Switzerland",
            "Geneva, Switzerland",
            "Zurich, Switzerland",
            "Brussels, Belgium"
          ],
          "correct": 0,
          "explanation": "The Universal Postal Union, established by the Treaty of Bern in 1874, is the second oldest international organization and is based in Bern."
        },
        {
          "id": 23,
          "question": "Where are the headquarters of the International Telecommunication Union (ITU) located?",
          "options": [
            "Geneva, Switzerland",
            "Paris, France",
            "Vienna, Austria",
            "New York, USA"
          ],
          "correct": 0,
          "explanation": "The ITU, founded in 1865 as the International Telegraph Union, is the oldest UN specialized agency, headquartered in Geneva."
        },
        {
          "id": 24,
          "question": "Where did the ITU open its Area Office and Innovation Centre in South Asia in 2023?",
          "options": [
            "New Delhi, India",
            "Dhaka, Bangladesh",
            "Colombo, Sri Lanka",
            "Kathmandu, Nepal"
          ],
          "correct": 0,
          "explanation": "Prime Minister Narendra Modi inaugurated the new ITU Area Office and Innovation Centre for South Asia at the MeitY complex in New Delhi."
        },
        {
          "id": 25,
          "question": "What is the 'Global Digital Compact' adopted by the United Nations Summit of the Future in 2024?",
          "options": [
            "A comprehensive UN framework for open, free, secure, and human-centred digital cooperation and AI governance",
            "A cryptocurrency trade treaty",
            "A space internet treaty",
            "A satellite tax agreement"
          ],
          "correct": 0,
          "explanation": "The Global Digital Compact establishes shared principles for universal internet access, digital public goods, data protection, and responsible artificial intelligence."
        }
      ]
    },
    "international_may2026": {
      "id": "international_may2026",
      "category_id": "international",
      "category_name": "International Affairs & Summits",
      "month_id": "may2026",
      "month_name": "May 2026",
      "title": "International Affairs Current Affairs - May 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "Which city hosted the 77th/79th World Health Assembly (WHA) in May 2026 under the World Health Organization?",
          "options": [
            "Geneva, Switzerland",
            "Vienna, Austria",
            "New York, USA",
            "Paris, France"
          ],
          "correct": 0,
          "explanation": "The World Health Assembly, the supreme decision-making body of the WHO, meets annually at the Palais des Nations in Geneva."
        },
        {
          "id": 2,
          "question": "Who is the Director-General of the World Health Organization (WHO)?",
          "options": [
            "Dr. Tedros Adhanom Ghebreyesus (Ethiopia)",
            "Dr. Margaret Chan",
            "Dr. Soumya Swaminathan",
            "Dr. Jeremy Farrar"
          ],
          "correct": 0,
          "explanation": "Dr. Tedros Adhanom Ghebreyesus was first elected Director-General in 2017 and was re-elected for a second 5-year term in 2022."
        },
        {
          "id": 3,
          "question": "Where was the WHO Global Centre for Traditional Medicine (GCTM) established in 2022 under an agreement between India and WHO?",
          "options": [
            "Jamnagar, Gujarat",
            "Rishikesh, Uttarakhand",
            "Pune, Maharashtra",
            "New Delhi"
          ],
          "correct": 0,
          "explanation": "The WHO GCTM is the world's first and only global outpost center for traditional medicine, established in Jamnagar, Gujarat."
        },
        {
          "id": 4,
          "question": "Which city hosted the 57th/59th Annual Meeting of the Board of Governors of the Asian Development Bank (ADB) in May 2026?",
          "options": [
            "Tbilisi, Georgia",
            "Incheon, South Korea",
            "Manila, Philippines",
            "Tokyo, Japan"
          ],
          "correct": 0,
          "explanation": "The ADB Annual Meeting was held in Tbilisi, Georgia, under the theme 'Bridge to the Future', focusing on climate finance and regional connectivity."
        },
        {
          "id": 5,
          "question": "Where are the headquarters of the Asian Development Bank (ADB) located?",
          "options": [
            "Mandaluyong, Metro Manila, Philippines",
            "Tokyo, Japan",
            "Beijing, China",
            "Singapore"
          ],
          "correct": 0,
          "explanation": "The Asian Development Bank, established in 1966, is headquartered in Metro Manila, Philippines."
        },
        {
          "id": 6,
          "question": "Who is the President of the Asian Development Bank (ADB)?",
          "options": [
            "Masatsugu Asakawa",
            "Takehiko Nakao",
            "Haruhiko Kuroda",
            "Jin Liqun"
          ],
          "correct": 0,
          "explanation": "Masatsugu Asakawa has served as the President of the Asian Development Bank since January 2020."
        },
        {
          "id": 7,
          "question": "Which country holds the largest voting share in the Asian Development Bank (ADB) along with the United States?",
          "options": [
            "Japan (15.57%) and United States (15.57%)",
            "China",
            "India",
            "Australia"
          ],
          "correct": 0,
          "explanation": "Japan and the US are the two largest shareholders in ADB with 15.57% voting share each, followed by China (6.43%) and India (6.32%)."
        },
        {
          "id": 8,
          "question": "Where are the headquarters of the Asian Infrastructure Investment Bank (AIIB) located?",
          "options": [
            "Beijing, China",
            "Shanghai, China",
            "Manila, Philippines",
            "Singapore"
          ],
          "correct": 0,
          "explanation": "The AIIB is a multilateral development bank initiated by China, headquartered in Beijing and operational since January 2016."
        },
        {
          "id": 9,
          "question": "Who is the President of the Asian Infrastructure Investment Bank (AIIB)?",
          "options": [
            "Jin Liqun",
            "Masatsugu Asakawa",
            "Dilma Rousseff",
            "KV Kamath"
          ],
          "correct": 0,
          "explanation": "Jin Liqun of China has served as the President of the AIIB since its inception."
        },
        {
          "id": 10,
          "question": "Which country is the second largest shareholder and the largest borrower of funds from the Asian Infrastructure Investment Bank (AIIB)?",
          "options": [
            "India (approx. 7.6% voting share)",
            "Russia",
            "Germany",
            "South Korea"
          ],
          "correct": 0,
          "explanation": "India is the second-largest shareholder in AIIB (behind China) and has been the largest recipient of project financing for infrastructure development."
        },
        {
          "id": 11,
          "question": "Who is the current President of the New Development Bank (NDB / BRICS Bank)?",
          "options": [
            "Dilma Rousseff (former President of Brazil)",
            "K.V. Kamath",
            "Marcos Troyjo",
            "Sergey Storchak"
          ],
          "correct": 0,
          "explanation": "Former Brazilian President Dilma Rousseff was elected President of the New Development Bank, headquartered in Shanghai."
        },
        {
          "id": 12,
          "question": "Who served as the inaugural first President of the New Development Bank (NDB) from 2015 to 2020?",
          "options": [
            "K.V. Kamath (India)",
            "Arun Jaitley",
            "Urjit Patel",
            "Raghuram Rajan"
          ],
          "correct": 0,
          "explanation": "Renowned Indian banker K.V. Kamath served as the founding President of the NDB during its first five formative years."
        },
        {
          "id": 13,
          "question": "Which country joined as a new member of the New Development Bank (NDB) in 2023-2024?",
          "options": [
            "Algeria and Egypt",
            "Saudi Arabia",
            "Argentina",
            "Indonesia"
          ],
          "correct": 0,
          "explanation": "The NDB has expanded beyond founding BRICS members, admitting Bangladesh, UAE, Egypt, and Algeria as formal members."
        },
        {
          "id": 14,
          "question": "Where are the headquarters of the International Labour Organization (ILO) located?",
          "options": [
            "Geneva, Switzerland",
            "Paris, France",
            "Brussels, Belgium",
            "The Hague, Netherlands"
          ],
          "correct": 0,
          "explanation": "The ILO, founded in 1919 under the Treaty of Versailles and the first specialized agency of the UN in 1946, is headquartered in Geneva."
        },
        {
          "id": 15,
          "question": "Who is the Director-General of the International Labour Organization (ILO)?",
          "options": [
            "Gilbert F. Houngbo (former Prime Minister of Togo)",
            "Guy Ryder",
            "Juan Somavia",
            "Tedros Adhanom"
          ],
          "correct": 0,
          "explanation": "Gilbert F. Houngbo of Togo took office in October 2022 as the 11th Director-General of the ILO, becoming the first African to head the organization."
        },
        {
          "id": 16,
          "question": "Where are the headquarters of the United Nations Educational, Scientific and Cultural Organization (UNESCO) located?",
          "options": [
            "Paris, France (Place de Fontenoy)",
            "Geneva, Switzerland",
            "London, UK",
            "Rome, Italy"
          ],
          "correct": 0,
          "explanation": "UNESCO, founded in 1945, has its iconic headquarters at Place de Fontenoy in Paris, France."
        },
        {
          "id": 17,
          "question": "Who is the Director-General of UNESCO?",
          "options": [
            "Audrey Azoulay (France)",
            "Irina Bokova",
            "Koichiro Matsuura",
            "Federico Mayor"
          ],
          "correct": 0,
          "explanation": "Audrey Azoulay was elected Director-General of UNESCO in 2017 and was re-elected for a second four-year term in 2021."
        },
        {
          "id": 18,
          "question": "How many World Heritage Sites from India are inscribed on the UNESCO World Heritage List as of mid-2026?",
          "options": [
            "43 sites (following the inclusion of Moidams of Assam)",
            "40 sites",
            "42 sites",
            "45 sites"
          ],
          "correct": 0,
          "explanation": "India has 43 World Heritage Sites (35 Cultural, 7 Natural, and 1 Mixed - Khangchendzonga), with the 'Moidams – the Mound-Burial System of the Ahom Dynasty' added in 2024."
        },
        {
          "id": 19,
          "question": "Which site from India was inscribed as India's 43rd UNESCO World Heritage Site at the 46th World Heritage Committee session in New Delhi?",
          "options": [
            "Moidams – the Mound-Burial System of the Ahom Dynasty, Charaideo, Assam",
            "Sacred Ensembles of the Hoysalas",
            "Santiniketan",
            "Dholavira"
          ],
          "correct": 0,
          "explanation": "The Royal Burial Mounds of the Ahom kings at Charaideo in Assam became the 43rd Indian property and the first cultural site from the Northeast on the UNESCO List."
        },
        {
          "id": 20,
          "question": "Which city hosted the 46th session of the UNESCO World Heritage Committee in July 2024, the first time India hosted the prestigious event?",
          "options": [
            "New Delhi (Bharat Mandapam)",
            "Mumbai",
            "Jaipur",
            "Kolkata"
          ],
          "correct": 0,
          "explanation": "India hosted the 46th Session of the World Heritage Committee for the first time at Bharat Mandapam in New Delhi."
        },
        {
          "id": 21,
          "question": "Which Indian sites were inscribed as the 41st and 42nd World Heritage Sites in September 2023?",
          "options": [
            "Santiniketan (West Bengal) and Sacred Ensembles of the Hoysalas (Karnataka)",
            "Dholavira and Ramappa Temple",
            "Jaipur City and Ahmedabad",
            "Nalanda and Rani ki Vav"
          ],
          "correct": 0,
          "explanation": "Santiniketan founded by Rabindranath Tagore was inscribed as the 41st site, and the 12th-century Hoysala temples (Belur, Halebid, Somnathapura) as the 42nd site."
        },
        {
          "id": 22,
          "question": "Which is India's only 'Mixed' (cultural and natural) UNESCO World Heritage Site?",
          "options": [
            "Khangchendzonga National Park (Sikkim)",
            "Manas Wildlife Sanctuary",
            "Kaziranga National Park",
            "Sundarbans National Park"
          ],
          "correct": 0,
          "explanation": "Khangchendzonga National Park in Sikkim was inscribed in 2016 as India's sole Mixed World Heritage site."
        },
        {
          "id": 23,
          "question": "Which was the first site from India to be inscribed on the UNESCO World Heritage List in 1983?",
          "options": [
            "Ajanta Caves, Ellora Caves, Agra Fort, and Taj Mahal",
            "Qutub Minar",
            "Sun Temple Konark",
            "Fatehpur Sikri"
          ],
          "correct": 0,
          "explanation": "The initial batch of four Indian sites inscribed in 1983 were Ajanta Caves, Ellora Caves, Agra Fort, and the Taj Mahal."
        },
        {
          "id": 24,
          "question": "Where are the headquarters of the Food and Agriculture Organization (FAO) located?",
          "options": [
            "Rome, Italy",
            "Geneva, Switzerland",
            "Paris, France",
            "Vienna, Austria"
          ],
          "correct": 0,
          "explanation": "The FAO, a specialized agency of the UN leading international efforts to defeat hunger, was founded in 1945 in Quebec and relocated to Rome in 1951."
        },
        {
          "id": 25,
          "question": "Where are the headquarters of the World Food Programme (WFP), which won the Nobel Peace Prize in 2020?",
          "options": [
            "Rome, Italy",
            "Geneva, Switzerland",
            "Nairobi, Kenya",
            "New York, USA"
          ],
          "correct": 0,
          "explanation": "The United Nations World Food Programme (WFP), the world's largest humanitarian agency addressing hunger and food security, is headquartered in Rome, Italy."
        }
      ]
    },
    "international_jun2026": {
      "id": "international_jun2026",
      "category_id": "international",
      "category_name": "International Affairs & Summits",
      "month_id": "jun2026",
      "month_name": "June 2026",
      "title": "International Affairs Current Affairs - June 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "Which country hosted the 50th/52nd G7 Summit held at the luxury resort of Borgo Egnazia in Apulia in June 2026?",
          "options": [
            "Italy",
            "Germany",
            "Japan",
            "Canada"
          ],
          "correct": 0,
          "explanation": "Italy held the 2024 G7 Presidency, and Prime Minister Giorgia Meloni hosted the G7 leaders at Borgo Egnazia in Fasano, Apulia."
        },
        {
          "id": 2,
          "question": "Prime Minister Narendra Modi participated in the G7 Outreach Session in Italy, delivering keynote remarks on which two key focus areas?",
          "options": [
            "Artificial Intelligence & Energy, Africa and the Mediterranean",
            "Trade tariffs and defense spending",
            "Crypto regulation",
            "Arctic sea navigation"
          ],
          "correct": 0,
          "explanation": "PM Modi highlighted India's human-centric approach to AI ('AI for All') and energy transition during the G7 Outreach sessions."
        },
        {
          "id": 3,
          "question": "How many countries constitute the Group of Seven (G7)?",
          "options": [
            "7 countries (USA, UK, France, Germany, Italy, Japan, Canada) plus the European Union",
            "8 countries",
            "6 countries",
            "10 countries"
          ],
          "correct": 0,
          "explanation": "The G7 comprises the world's seven leading advanced industrial democracies: United States, United Kingdom, France, Germany, Italy, Japan, and Canada, with the EU as a non-enumerated member."
        },
        {
          "id": 4,
          "question": "Which country hosted the BRICS Foreign Ministers Meeting in June 2026?",
          "options": [
            "Nizhny Novgorod, Russia",
            "Kazan, Russia",
            "Johannesburg, South Africa",
            "Brasilia, Brazil"
          ],
          "correct": 0,
          "explanation": "Russia held the 2024 BRICS Chairmanship under the motto 'Strengthening Multilateralism for Equitable Global Development and Security' and hosted the ministerial in Nizhny Novgorod."
        },
        {
          "id": 5,
          "question": "Which five new countries officially joined the BRICS grouping as full members on January 1, 2024?",
          "options": [
            "Egypt, Ethiopia, Iran, Saudi Arabia, and the United Arab Emirates (UAE)",
            "Argentina, Nigeria, Indonesia, Turkey, Mexico",
            "Algeria, Kenya, Vietnam, Thailand, Qatar",
            "Pakistan, Bangladesh, Sri Lanka, Nepal, Myanmar"
          ],
          "correct": 0,
          "explanation": "Following the 15th Summit in Johannesburg, Egypt, Ethiopia, Iran, Saudi Arabia, and the UAE joined BRICS (Argentina declined under President Milei)."
        },
        {
          "id": 6,
          "question": "Which country hosted the 'Summit on Peace in Ukraine' at the Bürgenstock resort in June 2026?",
          "options": [
            "Switzerland",
            "Austria",
            "Sweden",
            "Finland"
          ],
          "correct": 0,
          "explanation": "Switzerland hosted the high-level peace summit on Ukraine at the Bürgenstock resort near Lucerne, attended by delegations from over 90 countries."
        },
        {
          "id": 7,
          "question": "Who represented the Government of India at the Swiss Summit on Peace in Ukraine?",
          "options": [
            "Pavan Kapoor (Secretary - West, Ministry of External Affairs)",
            "Dr. S. Jaishankar",
            "Ajit Doval",
            "Sanjay Verma"
          ],
          "correct": 0,
          "explanation": "India deputed senior diplomat Pavan Kapoor, reiterating that lasting peace requires direct dialogue and diplomacy acceptable to both conflicting parties."
        },
        {
          "id": 8,
          "question": "Who is the Minister of External Affairs (MEA) of India?",
          "options": [
            "Dr. S. Jaishankar",
            "Rajnath Singh",
            "Nitin Gadkari",
            "Piyush Goyal"
          ],
          "correct": 0,
          "explanation": "Dr. Subrahmanyam Jaishankar, former Foreign Secretary and career diplomat, continues as the Union Minister of External Affairs for a second term."
        },
        {
          "id": 9,
          "question": "Who was appointed as the new Foreign Secretary of India in mid-2026, succeeding Vinay Mohan Kwatra?",
          "options": [
            "Vikram Misri",
            "Vinay Mohan Kwatra",
            "Harsh Vardhan Shringla",
            "Taranjit Singh Sandhu"
          ],
          "correct": 0,
          "explanation": "Veteran diplomat Vikram Misri (former Ambassador to China and Deputy NSA) took charge as the Foreign Secretary of India in July 2024."
        },
        {
          "id": 10,
          "question": "Where was Vinay Mohan Kwatra appointed after superannuating as India's Foreign Secretary?",
          "options": [
            "Ambassador of India to the United States",
            "High Commissioner to UK",
            "Permanent Representative to UN",
            "Ambassador to France"
          ],
          "correct": 0,
          "explanation": "Former Foreign Secretary Vinay Mohan Kwatra was appointed as the Ambassador of India to the United States of America."
        },
        {
          "id": 11,
          "question": "Who was appointed as India's Permanent Representative to the United Nations in New York in 2024, succeeding Ruchira Kamboj?",
          "options": [
            "Parvathaneni Harish",
            "Ruchira Kamboj",
            "TS Tirumurti",
            "Syed Akbaruddin"
          ],
          "correct": 0,
          "explanation": "Senior diplomat Parvathaneni Harish (former Ambassador to Germany) was appointed as India's Permanent Representative to the UN in New York."
        },
        {
          "id": 12,
          "question": "Where are the headquarters of the International Court of Arbitration of the International Chamber of Commerce (ICC) located?",
          "options": [
            "Paris, France",
            "London, UK",
            "The Hague, Netherlands",
            "Geneva, Switzerland"
          ],
          "correct": 0,
          "explanation": "The ICC International Court of Arbitration, the world's leading commercial dispute resolution institution, is headquartered in Paris."
        },
        {
          "id": 13,
          "question": "Where are the headquarters of the Permanent Court of Arbitration (PCA) situated?",
          "options": [
            "Peace Palace, The Hague, Netherlands",
            "Geneva, Switzerland",
            "London, UK",
            "Brussels, Belgium"
          ],
          "correct": 0,
          "explanation": "The PCA, established in 1899 by the First Hague Peace Conference, is the oldest global dispute resolution institution, based at the Peace Palace in The Hague."
        },
        {
          "id": 14,
          "question": "What is the primary role of the Financial Action Task Force (FATF)?",
          "options": [
            "Global money laundering and terrorist financing watchdog",
            "International currency exchange regulator",
            "Bank bailout fund",
            "Trade tariff enforcer"
          ],
          "correct": 0,
          "explanation": "The FATF is an intergovernmental policymaking body that sets international standards to prevent money laundering, terrorist financing, and proliferation financing."
        },
        {
          "id": 15,
          "question": "Where are the headquarters of the Financial Action Task Force (FATF) located?",
          "options": [
            "Paris, France (at the OECD headquarters)",
            "Geneva, Switzerland",
            "London, UK",
            "Vienna, Austria"
          ],
          "correct": 0,
          "explanation": "The FATF Secretariat is housed at the headquarters of the Organisation for Economic Co-operation and Development (OECD) in Paris."
        },
        {
          "id": 16,
          "question": "In its mutual evaluation report released in mid-2024/2026, which rating category did the FATF award to India for its anti-money laundering framework?",
          "options": [
            "'Regular Follow-up' category (the highest tier of technical compliance, alongside UK, France, and Italy)",
            "Grey List",
            "Enhanced Follow-up",
            "Black List"
          ],
          "correct": 0,
          "explanation": "The FATF Plenary placed India in the coveted 'Regular Follow-up' category, commending India's measures in tackling illicit financial flows and terrorist financing."
        },
        {
          "id": 17,
          "question": "What does the 'Grey List' of the FATF formally signify for a listed jurisdiction?",
          "options": [
            "Jurisdictions under Increased Monitoring working with the FATF to address strategic deficiencies",
            "High-Risk Jurisdictions subject to Call for Action",
            "Banned nations",
            "Nations without banking systems"
          ],
          "correct": 0,
          "explanation": "Countries on the FATF 'Grey List' (officially 'Jurisdictions under Increased Monitoring') commit to resolving deficiencies within agreed timeframes."
        },
        {
          "id": 18,
          "question": "What does the 'Black List' of the FATF signify, and which countries are currently on it?",
          "options": [
            "High-Risk Jurisdictions subject to a Call for Action (currently North Korea, Iran, and Myanmar)",
            "Tax haven islands only",
            "Nations in default of World Bank loans",
            "Non-UN members"
          ],
          "correct": 0,
          "explanation": "The FATF Black List comprises jurisdictions with significant strategic deficiencies; currently, Democratic People's Republic of Korea (DPRK), Iran, and Myanmar are blacklisted."
        },
        {
          "id": 19,
          "question": "Where are the headquarters of the Organisation for Economic Co-operation and Development (OECD) located?",
          "options": [
            "Paris, France (Chateau de la Muette)",
            "London, UK",
            "Geneva, Switzerland",
            "Brussels, Belgium"
          ],
          "correct": 0,
          "explanation": "The OECD, an intergovernmental organization of 38 high-income market economies, is based at Chateau de la Muette in Paris."
        },
        {
          "id": 20,
          "question": "Who is the Secretary-General of the OECD?",
          "options": [
            "Mathias Cormann (Australia)",
            "Angel Gurria",
            "Pascal Lamy",
            "Donald Johnston"
          ],
          "correct": 0,
          "explanation": "Mathias Cormann, former Australian Finance Minister, assumed office as the Secretary-General of the OECD in June 2021."
        },
        {
          "id": 21,
          "question": "Which multilateral export control regime controls the transfer of conventional arms and dual-use goods and technologies, with India as its 42nd member?",
          "options": [
            "The Wassenaar Arrangement",
            "Missile Technology Control Regime (MTCR)",
            "Australia Group",
            "Nuclear Suppliers Group (NSG)"
          ],
          "correct": 0,
          "explanation": "India was admitted as the 42nd participating state of the Wassenaar Arrangement in December 2017, having earlier joined MTCR (2016) and Australia Group (2018)."
        },
        {
          "id": 22,
          "question": "Which export control regime controls exports of chemical and biological agents and dual-use equipment, with India as its 43rd member?",
          "options": [
            "The Australia Group",
            "Wassenaar Arrangement",
            "MTCR",
            "NSG"
          ],
          "correct": 0,
          "explanation": "The Australia Group admitted India as its 43rd member in January 2018, reaffirming India's non-proliferation credentials."
        },
        {
          "id": 23,
          "question": "Which export control regime regulates the proliferation of missiles and unmanned aerial vehicles capable of carrying a 500 kg payload to at least 300 km?",
          "options": [
            "Missile Technology Control Regime (MTCR)",
            "Wassenaar Arrangement",
            "Australia Group",
            "Zangger Committee"
          ],
          "correct": 0,
          "explanation": "MTCR was established in 1987; India joined as its 35th member in June 2016, enabling extended-range BrahMos testing and drone exports."
        },
        {
          "id": 24,
          "question": "Which of the four major multilateral export control regimes has India NOT yet gained membership of, due to lack of consensus?",
          "options": [
            "Nuclear Suppliers Group (NSG)",
            "MTCR",
            "Wassenaar Arrangement",
            "Australia Group"
          ],
          "correct": 0,
          "explanation": "India is a member of MTCR, Wassenaar Arrangement, and Australia Group, but its membership bid for the 48-nation NSG remains blocked by China due to NPT non-signatory criteria."
        },
        {
          "id": 25,
          "question": "Where are the headquarters of the United Nations Environment Programme (UNEP) located?",
          "options": [
            "Nairobi, Kenya",
            "Geneva, Switzerland",
            "Vienna, Austria",
            "Bonn, Germany"
          ],
          "correct": 0,
          "explanation": "UNEP is the leading global environmental authority within the UN system, founded in 1972 and based in Gigiri, Nairobi, Kenya."
        }
      ]
    },
    "international_jul2026": {
      "id": "international_jul2026",
      "category_id": "international",
      "category_name": "International Affairs & Summits",
      "month_id": "jul2026",
      "month_name": "July 2026",
      "title": "International Affairs Current Affairs - July 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "Which city hosted the 24th Meeting of the Council of Heads of State of the Shanghai Cooperation Organisation (SCO) in July 2026?",
          "options": [
            "Astana, Kazakhstan",
            "Tashkent, Uzbekistan",
            "Samarkand, Uzbekistan",
            "Bishkek, Kyrgyzstan"
          ],
          "correct": 0,
          "explanation": "Kazakhstan President Kassym-Jomart Tokayev chaired the 24th SCO Summit in Astana, where leaders adopted the historic Astana Declaration."
        },
        {
          "id": 2,
          "question": "Who represented India at the 24th SCO Summit in Astana?",
          "options": [
            "Dr. S. Jaishankar (External Affairs Minister)",
            "Prime Minister Narendra Modi",
            "Ajit Doval",
            "Rajnath Singh"
          ],
          "correct": 0,
          "explanation": "External Affairs Minister Dr. S. Jaishankar led the Indian delegation to Astana, emphasizing counter-terrorism, sovereignty, and connectivity without unilateral hegemony."
        },
        {
          "id": 3,
          "question": "Which country officially assumed the rotating Presidency of the SCO for 2024-2025 at the conclusion of the Astana Summit?",
          "options": [
            "China",
            "Russia",
            "Uzbekistan",
            "Kyrgyzstan"
          ],
          "correct": 0,
          "explanation": "China took over the rotating SCO Presidency for 2024-2025 following Kazakhstan's successful tenure."
        },
        {
          "id": 4,
          "question": "Prime Minister Narendra Modi undertook a historic bilateral visit to Moscow in July 2026. What was the occasion?",
          "options": [
            "22nd India-Russia Annual Bilateral Summit",
            "SCO Summit",
            "BRICS Summit",
            "Victory Day Parade"
          ],
          "correct": 0,
          "explanation": "Prime Minister Modi and President Vladimir Putin co-chaired the 22nd India-Russia Annual Summit at the Kremlin in Moscow."
        },
        {
          "id": 5,
          "question": "Which highest civilian honour of the Russian Federation was officially conferred upon Prime Minister Narendra Modi during his visit to Moscow?",
          "options": [
            "Order of St. Andrew the Apostle the First-Called",
            "Order of Friendship",
            "Hero of the Russian Federation",
            "Order of Alexander Nevsky"
          ],
          "correct": 0,
          "explanation": "President Vladimir Putin formally presented PM Modi with the Order of St. Andrew the Apostle, Russia's highest state decoration, for distinguished services in bilateral strategic partnership."
        },
        {
          "id": 6,
          "question": "Following his visit to Russia, Prime Minister Modi visited which European country, marking the first visit by an Indian Prime Minister in 41 years since Indira Gandhi in 1983?",
          "options": [
            "Austria (Vienna)",
            "Switzerland",
            "Poland",
            "Hungary"
          ],
          "correct": 0,
          "explanation": "PM Modi visited Vienna, meeting Austrian President Alexander Van der Bellen and Chancellor Karl Nehammer to celebrate 75 years of diplomatic relations."
        },
        {
          "id": 7,
          "question": "Where are the headquarters of the Organization for Security and Co-operation in Europe (OSCE) located?",
          "options": [
            "Vienna, Austria",
            "Geneva, Switzerland",
            "Brussels, Belgium",
            "Warsaw, Poland"
          ],
          "correct": 0,
          "explanation": "The OSCE, the world's largest regional security-oriented intergovernmental organization with 57 participating states, is based in Vienna."
        },
        {
          "id": 8,
          "question": "Which city hosted the 75th Anniversary NATO Summit in July 2026?",
          "options": [
            "Washington D.C., United States",
            "Brussels, Belgium",
            "Vilnius, Lithuania",
            "Madrid, Spain"
          ],
          "correct": 0,
          "explanation": "NATO leaders gathered in Washington D.C. where the North Atlantic Treaty was originally signed on April 4, 1949, focusing on Ukraine support and Indo-Pacific partnerships (IP4)."
        },
        {
          "id": 9,
          "question": "Which four Asia-Pacific nations (collectively termed IP4) participated as partner countries in the NATO Washington Summit?",
          "options": [
            "Australia, Japan, New Zealand, and South Korea",
            "India, Japan, Australia, USA",
            "Singapore, Philippines, Japan, South Korea",
            "Vietnam, Indonesia, Thailand, Malaysia"
          ],
          "correct": 0,
          "explanation": "The Indo-Pacific Four (IP4) partners participating in NATO deliberations on global supply chain and maritime security were Australia, Japan, New Zealand, and South Korea."
        },
        {
          "id": 10,
          "question": "Where was the 57th ASEAN Foreign Ministers' Meeting (AMM) and Post-Ministerial Conferences held in July 2026?",
          "options": [
            "Vientiane, Laos",
            "Jakarta, Indonesia",
            "Phnom Penh, Cambodia",
            "Bandar Seri Begawan, Brunei"
          ],
          "correct": 0,
          "explanation": "The 57th AMM took place in Vientiane under the chairmanship of Laos, with Dr. S. Jaishankar participating in the ASEAN-India and East Asia Summit foreign ministers meetings."
        },
        {
          "id": 11,
          "question": "Which country took over the rotating presidency of the Council of the European Union for the second half of 2024 from Belgium?",
          "options": [
            "Hungary",
            "Poland",
            "Denmark",
            "Spain"
          ],
          "correct": 0,
          "explanation": "Hungary held the 6-month rotating Council presidency from July 1 to December 31, 2024, followed by Poland in the first half of 2025."
        },
        {
          "id": 12,
          "question": "Who is the President of the European Commission, re-elected for a second 5-year term in July 2026?",
          "options": [
            "Ursula von der Leyen (Germany)",
            "Roberta Metsola",
            "Charles Michel",
            "Josep Borrell"
          ],
          "correct": 0,
          "explanation": "The European Parliament confirmed Ursula von der Leyen as President of the European Commission for a second consecutive term until 2029."
        },
        {
          "id": 13,
          "question": "Who is the President of the European Parliament, re-elected in July 2026?",
          "options": [
            "Roberta Metsola (Malta)",
            "Ursula von der Leyen",
            "Antonio Costa",
            "Kaja Kallas"
          ],
          "correct": 0,
          "explanation": "Maltese politician Roberta Metsola was re-elected as President of the European Parliament with an overwhelming majority."
        },
        {
          "id": 14,
          "question": "Who was chosen by EU leaders to succeed Charles Michel as the President of the European Council?",
          "options": [
            "Antonio Costa (former Prime Minister of Portugal)",
            "Alexander De Croo",
            "Mark Rutte",
            "Enrico Letta"
          ],
          "correct": 0,
          "explanation": "Former Portuguese Prime Minister Antonio Costa was selected by European leaders as the new President of the European Council."
        },
        {
          "id": 15,
          "question": "Who was designated as the EU High Representative for Foreign Affairs and Security Policy, succeeding Josep Borrell?",
          "options": [
            "Kaja Kallas (former Prime Minister of Estonia)",
            "Ursula von der Leyen",
            "Sanna Marin",
            "Mette Frederiksen"
          ],
          "correct": 0,
          "explanation": "Former Estonian Prime Minister Kaja Kallas was appointed as the European Union's foreign policy chief."
        },
        {
          "id": 16,
          "question": "Where are the headquarters of the European Investment Bank (EIB) located?",
          "options": [
            "Luxembourg City, Luxembourg",
            "Brussels, Belgium",
            "Frankfurt, Germany",
            "Strasbourg, France"
          ],
          "correct": 0,
          "explanation": "The EIB, the lending arm of the European Union and the world's largest multilateral financial institution, is based in Kirchberg, Luxembourg."
        },
        {
          "id": 17,
          "question": "Where are the headquarters of the European Central Bank (ECB) situated?",
          "options": [
            "Frankfurt am Main, Germany",
            "Brussels, Belgium",
            "Paris, France",
            "Amsterdam, Netherlands"
          ],
          "correct": 0,
          "explanation": "The European Central Bank, responsible for administering monetary policy of the Eurozone, has its seat in Frankfurt, Germany."
        },
        {
          "id": 18,
          "question": "Who is the President of the European Central Bank (ECB)?",
          "options": [
            "Christine Lagarde (France)",
            "Mario Draghi",
            "Jean-Claude Trichet",
            "Wim Duisenberg"
          ],
          "correct": 0,
          "explanation": "Christine Lagarde, former Managing Director of the IMF, serves as the President of the ECB."
        },
        {
          "id": 19,
          "question": "Where are the headquarters of the Bank for International Settlements (BIS), often referred to as the 'central bank for central banks'?",
          "options": [
            "Basel, Switzerland",
            "Zurich, Switzerland",
            "Geneva, Switzerland",
            "Bern, Switzerland"
          ],
          "correct": 0,
          "explanation": "The BIS was established in 1930 and is headquartered in Basel, Switzerland, fostering international monetary and financial cooperation."
        },
        {
          "id": 20,
          "question": "Who serves as the General Manager of the Bank for International Settlements (BIS)?",
          "options": [
            "Agustin Carstens (former Governor of Bank of Mexico)",
            "Mark Carney",
            "Raghuram Rajan",
            "Mervyn King"
          ],
          "correct": 0,
          "explanation": "Agustin Carstens has served as the General Manager of the Bank for International Settlements since December 2017."
        },
        {
          "id": 21,
          "question": "Where are the headquarters of the International Organization for Migration (IOM) located?",
          "options": [
            "Geneva, Switzerland",
            "New York, USA",
            "Vienna, Austria",
            "Rome, Italy"
          ],
          "correct": 0,
          "explanation": "The IOM, established in 1951 and part of the UN system since 2016, is headquartered in Le Grand-Saconnex, Geneva."
        },
        {
          "id": 22,
          "question": "Who is the Director General of the International Organization for Migration (IOM)?",
          "options": [
            "Amy E. Pope (USA)",
            "Antonio Vitorino",
            "William Lacy Swing",
            "Brunson McKinley"
          ],
          "correct": 0,
          "explanation": "Amy Pope assumed office as the first woman Director General of the International Organization for Migration in October 2023."
        },
        {
          "id": 23,
          "question": "Where are the headquarters of the United Nations High Commissioner for Refugees (UNHCR) located?",
          "options": [
            "Geneva, Switzerland",
            "Nairobi, Kenya",
            "The Hague, Netherlands",
            "Bonn, Germany"
          ],
          "correct": 0,
          "explanation": "UNHCR, the UN refugee agency twice awarded the Nobel Peace Prize, is based in Geneva, Switzerland."
        },
        {
          "id": 24,
          "question": "Who is the United Nations High Commissioner for Refugees (UNHCR)?",
          "options": [
            "Filippo Grandi (Italy)",
            "Antonio Guterres",
            "Ruud Lubbers",
            "Sadako Ogata"
          ],
          "correct": 0,
          "explanation": "Filippo Grandi has served as the UN High Commissioner for Refugees since 2016."
        },
        {
          "id": 25,
          "question": "Where are the headquarters of the United Nations Development Programme (UNDP) situated?",
          "options": [
            "New York City, United States",
            "Geneva, Switzerland",
            "Paris, France",
            "Rome, Italy"
          ],
          "correct": 0,
          "explanation": "UNDP, which works in nearly 170 countries to eradicate poverty and reduce inequalities, has its headquarters at One United Nations Plaza in New York."
        }
      ]
    },
    "international_aug2026": {
      "id": "international_aug2026",
      "category_id": "international",
      "category_name": "International Affairs & Summits",
      "month_id": "aug2026",
      "month_name": "August 2026",
      "title": "International Affairs Current Affairs - August 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "India virtually hosted the 3rd 'Voice of Global South Summit' in August 2026. What was the overarching theme of the summit?",
          "options": [
            "An Empowered Global South for a Sustainable Future",
            "Unity of Voice, Unity of Purpose",
            "Energy for All",
            "Shared Prosperity and Resilience"
          ],
          "correct": 0,
          "explanation": "Prime Minister Narendra Modi chaired the 3rd Voice of Global South Summit, bringing together leaders from over 120 developing nations to amplify developing world priorities."
        },
        {
          "id": 2,
          "question": "What initiative was proposed by India at the 3rd Voice of Global South Summit to build medical and healthcare resilience?",
          "options": [
            "Aarogya Maitri Disaster Management Cube / Health Network",
            "Global South Vaccine Pool",
            "Pharma Hub Fund",
            "Telemedicine South"
          ],
          "correct": 0,
          "explanation": "Under Project BHISHM (Bharat Health Initiative for Sahyog Hita and Maitri), India showcased portable Aarogya Maitri cubes capable of treating 200 casualties in disaster zones."
        },
        {
          "id": 3,
          "question": "Which country did Prime Minister Narendra Modi visit in August 2026, marking the first visit by an Indian Prime Minister to that nation in 45 years?",
          "options": [
            "Poland (Warsaw)",
            "Austria",
            "Ukraine",
            "Czech Republic"
          ],
          "correct": 0,
          "explanation": "Prime Minister Modi visited Warsaw, Poland, holding bilateral talks with Prime Minister Donald Tusk, elevating bilateral ties to a Strategic Partnership."
        },
        {
          "id": 4,
          "question": "Following Poland, Prime Minister Narendra Modi travelled to which war-torn nation aboard the special train 'Rail Force One' in August 2026?",
          "options": [
            "Ukraine (Kyiv)",
            "Moldova",
            "Georgia",
            "Armenia"
          ],
          "correct": 0,
          "explanation": "PM Modi undertook a historic visit to Kyiv, Ukraine, meeting President Volodymyr Zelenskyy at the Mariinskyi Palace—the first visit by an Indian Prime Minister since Ukraine's independence in 1991."
        },
        {
          "id": 5,
          "question": "During his visit to Kyiv, which memorial did Prime Minister Narendra Modi visit alongside President Zelenskyy to pay solemn homage to fallen children?",
          "options": [
            "Martyrologist Exhibition at the National Museum of the History of Ukraine in the Second World War",
            "Babi Yar Memorial",
            "Maidan Square",
            "St. Sophia Cathedral"
          ],
          "correct": 0,
          "explanation": "Prime Minister Modi placed a stuffed toy at the memorial for children killed in the conflict, reiterating that innocent human loss is unacceptable to humanity."
        },
        {
          "id": 6,
          "question": "What four bilateral agreements/MoUs were signed between India and Ukraine during the historic August 2026 visit?",
          "options": [
            "Agreements on Agriculture and Food Industry, Medical Products Regulation, High Impact Community Development Projects (HICDP), and Cultural Cooperation",
            "Defence treaty",
            "Free trade pact",
            "Dual citizenship agreement"
          ],
          "correct": 0,
          "explanation": "India and Ukraine signed four MoUs spanning agriculture, pharmaceutical regulation, community infrastructure grants, and cultural exchanges."
        },
        {
          "id": 7,
          "question": "Where was the 18th East Asia Summit (EAS) senior officials meeting held in August 2026?",
          "options": [
            "Vientiane, Laos",
            "Jakarta, Indonesia",
            "Bangkok, Thailand",
            "Kuala Lumpur, Malaysia"
          ],
          "correct": 0,
          "explanation": "Laos hosted the EAS preparatory sessions, focusing on maritime cooperation, Indo-Pacific guidelines, and regional food security."
        },
        {
          "id": 8,
          "question": "How many member countries comprise the East Asia Summit (EAS)?",
          "options": [
            "18 countries (10 ASEAN nations + Australia, China, India, Japan, New Zealand, South Korea, Russia, USA)",
            "16 countries",
            "20 countries",
            "14 countries"
          ],
          "correct": 0,
          "explanation": "The East Asia Summit is an 18-nation regional leaders' forum comprising the 10 ASEAN members and eight dialogue partners including India and the US."
        },
        {
          "id": 9,
          "question": "Which city hosted the India-Japan 2+2 Ministerial Dialogue in August 2026?",
          "options": [
            "New Delhi, India",
            "Tokyo, Japan",
            "Osaka, Japan",
            "Bengaluru, India"
          ],
          "correct": 0,
          "explanation": "Defence Minister Rajnath Singh and EAM Dr. S. Jaishankar hosted Japanese Foreign Minister Yoko Kamikawa and Defense Minister Minoru Kihara in New Delhi."
        },
        {
          "id": 10,
          "question": "What does a '2+2 Ministerial Dialogue' denote in Indian diplomatic parlance?",
          "options": [
            "A formal summit format where Foreign and Defence Ministers of both partner nations meet jointly",
            "Prime Minister and President summit",
            "Two trade ministers and two finance ministers",
            "Biannual trade rounds"
          ],
          "correct": 0,
          "explanation": "India conducts 2+2 dialogues with five key strategic partners: United States, Japan, Australia, Russia, and the United Kingdom."
        },
        {
          "id": 11,
          "question": "Who is the Prime Minister of Japan who announced in August 2024 that he would step down?",
          "options": [
            "Fumio Kishida (succeeded by Shigeru Ishiba)",
            "Yoshihide Suga",
            "Shinzo Abe",
            "Taro Aso"
          ],
          "correct": 0,
          "explanation": "Fumio Kishida decided not to contest the LDP leadership election, paving the way for former Defense Minister Shigeru Ishiba to become Japan's Prime Minister."
        },
        {
          "id": 12,
          "question": "Who was appointed as the interim Chief Adviser of the Interim Government of Bangladesh in August 2024 following the resignation of Sheikh Hasina?",
          "options": [
            "Nobel Peace Laureate Dr. Muhammad Yunus",
            "Muhammad Abdul Hamid",
            "Khaleda Zia",
            "Tarique Rahman"
          ],
          "correct": 0,
          "explanation": "Nobel Laureate Dr. Muhammad Yunus was sworn in as the head of Bangladesh's interim government following widespread student protests."
        },
        {
          "id": 13,
          "question": "In which year was Dr. Muhammad Yunus and Grameen Bank awarded the Nobel Peace Prize for microcredit and poverty alleviation?",
          "options": [
            "2006",
            "2014",
            "2000",
            "1998"
          ],
          "correct": 0,
          "explanation": "Dr. Muhammad Yunus and the Grameen Bank were jointly awarded the 2006 Nobel Peace Prize for pioneering microfinance for the rural poor."
        },
        {
          "id": 14,
          "question": "Which country hosted the Pacific Islands Forum (PIF) Leaders Meeting in August 2026?",
          "options": [
            "Nuku'alofa, Tonga",
            "Suva, Fiji",
            "Port Moresby, Papua New Guinea",
            "Apia, Samoa"
          ],
          "correct": 0,
          "explanation": "The 53rd Pacific Islands Forum Leaders Conclave was held in Nuku'alofa, Tonga, addressing rising sea levels and climate adaptation."
        },
        {
          "id": 15,
          "question": "Where was the Forum for India-Pacific Islands Cooperation (FIPIC) III Summit hosted by India in May 2023?",
          "options": [
            "Port Moresby, Papua New Guinea",
            "Suva, Fiji",
            "Jaipur, India",
            "Canberra, Australia"
          ],
          "correct": 0,
          "explanation": "PM Modi co-chaired the FIPIC III Summit in Port Moresby, releasing developmental grants and healthcare assistance for 14 Pacific Island nations."
        },
        {
          "id": 16,
          "question": "What is the highest civilian honour of Papua New Guinea conferred on Prime Minister Narendra Modi during the FIPIC summit?",
          "options": [
            "Grand Companion of the Order of Logohu (GCL)",
            "Companion of the Order of Fiji",
            "Order of the Star of Melanesia",
            "Pacific Cross"
          ],
          "correct": 0,
          "explanation": "Governor-General Sir Bob Dadae invested PM Modi with the Grand Companion of the Order of Logohu for championing the cause of Pacific Island nations."
        },
        {
          "id": 17,
          "question": "What is the highest honour of Fiji conferred upon Prime Minister Narendra Modi?",
          "options": [
            "Companion of the Order of Fiji (CF)",
            "Order of the Lion",
            "Medal of Suva",
            "Honor of the South Seas"
          ],
          "correct": 0,
          "explanation": "Prime Minister Sitiveni Rabuka of Fiji presented PM Modi with Fiji's highest civilian decoration, the Companion of the Order of Fiji."
        },
        {
          "id": 18,
          "question": "Which African nation conferred its highest national honour, 'The Grand Commander of the Order of the Niger' (GCON), on Prime Minister Modi in 2024?",
          "options": [
            "Nigeria",
            "Ghana",
            "South Africa",
            "Kenya"
          ],
          "correct": 0,
          "explanation": "Nigeria conferred its second-highest national honour, the GCON, on Prime Minister Modi, making him only the second foreign leader after Queen Elizabeth II to receive it."
        },
        {
          "id": 19,
          "question": "Which Caribbean nation conferred its highest civilian honour, 'The Order of Excellence', on Prime Minister Modi in 2024?",
          "options": [
            "Guyana",
            "Trinidad and Tobago",
            "Jamaica",
            "Barbados"
          ],
          "correct": 0,
          "explanation": "President Irfaan Ali of Guyana conferred the Order of Excellence on PM Modi during the 2nd India-CARICOM Summit in Georgetown."
        },
        {
          "id": 20,
          "question": "Where are the headquarters of the Caribbean Community (CARICOM) located?",
          "options": [
            "Georgetown, Guyana",
            "Kingston, Jamaica",
            "Port of Spain, Trinidad and Tobago",
            "Bridgetown, Barbados"
          ],
          "correct": 0,
          "explanation": "The CARICOM Secretariat is located in Georgetown, Guyana. CARICOM was established by the Treaty of Chaguaramas in 1973."
        },
        {
          "id": 21,
          "question": "Where are the headquarters of the International Committee of the Red Cross (ICRC) located?",
          "options": [
            "Geneva, Switzerland",
            "Vienna, Austria",
            "London, UK",
            "Paris, France"
          ],
          "correct": 0,
          "explanation": "The ICRC, a three-time recipient of the Nobel Peace Prize (1917, 1944, 1963), was founded in 1863 by Henry Dunant and is based in Geneva."
        },
        {
          "id": 22,
          "question": "On which date is World Humanitarian Day observed globally each year to honour humanitarian aid workers?",
          "options": [
            "August 19",
            "August 12",
            "August 29",
            "August 21"
          ],
          "correct": 0,
          "explanation": "World Humanitarian Day is marked on August 19, commemorating the 2003 bombing of the Canal Hotel in Baghdad which killed 22 UN workers including Sergio Vieira de Mello."
        },
        {
          "id": 23,
          "question": "On which date is International Youth Day observed by the United Nations annually?",
          "options": [
            "August 12",
            "August 15",
            "August 8",
            "August 20"
          ],
          "correct": 0,
          "explanation": "International Youth Day is celebrated globally on August 12 to recognize youth potential and promote youth-led social impact."
        },
        {
          "id": 24,
          "question": "On which date is National Youth Day celebrated in India to commemorate the birth anniversary of Swami Vivekananda?",
          "options": [
            "January 12",
            "January 23",
            "August 12",
            "October 31"
          ],
          "correct": 0,
          "explanation": "National Youth Day (Yuva Diwas) is celebrated on January 12 each year across India in honor of Swami Vivekananda (born January 12, 1863)."
        },
        {
          "id": 25,
          "question": "Which day is designated by the United Nations as the 'International Day against Nuclear Tests'?",
          "options": [
            "August 29",
            "August 6 (Hiroshima Day)",
            "August 9 (Nagasaki Day)",
            "August 15"
          ],
          "correct": 0,
          "explanation": "The UN General Assembly declared August 29 as the International Day against Nuclear Tests to raise awareness about the catastrophic effects of nuclear weapon test explosions."
        }
      ]
    },
    "awards_appointments_feb2026": {
      "id": "awards_appointments_feb2026",
      "category_id": "awards_appointments",
      "category_name": "Awards, Honours & Appointments",
      "month_id": "feb2026",
      "month_name": "February 2026",
      "title": "Awards & Appointments Current Affairs - February 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "The Government of India conferred the highest civilian award 'Bharat Ratna' on how many eminent personalities in 2024?",
          "options": [
            "5 personalities (Karpoori Thakur, L.K. Advani, P.V. Narasimha Rao, Chaudhary Charan Singh, and M.S. Swaminathan)",
            "3 personalities",
            "4 personalities",
            "2 personalities"
          ],
          "correct": 0,
          "explanation": "The Government announced Bharat Ratna for 5 legendary figures: former Bihar CM Karpoori Thakur, former Deputy PM L.K. Advani, former PMs P.V. Narasimha Rao and Chaudhary Charan Singh, and agricultural scientist Dr. M.S. Swaminathan."
        },
        {
          "id": 2,
          "question": "Who is revered as the 'Father of the Green Revolution in India' who was posthumously conferred the Bharat Ratna?",
          "options": [
            "Dr. M.S. Swaminathan",
            "Dr. Norman Borlaug",
            "Dr. Verghese Kurien",
            "Dr. Homi Bhabha"
          ],
          "correct": 0,
          "explanation": "Dr. Mankombu Sambasivan Swaminathan led the development and introduction of high-yielding semi-dwarf wheat and rice varieties in India in the 1960s."
        },
        {
          "id": 3,
          "question": "Who is known as the 'Father of the White Revolution' (Operation Flood) in India?",
          "options": [
            "Dr. Verghese Kurien",
            "Dr. M.S. Swaminathan",
            "Sam Pitroda",
            "Dr. Amrita Patel"
          ],
          "correct": 0,
          "explanation": "Dr. Verghese Kurien ('Milkman of India') engineered Operation Flood, transforming India from a milk-deficient nation into the world's largest milk producer."
        },
        {
          "id": 4,
          "question": "Former Chief Minister of Bihar known affectionately as 'Jananayak' who was conferred the Bharat Ratna posthumously is:",
          "options": [
            "Karpoori Thakur",
            "Jayaprakash Narayan",
            "Sri Krishna Sinha",
            "Daroga Prasad Rai"
          ],
          "correct": 0,
          "explanation": "Karpoori Thakur was a socialist leader who championed social justice, reservation for backward classes, and land reforms in Bihar."
        },
        {
          "id": 5,
          "question": "Which former Prime Minister of India who served as the 9th Prime Minister from 1991 to 1996 and initiated economic liberalization was conferred the Bharat Ratna?",
          "options": [
            "Pamulaparthi Venkata Narasimha Rao",
            "Atal Bihari Vajpayee",
            "I.K. Gujral",
            "H.D. Deve Gowda"
          ],
          "correct": 0,
          "explanation": "P.V. Narasimha Rao steered India through severe balance-of-payments crisis and ushered in historic LPG (Liberalisation, Privatisation, Globalisation) economic reforms."
        },
        {
          "id": 6,
          "question": "Which former Prime Minister of India celebrated as a champion of farmers and the agrarian community was conferred the Bharat Ratna?",
          "options": [
            "Chaudhary Charan Singh",
            "Lal Bahadur Shastri",
            "Morarji Desai",
            "Chandra Shekhar"
          ],
          "correct": 0,
          "explanation": "Chaudhary Charan Singh was the 5th Prime Minister of India whose birth anniversary on December 23 is observed nationally as 'Kisan Diwas' (National Farmers' Day)."
        },
        {
          "id": 7,
          "question": "On which date is National Farmers' Day (Kisan Diwas) celebrated annually in India?",
          "options": [
            "December 23",
            "December 25",
            "October 2",
            "November 26"
          ],
          "correct": 0,
          "explanation": "National Farmers' Day is marked on December 23 to honor Chaudhary Charan Singh's pioneering contributions to peasant welfare and agricultural reform."
        },
        {
          "id": 8,
          "question": "How many Padma Awards were conferred by the President of India on Republic Day (including Padma Vibhushan, Padma Bhushan, and Padma Shri)?",
          "options": [
            "132 Padma Awards (5 Padma Vibhushan, 17 Padma Bhushan, and 110 Padma Shri)",
            "106 awards",
            "128 awards",
            "141 awards"
          ],
          "correct": 0,
          "explanation": "President Droupadi Murmu approved the conferment of 132 Padma Awards, including 5 Padma Vibhushan, 17 Padma Bhushan, and 110 Padma Shri across diverse fields."
        },
        {
          "id": 9,
          "question": "Who among the following was NOT awarded the Padma Vibhushan (India's second-highest civilian award) in 2024?",
          "options": [
            "Mithun Chakraborty (awarded Padma Bhushan)",
            "Ms. Vyjayanthimala Bali (Art)",
            "Shri Konidela Chiranjeevi (Art)",
            "Shri M. Venkaiah Naidu (Public Affairs)"
          ],
          "correct": 0,
          "explanation": "The 5 Padma Vibhushan recipients were: Ms. Vyjayanthimala Bali, Shri K. Chiranjeevi, Shri M. Venkaiah Naidu, Dr. Bindeshwar Pathak (posthumous), and Ms. Padma Subrahmanyam. Mithun Chakraborty received the Padma Bhushan."
        },
        {
          "id": 10,
          "question": "Founder of Sulabh International who was posthumously conferred the Padma Vibhushan in 2024 for social work and sanitation is:",
          "options": [
            "Dr. Bindeshwar Pathak",
            "Sundarlal Bahuguna",
            "Baba Amte",
            "Anna Hazare"
          ],
          "correct": 0,
          "explanation": "Dr. Bindeshwar Pathak revolutionized low-cost two-pit pour-flush eco-sanitation and liberation of manual scavengers across India."
        },
        {
          "id": 11,
          "question": "Renowned classical Bharatanatyam dancer and scholar who was conferred the Padma Vibhushan is:",
          "options": [
            "Dr. Padma Subrahmanyam",
            "Yamini Krishnamurthy",
            "Sonal Mansingh",
            "Mallika Sarabhai"
          ],
          "correct": 0,
          "explanation": "Dr. Padma Subrahmanyam is celebrated for her research on Natyashastra Karana sculptures and reviving Bharata Nrithyam."
        },
        {
          "id": 12,
          "question": "Veteran cinema actress Ms. Vyjayanthimala Bali was conferred the Padma Vibhushan in which field?",
          "options": [
            "Art (Cinema and Classical Bharatanatyam)",
            "Literature",
            "Public Affairs",
            "Social Work"
          ],
          "correct": 0,
          "explanation": "Vyjayanthimala Bali is an iconic figure of Indian cinema and classical dance who brought South Indian classical dance to national Hindi cinema."
        },
        {
          "id": 13,
          "question": "Which fusion band featuring Ustad Zakir Hussain and Shankar Mahadevan won the 'Best Global Music Album' at the 66th Annual Grammy Awards in February 2026?",
          "options": [
            "Shakti (for the album 'This Moment')",
            "Indian Ocean",
            "Euphoria",
            "Junoon"
          ],
          "correct": 0,
          "explanation": "Pioneering Indo-jazz fusion band Shakti (founded by John McLaughlin and Zakir Hussain) won the Grammy Award for 'This Moment', their first new studio album in 46 years."
        },
        {
          "id": 14,
          "question": "How many Grammy Awards did tabla maestro Ustad Zakir Hussain win in a single night at the 66th Grammy Awards?",
          "options": [
            "3 Grammy Awards",
            "2 Grammys",
            "1 Grammy",
            "4 Grammys"
          ],
          "correct": 0,
          "explanation": "Ustad Zakir Hussain won three Grammys in one evening: Best Global Music Album (Shakti), Best Global Music Performance ('Pashto'), and Best Contemporary Instrumental Album ('As We Speak')."
        },
        {
          "id": 15,
          "question": "Which film won the top award for Best Film at the 77th British Academy Film Awards (BAFTA) in February 2026?",
          "options": [
            "Oppenheimer",
            "Poor Things",
            "The Zone of Interest",
            "Anatomy of a Fall"
          ],
          "correct": 0,
          "explanation": "Christopher Nolan's biographical epic 'Oppenheimer' swept the 77th BAFTA Awards, winning 7 trophies including Best Film, Best Director, and Best Actor."
        },
        {
          "id": 16,
          "question": "Who won the BAFTA Award for Best Actor in a Leading Role in February 2026 for portraying J. Robert Oppenheimer?",
          "options": [
            "Cillian Murphy",
            "Bradley Cooper",
            "Paul Giamatti",
            "Colman Domingo"
          ],
          "correct": 0,
          "explanation": "Irish actor Cillian Murphy won the BAFTA Best Actor award for his compelling portrayal of the theoretical physicist J. Robert Oppenheimer."
        },
        {
          "id": 17,
          "question": "Who won the BAFTA Award for Best Actress in a Leading Role for 'Poor Things'?",
          "options": [
            "Emma Stone",
            "Margot Robbie",
            "Carey Mulligan",
            "Sandra Huller"
          ],
          "correct": 0,
          "explanation": "Emma Stone won the BAFTA for Best Actress for her audacious performance as Bella Baxter in Yorgos Lanthimos's 'Poor Things'."
        },
        {
          "id": 18,
          "question": "Who was appointed as the Chief Election Commissioner (CEC) of India?",
          "options": [
            "Rajiv Kumar",
            "Gyanesh Kumar",
            "Sukhbir Singh Sandhu",
            "Arun Goel"
          ],
          "correct": 0,
          "explanation": "Rajiv Kumar continued as the 25th Chief Election Commissioner of India, supervising the general elections."
        },
        {
          "id": 19,
          "question": "Who were appointed as the two new Election Commissioners in the Election Commission of India in March 2024?",
          "options": [
            "Gyanesh Kumar and Dr. Sukhbir Singh Sandhu",
            "Arun Goel and Anup Chandra Pandey",
            "Rajiv Mehrishi and Ajay Bhushan Pandey",
            "Sanjay Malhotra and Vivek Joshi"
          ],
          "correct": 0,
          "explanation": "A high-level selection committee chaired by Prime Minister Modi appointed retired IAS officers Gyanesh Kumar (Kerala cadre) and Sukhbir Singh Sandhu (Uttarakhand cadre) as Election Commissioners."
        },
        {
          "id": 20,
          "question": "Under which statutory Act were Election Commissioners Gyanesh Kumar and Sukhbir Singh Sandhu appointed?",
          "options": [
            "Chief Election Commissioner and other Election Commissioners (Appointment, Conditions of Service and Term of Office) Act, 2023",
            "Representation of the People Act, 1950",
            "Election Commission Act, 1991",
            "Civil Services Act"
          ],
          "correct": 0,
          "explanation": "The appointments were made under the new 2023 legislation, which establishes a selection committee comprising the Prime Minister, a Union Cabinet Minister, and the Leader of the Opposition/single largest party in Lok Sabha."
        },
        {
          "id": 21,
          "question": "Who is the Comptroller and Auditor General (CAG) of India who assumed office in late 2024, succeeding Girish Chandra Murmu?",
          "options": [
            "K. Sanjay Murthy",
            "Girish Chandra Murmu",
            "Rajiv Mehrishi",
            "Shashi Kant Sharma"
          ],
          "correct": 0,
          "explanation": "Former Higher Education Secretary K. Sanjay Murthy was appointed as the Comptroller and Auditor General of India under Article 148."
        },
        {
          "id": 22,
          "question": "Who was appointed as the Director General of the National Investigation Agency (NIA) in March 2024?",
          "options": [
            "Sadanand Vasant Date",
            "Dinkar Gupta",
            "Tapan Deka",
            "Praveen Sood"
          ],
          "correct": 0,
          "explanation": "Senior IPS officer Sadanand Vasant Date (1990 batch Maharashtra cadre), a 26/11 Mumbai terror attacks gallantry awardee, took charge as Director General of the NIA."
        },
        {
          "id": 23,
          "question": "Who was appointed as the Director General of the National Disaster Response Force (NDRF)?",
          "options": [
            "Piyush Anand",
            "Atul Karwal",
            "Satya Narayan Pradhan",
            "SN Shrivastava"
          ],
          "correct": 0,
          "explanation": "Piyush Anand (1991 batch IPS officer of Uttar Pradesh cadre) was appointed as the Director General of the specialized disaster response force NDRF."
        },
        {
          "id": 24,
          "question": "Who was appointed as the Director General of the Bureau of Civil Aviation Security (BCAS)?",
          "options": [
            "Zulfiquar Hasan",
            "Nasir Kamal",
            "Rakesh Asthana",
            "Kumar Rajesh Chandra"
          ],
          "correct": 0,
          "explanation": "Zulfiquar Hasan serves as the Director General of the Bureau of Civil Aviation Security under the Ministry of Civil Aviation."
        },
        {
          "id": 25,
          "question": "Where are the headquarters of the National Investigation Agency (NIA) located?",
          "options": [
            "New Delhi",
            "Mumbai",
            "Hyderabad",
            "Kolkata"
          ],
          "correct": 0,
          "explanation": "The NIA, constituted under the National Investigation Agency Act 2008 following the 26/11 terror attacks as the central counter-terrorism law enforcement agency, is headquartered in New Delhi."
        }
      ]
    },
    "awards_appointments_mar2026": {
      "id": "awards_appointments_mar2026",
      "category_id": "awards_appointments",
      "category_name": "Awards, Honours & Appointments",
      "month_id": "mar2026",
      "month_name": "March 2026",
      "title": "Awards & Appointments Current Affairs - March 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "Which film won the Best Picture award at the 96th/98th Academy Awards (Oscars) held at the Dolby Theatre in Hollywood in March 2026?",
          "options": [
            "Oppenheimer",
            "Poor Things",
            "Barbie",
            "Killers of the Flower Moon"
          ],
          "correct": 0,
          "explanation": "Christopher Nolan's 'Oppenheimer' won 7 Academy Awards, including Best Picture, Best Director, Best Actor, and Best Supporting Actor."
        },
        {
          "id": 2,
          "question": "Who won the Academy Award (Oscar) for Best Director for 'Oppenheimer'?",
          "options": [
            "Christopher Nolan",
            "Martin Scorsese",
            "Yorgos Lanthimos",
            "Jonathan Glazer"
          ],
          "correct": 0,
          "explanation": "British-American filmmaker Christopher Nolan won his first career Oscar for Best Director for directing 'Oppenheimer'."
        },
        {
          "id": 3,
          "question": "Who won the Academy Award for Best Actor in a Leading Role at the Oscars?",
          "options": [
            "Cillian Murphy",
            "Paul Giamatti",
            "Bradley Cooper",
            "Jeffrey Wright"
          ],
          "correct": 0,
          "explanation": "Cillian Murphy became the first Irish-born actor to win the Academy Award for Best Actor for his performance as J. Robert Oppenheimer."
        },
        {
          "id": 4,
          "question": "Who won the Academy Award for Best Actress in a Leading Role at the Oscars for 'Poor Things'?",
          "options": [
            "Emma Stone",
            "Lily Gladstone",
            "Sandra Huller",
            "Annette Bening"
          ],
          "correct": 0,
          "explanation": "Emma Stone won her second career Best Actress Oscar for her extraordinary portrayal of Bella Baxter in 'Poor Things'."
        },
        {
          "id": 5,
          "question": "Who won the Academy Award for Best Supporting Actor at the Oscars for playing Lewis Strauss in 'Oppenheimer'?",
          "options": [
            "Robert Downey Jr.",
            "Ryan Gosling",
            "Robert De Niro",
            "Mark Ruffalo"
          ],
          "correct": 0,
          "explanation": "Robert Downey Jr. won his first Academy Award for Best Supporting Actor for his role as Atomic Energy Commission chairman Lewis Strauss."
        },
        {
          "id": 6,
          "question": "Who won the Academy Award for Best Supporting Actress at the Oscars for 'The Holdovers'?",
          "options": [
            "Da'Vine Joy Randolph",
            "Emily Blunt",
            "America Ferrera",
            "Jodie Foster"
          ],
          "correct": 0,
          "explanation": "Da'Vine Joy Randolph won the Best Supporting Actress Oscar for her moving performance as grieving mother Mary Lamb in 'The Holdovers'."
        },
        {
          "id": 7,
          "question": "Which international film won the Academy Award for Best International Feature Film and Best Sound at the Oscars?",
          "options": [
            "The Zone of Interest (United Kingdom)",
            "Society of the Snow (Spain)",
            "Perfect Days (Japan)",
            "Io Capitano (Italy)"
          ],
          "correct": 0,
          "explanation": "Jonathan Glazer's Holocaust drama 'The Zone of Interest' became the first British submission to win the Oscar for Best International Feature Film."
        },
        {
          "id": 8,
          "question": "Which documentary won the Academy Award for Best Documentary Feature Film at the Oscars?",
          "options": [
            "20 Days in Mariupol",
            "Bobi Wine: The People's President",
            "To Kill a Tiger",
            "Four Daughters"
          ],
          "correct": 0,
          "explanation": "Mstyslav Chernov's '20 Days in Mariupol' won the first-ever Academy Award in Ukrainian cinema history for Best Documentary Feature."
        },
        {
          "id": 9,
          "question": "Who was awarded the prestigious 'Abel Prize 2026' in Mathematics by the Norwegian Academy of Science and Letters in March?",
          "options": [
            "Michel Talagrand (France)",
            "Luis Caffarelli",
            "Dennis Sullivan",
            "Avi Wigderson"
          ],
          "correct": 0,
          "explanation": "French mathematician Michel Talagrand was awarded the Abel Prize 'for groundbreaking contributions to probability theory and functional analysis, with outstanding applications in mathematical physics'."
        },
        {
          "id": 10,
          "question": "The Abel Prize is named after which famous 19th-century Norwegian mathematician?",
          "options": [
            "Niels Henrik Abel",
            "Sophus Lie",
            "Carl Friedrich Gauss",
            "Leonhard Euler"
          ],
          "correct": 0,
          "explanation": "The Abel Prize was established by the Government of Norway in 2001 in memory of Niels Henrik Abel (1802–1829), celebrated as mathematics' equivalent to the Nobel Prize."
        },
        {
          "id": 11,
          "question": "Who was awarded the 'Pritzker Architecture Prize 2026' (architecture's highest international honour) in March?",
          "options": [
            "Riken Yamamoto (Japan)",
            "David Chipperfield",
            "Francis Kéré",
            "Anne Lacaton"
          ],
          "correct": 0,
          "explanation": "Japanese architect Riken Yamamoto was named the 2024 Pritzker Prize Laureate for his social architecture bridging public and private realms."
        },
        {
          "id": 12,
          "question": "Who was the first Indian architect to be awarded the prestigious Pritzker Architecture Prize in 2018?",
          "options": [
            "Balkrishna Doshi",
            "Charles Correa",
            "Raj Rewal",
            "Hafeez Contractor"
          ],
          "correct": 0,
          "explanation": "Dr. Balkrishna Vithaldas Doshi became the first Indian architect to receive the Pritzker Prize, recognized for low-cost social housing like the Aranya Community in Indore."
        },
        {
          "id": 13,
          "question": "Which mathematician and computer scientist was awarded the 2023/2026 A.M. Turing Award ('Nobel Prize of Computing') in April?",
          "options": [
            "Avi Wigderson (Institute for Advanced Study, Princeton)",
            "Robert Metcalfe",
            "Jack Dongarra",
            "Alfred Aho"
          ],
          "correct": 0,
          "explanation": "Avi Wigderson was awarded the ACM A.M. Turing Award for foundational contributions to the theory of computation, becoming the first person to win both the Abel Prize and the Turing Award."
        },
        {
          "id": 14,
          "question": "Who was appointed as the Director General of the Central Industrial Security Force (CISF), becoming the first woman IPS officer to head CISF?",
          "options": [
            "Nina Singh",
            "Rashmi Shukla",
            "Archana Ramasundaram",
            "S. Sundari Nanda"
          ],
          "correct": 0,
          "explanation": "Nina Singh (1989 batch IPS officer of Rajasthan cadre) scripted history by becoming the first woman Director General of the CISF."
        },
        {
          "id": 15,
          "question": "Where are the headquarters of the Central Industrial Security Force (CISF) located?",
          "options": [
            "New Delhi",
            "Mumbai",
            "Kolkata",
            "Chennai"
          ],
          "correct": 0,
          "explanation": "CISF, raised under the CISF Act 1968 to guard critical infrastructure including airports, seaports, nuclear facilities, and metro rail networks, is headquartered in New Delhi."
        },
        {
          "id": 16,
          "question": "Who was appointed as the Director General of the Sashastra Seema Bal (SSB)?",
          "options": [
            "Amrit Mohan Prasad / Daljit Singh Chawdhary",
            "Rashmi Shukla",
            "SL Thaosen",
            "Kumar Rajesh Chandra"
          ],
          "correct": 0,
          "explanation": "Senior IPS officer Daljit Singh Chawdhary was appointed as the Director General of the Sashastra Seema Bal (SSB), guarding the Nepal and Bhutan borders."
        },
        {
          "id": 17,
          "question": "Which international border is secured by the Sashastra Seema Bal (SSB)?",
          "options": [
            "Indo-Nepal and Indo-Bhutan borders",
            "Indo-Pak and Indo-Bangla borders",
            "Indo-China border",
            "Indo-Myanmar border"
          ],
          "correct": 0,
          "explanation": "The SSB is the designated border guarding force for the 1,751 km Indo-Nepal border and the 699 km Indo-Bhutan border under the Ministry of Home Affairs."
        },
        {
          "id": 18,
          "question": "Which paramilitary force guards the Line of Actual Control (LAC) along the border with China?",
          "options": [
            "Indo-Tibetan Border Police (ITBP)",
            "Border Security Force (BSF)",
            "Assam Rifles",
            "CRPF"
          ],
          "correct": 0,
          "explanation": "ITBP is raised specifically to patrol high-altitude mountainous border posts ranging from Karakoram Pass in Ladakh to Jachep La in Arunachal Pradesh."
        },
        {
          "id": 19,
          "question": "Who is the Director General of the Indo-Tibetan Border Police (ITBP)?",
          "options": [
            "Rahul Rasgotra",
            "Anish Dayal Singh",
            "Sanjay Arora",
            "Praveen Vashista"
          ],
          "correct": 0,
          "explanation": "Senior IPS officer Rahul Rasgotra serves as the Director General of the Indo-Tibetan Border Police."
        },
        {
          "id": 20,
          "question": "Who was appointed as the Director General of the Border Security Force (BSF)?",
          "options": [
            "Daljit Singh Chawdhary (additional charge) / Praveen Kumar",
            "Nitin Agrawal",
            "Pankaj Kumar Singh",
            "Rakesh Asthana"
          ],
          "correct": 0,
          "explanation": "BSF is the 'First Line of Defence' guarding India's international borders with Pakistan and Bangladesh under the Ministry of Home Affairs."
        },
        {
          "id": 21,
          "question": "Which is the oldest paramilitary force in India, often called the 'Sentinels of the Northeast'?",
          "options": [
            "Assam Rifles (raised in 1835 as Cachar Levy)",
            "ITBP",
            "BSF",
            "CRPF"
          ],
          "correct": 0,
          "explanation": "Assam Rifles was established in 1835 as the 'Cachar Levy' to protect British settlements and is tasked with guarding the 1,643 km Indo-Myanmar border and internal security."
        },
        {
          "id": 22,
          "question": "Where are the headquarters of the Assam Rifles located?",
          "options": [
            "Shillong, Meghalaya",
            "Guwahati, Assam",
            "Kohima, Nagaland",
            "Imphal, Manipur"
          ],
          "correct": 0,
          "explanation": "The Directorate General of Assam Rifles (DGAR) is situated at Laitkor in Shillong, Meghalaya."
        },
        {
          "id": 23,
          "question": "What unique dual-control structure governs the Assam Rifles?",
          "options": [
            "Administrative control under Ministry of Home Affairs, operational control under the Indian Army (Ministry of Defence)",
            "Wholly under Army",
            "Wholly under MHA",
            "Joint command with state police"
          ],
          "correct": 0,
          "explanation": "Assam Rifles operates under dual command: administrative and budgetary control by MHA, while military operational control is vested in the Indian Army."
        },
        {
          "id": 24,
          "question": "Who is the Director General of the Central Reserve Police Force (CRPF), India's largest central armed police force?",
          "options": [
            "Anish Dayal Singh",
            "SL Thaosen",
            "Kuldiep Singh",
            "AP Maheshwari"
          ],
          "correct": 0,
          "explanation": "Senior IPS officer Anish Dayal Singh serves as the Director General of the CRPF, tasked with internal security and anti-Naxal operations."
        },
        {
          "id": 25,
          "question": "Where are the headquarters of the Central Reserve Police Force (CRPF) situated?",
          "options": [
            "CGO Complex, Lodhi Road, New Delhi",
            "Nagpur",
            "Hyderabad",
            "Bhopal"
          ],
          "correct": 0,
          "explanation": "The Directorate General of the CRPF operates from the CGO Complex on Lodhi Road in New Delhi."
        }
      ]
    },
    "awards_appointments_apr2026": {
      "id": "awards_appointments_apr2026",
      "category_id": "awards_appointments",
      "category_name": "Awards, Honours & Appointments",
      "month_id": "apr2026",
      "month_name": "April 2026",
      "title": "Awards & Appointments Current Affairs - April 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "Renowned Malayalam poet and lyricist Prabha Varma was selected for the prestigious 'Saraswati Samman 2023/2026' for which poetic work?",
          "options": [
            "Roudra Sathwikam",
            "Shyama Madhavam",
            "Kanal Chilambu",
            "Aparigraham"
          ],
          "correct": 0,
          "explanation": "Prabha Varma's poetic work 'Roudra Sathwikam' in Malayalam explores the existential dilemmas between power and righteousness."
        },
        {
          "id": 2,
          "question": "Which foundation institutes the prestigious Saraswati Samman and Vyas Samman literary awards annually?",
          "options": [
            "K.K. Birla Foundation",
            "Sahitya Akademi",
            "Bharatiya Jnanpith",
            "Azim Premji Foundation"
          ],
          "correct": 0,
          "explanation": "The K.K. Birla Foundation, established in 1991 by industrialist Krishna Kumar Birla, confers the Saraswati Samman, Vyas Samman, and Bihari Puraskar."
        },
        {
          "id": 3,
          "question": "What is the cash prize awarded to the recipient of the Saraswati Samman?",
          "options": [
            "₹15 lakh, a citation, and a plaque",
            "₹10 lakh",
            "₹5 lakh",
            "₹25 lakh"
          ],
          "correct": 0,
          "explanation": "The Saraswati Samman carries a cash citation prize of ₹15 lakh and is awarded for outstanding prose or poetry in any of the 22 languages in the Eighth Schedule."
        },
        {
          "id": 4,
          "question": "Who was the first recipient of the Saraswati Samman in 1991?",
          "options": [
            "Dr. Harivansh Rai Bachchan (for his four-volume autobiography)",
            "Ramakant Rath",
            "Vijay Tendulkar",
            "Mahasweta Devi"
          ],
          "correct": 0,
          "explanation": "Legendary Hindi poet Dr. Harivansh Rai Bachchan was honored with the inaugural Saraswati Samman in 1991."
        },
        {
          "id": 5,
          "question": "Noted Hindi writer Pushpa Bharati was awarded the 33rd 'Vyas Samman' for which literary memoir?",
          "options": [
            "Yaadein, Yaadein aur Yaadein (2016)",
            "Kasturi Kundali Base",
            "Chitrakoot Ke Ghat Par",
            "Premchand Ke Phate Joote"
          ],
          "correct": 0,
          "explanation": "Pushpa Bharati was chosen for her captivating memoir 'Yaadein, Yaadein aur Yaadein', reflecting on literary encounters across decades."
        },
        {
          "id": 6,
          "question": "The Vyas Samman is awarded annually for outstanding literary work published during the last 10 years in which language exclusively?",
          "options": [
            "Hindi language exclusively",
            "Any Eighth Schedule language",
            "English and Hindi",
            "Sanskrit only"
          ],
          "correct": 0,
          "explanation": "Unlike the Saraswati Samman which covers all 22 scheduled languages, the Vyas Samman is restricted solely to works in the Hindi language."
        },
        {
          "id": 7,
          "question": "Who was the first recipient of the Vyas Samman in 1991?",
          "options": [
            "Dr. Ram Vilas Sharma (for 'Bharat Ke Pracheen Bhasha Parivar Aur Hindi')",
            "Shiv Prasad Singh",
            "Girija Kumar Mathur",
            "Dharamvir Bharati"
          ],
          "correct": 0,
          "explanation": "Eminent scholar and Marxist critic Dr. Ram Vilas Sharma won the inaugural Vyas Samman in 1991."
        },
        {
          "id": 8,
          "question": "Who was selected for the 58th Jnanpith Award (for year 2023/2024)?",
          "options": [
            "Sanskrit scholar Jagadguru Rambhadracharya and Urdu poet-lyricist Gulzar",
            "Damodar Mauzo and Nilmani Phookan",
            "Amitav Ghosh and Krishna Sobti",
            "Akkitham and Shankha Ghosh"
          ],
          "correct": 0,
          "explanation": "The Jnanpith Selection Board conferred the award jointly on renowned Urdu poet-filmmaker Gulzar (Sampooran Singh Kalra) and Sanskrit scholar Jagadguru Rambhadracharya."
        },
        {
          "id": 9,
          "question": "In which year was the Jnanpith Award, India's highest literary honour, instituted by Bharatiya Jnanpith?",
          "options": [
            "1961 (first awarded in 1965 to G. Sankara Kurup)",
            "1954",
            "1970",
            "1950"
          ],
          "correct": 0,
          "explanation": "The Jnanpith Award was established in 1961 by the Sahu Shanti Prasad Jain family, with Malayalam poet G. Sankara Kurup winning the first award in 1965 for 'Odakkuzhal'."
        },
        {
          "id": 10,
          "question": "Who was the first woman writer to receive the Jnanpith Award in 1976?",
          "options": [
            "Ashapoorna Devi (Bengali for 'Prothom Protishruti')",
            "Amrita Pritam",
            "Mahadevi Varma",
            "Mahasweta Devi"
          ],
          "correct": 0,
          "explanation": "Eminent Bengali novelist Ashapoorna Devi became the first woman laureate in 1976 for her magnum opus 'Prothom Protishruti'."
        },
        {
          "id": 11,
          "question": "Who was the first English language author to be awarded the Jnanpith Award in 2018?",
          "options": [
            "Amitav Ghosh",
            "Arundhati Roy",
            "Salman Rushdie",
            "Vikram Seth"
          ],
          "correct": 0,
          "explanation": "Renowned novelist Amitav Ghosh was conferred the 54th Jnanpith Award in 2018, becoming the first author writing in English to win the honor."
        },
        {
          "id": 12,
          "question": "What does the Jnanpith Award confer on its laureates?",
          "options": [
            "₹11 lakh cash prize, a citation, and a bronze replica of Goddess Saraswati (Vagdhevi)",
            "₹25 lakh",
            "₹15 lakh",
            "₹5 lakh"
          ],
          "correct": 0,
          "explanation": "The Jnanpith Award includes a cash prize of ₹11 lakh, a citation, and a bronze replica of Vagdhevi (Saraswati), modeled after the sculpture at the Bhojshala temple in Dhar."
        },
        {
          "id": 13,
          "question": "Who was appointed as the Vice Chief of the Naval Staff (VCNS) in April 2026?",
          "options": [
            "Vice Admiral Krishna Swaminathan",
            "Vice Admiral Dinesh K. Tripathi",
            "Vice Admiral Sanjay J. Singh",
            "Vice Admiral Suraj Berry"
          ],
          "correct": 0,
          "explanation": "Vice Admiral Krishna Swaminathan assumed charge as the Vice Chief of the Naval Staff at Naval Headquarters, New Delhi."
        },
        {
          "id": 14,
          "question": "Who was appointed as the Flag Officer Commanding-in-Chief (FOC-in-C), Western Naval Command in Mumbai?",
          "options": [
            "Vice Admiral Sanjay Jasjit Singh",
            "Vice Admiral Suraj Berry",
            "Vice Admiral Rajesh Pendharkar",
            "Vice Admiral V. Srinivas"
          ],
          "correct": 0,
          "explanation": "Vice Admiral Sanjay Jasjit Singh took over as the Commander-in-Chief of the Western Naval Command in Mumbai."
        },
        {
          "id": 15,
          "question": "Who was appointed as the Flag Officer Commanding-in-Chief, Eastern Naval Command in Visakhapatnam?",
          "options": [
            "Vice Admiral Rajesh Pendharkar",
            "Vice Admiral Suraj Berry",
            "Vice Admiral Sanjay Singh",
            "Vice Admiral Sameer Saxena"
          ],
          "correct": 0,
          "explanation": "Vice Admiral Rajesh Pendharkar serves as the FOC-in-C Eastern Naval Command, overseeing naval operations in the Bay of Bengal."
        },
        {
          "id": 16,
          "question": "Where are the headquarters of the Southern Naval Command located?",
          "options": [
            "Kochi, Kerala (INS Venduruthy)",
            "Goa",
            "Chennai, Tamil Nadu",
            "Karwar, Karnataka"
          ],
          "correct": 0,
          "explanation": "Southern Naval Command is the training command of the Indian Navy, based at INS Venduruthy in Kochi, Kerala."
        },
        {
          "id": 17,
          "question": "Where is INS Kadamba, the massive naval base developed under 'Project Seabird', located?",
          "options": [
            "Karwar, Karnataka",
            "Kochi, Kerala",
            "Vizag, Andhra Pradesh",
            "Okha, Gujarat"
          ],
          "correct": 0,
          "explanation": "Project Seabird at Karwar is one of the largest naval infrastructure bases in the Eastern Hemisphere, providing berthing for aircraft carriers and submarines."
        },
        {
          "id": 18,
          "question": "Which Indian space scientist received the prestigious 'John L. Jack Swigert Jr. Award for Space Exploration' for Chandrayaan-3?",
          "options": [
            "ISRO Chandrayaan-3 Team (accepted by S. Somanath)",
            "K. Sivan",
            "P. Veeramuthuvel",
            "U.R. Rao"
          ],
          "correct": 0,
          "explanation": "The US-based Space Foundation presented the 2024 John L. 'Jack' Swigert, Jr. Award for Space Exploration to the ISRO Chandrayaan-3 mission team."
        },
        {
          "id": 19,
          "question": "Which industrialist was honoured with the prestigious 'Outstanding Business Leader of the Decade Award' in mid-2026?",
          "options": [
            "Kumar Mangalam Birla",
            "Gautam Adani",
            "Mukesh Ambani",
            "N. Chandrasekaran"
          ],
          "correct": 0,
          "explanation": "Aditya Birla Group Chairman Kumar Mangalam Birla was recognized by AIMA for his stewardship and expansion of global manufacturing footprints."
        },
        {
          "id": 20,
          "question": "Who was appointed as the Chairperson of the National Commission for Women (NCW)?",
          "options": [
            "Vijaya Rahatkar",
            "Rekha Sharma",
            "Mamta Sharma",
            "Lalitha Kumaramangalam"
          ],
          "correct": 0,
          "explanation": "The Central Government appointed Vijaya Rahatkar (former Maharashtra State Commission for Women chief) as the Chairperson of the NCW, succeeding Rekha Sharma."
        },
        {
          "id": 21,
          "question": "Under which statutory Act was the National Commission for Women (NCW) established in January 1992?",
          "options": [
            "National Commission for Women Act, 1990",
            "Protection of Women Act, 2005",
            "Civil Rights Act",
            "Equal Remuneration Act"
          ],
          "correct": 0,
          "explanation": "The NCW was established as a statutory body in January 1992 under the National Commission for Women Act, 1990, to safeguard women's constitutional and legal rights."
        },
        {
          "id": 22,
          "question": "Who was the first Chairperson of the National Commission for Women (NCW)?",
          "options": [
            "Ms. Jayanti Patnaik",
            "Dr. V. Mohini Giri",
            "Dr. Poornima Advani",
            "Ms. Girija Vyas"
          ],
          "correct": 0,
          "explanation": "Ms. Jayanti Patnaik served as the first Chairperson of the NCW from January 1992 to January 1995."
        },
        {
          "id": 23,
          "question": "Who is the Chairperson of the National Human Rights Commission (NHRC) of India?",
          "options": [
            "Justice Arun Kumar Mishra (former Judge of Supreme Court) / Vijaya Bharathi Sayani (acting)",
            "Justice HL Dattu",
            "Justice KG Balakrishnan",
            "Justice AS Anand"
          ],
          "correct": 0,
          "explanation": "Following Justice Arun Kumar Mishra's tenure, Vijaya Bharathi Sayani served as acting Chairperson, with the high-level panel selecting the next chairperson."
        },
        {
          "id": 24,
          "question": "Under which Act was the National Human Rights Commission (NHRC) established in India in October 1993?",
          "options": [
            "Protection of Human Rights Act (PHRA), 1993",
            "Human Rights Protection Code",
            "Fundamental Rights Act",
            "Civil Liberties Act"
          ],
          "correct": 0,
          "explanation": "The NHRC is a statutory body constituted on October 12, 1993, under the Protection of Human Rights Act, 1993 (amended in 2006 and 2019)."
        },
        {
          "id": 25,
          "question": "What is the term of office for the Chairperson and members of the NHRC as amended by the 2019 Amendment Act?",
          "options": [
            "3 years or up to 70 years of age, whichever is earlier (eligible for re-appointment)",
            "5 years or 70 years",
            "5 years or 65 years",
            "6 years or 65 years"
          ],
          "correct": 0,
          "explanation": "The Protection of Human Rights (Amendment) Act 2019 reduced the term from 5 years to 3 years or until age 70, making members eligible for re-appointment."
        }
      ]
    },
    "awards_appointments_may2026": {
      "id": "awards_appointments_may2026",
      "category_id": "awards_appointments",
      "category_name": "Awards, Honours & Appointments",
      "month_id": "may2026",
      "month_name": "May 2026",
      "title": "Awards & Appointments Current Affairs - May 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "Which novel won the prestigious 2024/2026 International Booker Prize, authored by German writer Jenny Erpenbeck?",
          "options": [
            "Kairos (translated by Michael Hofmann)",
            "Time Shelter",
            "Tomb of Sand",
            "The Gospel According to the New World"
          ],
          "correct": 0,
          "explanation": "Jenny Erpenbeck's 'Kairos', translated from German by Michael Hofmann, won the International Booker Prize, becoming the first German novel to win the prize."
        },
        {
          "id": 2,
          "question": "Who became the first Indian writer to win the International Booker Prize in 2022 for her Hindi novel 'Ret Samadhi' ('Tomb of Sand')?",
          "options": [
            "Geetanjali Shree (translated by Daisy Rockwell)",
            "Arundhati Roy",
            "Kiran Desai",
            "Jhumpa Lahiri"
          ],
          "correct": 0,
          "explanation": "Geetanjali Shree's 'Ret Samadhi', translated by Daisy Rockwell as 'Tomb of Sand', made history as the first book translated from Hindi or any South Asian language to win the International Booker Prize."
        },
        {
          "id": 3,
          "question": "Which Indian filmmaker won the prestigious Grand Prix (the second highest prize after Palme d'Or) at the 77th Cannes Film Festival in May 2026?",
          "options": [
            "Payal Kapadia (for 'All We Imagine as Light')",
            "Anurag Kashyap",
            "Mira Nair",
            "Chaitanya Tamhane"
          ],
          "correct": 0,
          "explanation": "Payal Kapadia scripted history as 'All We Imagine as Light' became the first Indian film in 30 years in the Cannes Competition, winning the prestigious Grand Prix."
        },
        {
          "id": 4,
          "question": "Who became the first Indian actor to win the Best Actress award in the Un Certain Regard section at the 77th Cannes Film Festival?",
          "options": [
            "Anasuya Sengupta (for 'The Shameless')",
            "Kani Kusruti",
            "Divya Prabha",
            "Tillotama Shome"
          ],
          "correct": 0,
          "explanation": "Kolkata-born actress Anasuya Sengupta won the Best Actress award in the Un Certain Regard section for her performance in Konstantin Bojanov's 'The Shameless'."
        },
        {
          "id": 5,
          "question": "Which film won the Palme d'Or (the top prize) at the 77th Cannes Film Festival in May 2026?",
          "options": [
            "Anora (directed by Sean Baker)",
            "All We Imagine as Light",
            "Emilia Perez",
            "The Seed of the Sacred Fig"
          ],
          "correct": 0,
          "explanation": "American director Sean Baker's romantic comedy-drama 'Anora' won the coveted Palme d'Or at Cannes."
        },
        {
          "id": 6,
          "question": "Who won the 2024 Pulitzer Prize for Fiction for his semi-autobiographical novel 'Night Watch'?",
          "options": [
            "Jayne Anne Phillips",
            "Barbara Kingsolver",
            "Hernan Diaz",
            "Colson Whitehead"
          ],
          "correct": 0,
          "explanation": "Jayne Anne Phillips was awarded the Pulitzer Prize in Fiction for 'Night Watch', a post-Civil War story set in a West Virginia asylum."
        },
        {
          "id": 7,
          "question": "Which news organizations jointly won the 2024 Pulitzer Prize for Public Service?",
          "options": [
            "ProPublica (for ground-breaking reporting on US Supreme Court ethics)",
            "The New York Times",
            "The Washington Post",
            "Reuters"
          ],
          "correct": 0,
          "explanation": "ProPublica received the coveted gold medal for Public Service for investigative reporting that revealed undisclosed gifts to Supreme Court justices."
        },
        {
          "id": 8,
          "question": "Who was appointed as the Chairperson of the Competition Commission of India (CCI)?",
          "options": [
            "Ravneet Kaur",
            "Ashok Kumar Gupta",
            "Dhanendra Kumar",
            "Devender Kumar Sikri"
          ],
          "correct": 0,
          "explanation": "Former Punjab cadre IAS officer Ravneet Kaur serves as the first woman regular Chairperson of the fair-trade watchdog CCI."
        },
        {
          "id": 9,
          "question": "Where are the headquarters of the Competition Commission of India (CCI) located?",
          "options": [
            "New Delhi",
            "Mumbai",
            "Bengaluru",
            "Hyderabad"
          ],
          "correct": 0,
          "explanation": "The Competition Commission of India, established under the Competition Act 2002, is headquartered at the World Trade Centre complex in New Delhi."
        },
        {
          "id": 10,
          "question": "Which appellate tribunal hears appeals against orders passed by the Competition Commission of India (CCI)?",
          "options": [
            "National Company Law Appellate Tribunal (NCLAT)",
            "Supreme Court directly",
            "High Court of Delhi",
            "Securities Appellate Tribunal (SAT)"
          ],
          "correct": 0,
          "explanation": "Following amendments to the Companies Act and Competition Act in 2017, the NCLAT was designated as the appellate tribunal replacing the erstwhile COMPAT."
        },
        {
          "id": 11,
          "question": "Who is the Chairperson of the National Company Law Appellate Tribunal (NCLAT)?",
          "options": [
            "Justice Ashok Bhushan",
            "Justice SJ Mukhopadhaya",
            "Justice Bansi Lal Bhat",
            "Justice Chellameswar"
          ],
          "correct": 0,
          "explanation": "Former Supreme Court judge Justice Ashok Bhushan serves as the Chairperson of the NCLAT."
        },
        {
          "id": 12,
          "question": "Who is the Chairperson of the Telecom Regulatory Authority of India (TRAI)?",
          "options": [
            "Anil Kumar Lahoti",
            "PD Vaghela",
            "RS Sharma",
            "Rahul Khullar"
          ],
          "correct": 0,
          "explanation": "Former Railway Board Chairman and CEO Anil Kumar Lahoti was appointed as the Chairperson of TRAI in early 2024."
        },
        {
          "id": 13,
          "question": "Where are the headquarters of the Telecom Regulatory Authority of India (TRAI) located?",
          "options": [
            "Mahanagar Doorsanchar Bhawan, Jawaharlal Nehru Marg, New Delhi",
            "Mumbai",
            "Bengaluru",
            "Hyderabad"
          ],
          "correct": 0,
          "explanation": "TRAI, established in 1997 by an Act of Parliament to regulate telecom and broadcasting services, is based in New Delhi."
        },
        {
          "id": 14,
          "question": "Which appellate tribunal adjudicates disputes and hears appeals against decisions of TRAI?",
          "options": [
            "Telecom Disputes Settlement and Appellate Tribunal (TDSAT)",
            "NCLAT",
            "High Court",
            "Supreme Court"
          ],
          "correct": 0,
          "explanation": "TDSAT was established in 2000 under Section 14 of the TRAI Act to adjudicate disputes between licensors, licensees, service providers, and consumers."
        },
        {
          "id": 15,
          "question": "Who was appointed as the Chairperson of the Central Board of Direct Taxes (CBDT) in mid-2024?",
          "options": [
            "Ravi Agrawal",
            "Nitin Gupta",
            "JB Mohapatra",
            "PC Mody"
          ],
          "correct": 0,
          "explanation": "Senior IRS officer Ravi Agrawal (1988 batch) took charge as the Chairman of the Central Board of Direct Taxes, succeeding Nitin Gupta."
        },
        {
          "id": 16,
          "question": "Who is the Chairman of the Central Board of Indirect Taxes and Customs (CBIC)?",
          "options": [
            "Sanjay Kumar Agarwal",
            "Vivek Johri",
            "M. Ajit Kumar",
            "Pranab Kumar Das"
          ],
          "correct": 0,
          "explanation": "Sanjay Kumar Agarwal serves as the Chairman of CBIC, administering GST, Central Excise, Customs, and narcotics enforcement under the Department of Revenue."
        },
        {
          "id": 17,
          "question": "Under which statutory Act are the Central Board of Direct Taxes (CBDT) and Central Board of Indirect Taxes and Customs (CBIC) constituted?",
          "options": [
            "Central Boards of Revenue Act, 1963",
            "Income Tax Act, 1961",
            "Customs Act, 1962",
            "Finance Act, 1994"
          ],
          "correct": 0,
          "explanation": "Both CBDT and CBIC derive their statutory existence from the Central Boards of Revenue Act, 1963, functioning under the Department of Revenue, Ministry of Finance."
        },
        {
          "id": 18,
          "question": "Who was appointed as the President of the Confederation of Indian Industry (CII) for 2024-2025?",
          "options": [
            "Sanjiv Puri (Chairman and MD of ITC Limited)",
            "R. Dinesh",
            "Sanjiv Bajaj",
            "TV Narendran"
          ],
          "correct": 0,
          "explanation": "Sanjiv Puri, Chairman and Managing Director of ITC Limited, assumed office as the President of CII, India's premier industry body."
        },
        {
          "id": 19,
          "question": "Who was appointed as the President of the Federation of Indian Chambers of Commerce and Industry (FICCI)?",
          "options": [
            "Harsha Vardhan Agarwal / Anish Shah",
            "Subhrakant Panda",
            "Sanjiv Mehta",
            "Uday Shankar"
          ],
          "correct": 0,
          "explanation": "Leading corporate leaders rotate to head FICCI, India's oldest non-government, not-for-profit apex business organization founded in 1927 by GD Birla and Purshottamdas Thakurdas."
        },
        {
          "id": 20,
          "question": "Who was appointed as the President of ASSOCHAM (Associated Chambers of Commerce and Industry of India)?",
          "options": [
            "Sanjay Nayar",
            "Ajay Singh",
            "Sumant Sinha",
            "Vineet Agarwal"
          ],
          "correct": 0,
          "explanation": "Former KKR India head Sanjay Nayar took over as the President of ASSOCHAM."
        },
        {
          "id": 21,
          "question": "Which veteran scientist was appointed as the President of the Indian National Science Academy (INSA)?",
          "options": [
            "Prof. Ashutosh Sharma",
            "Prof. Chandrima Shaha",
            "Prof. K. VijayRaghavan",
            "Dr. Shekhar Mande"
          ],
          "correct": 0,
          "explanation": "Former DST Secretary Prof. Ashutosh Sharma was chosen to steer INSA, the apex body of Indian scientists."
        },
        {
          "id": 22,
          "question": "Where are the headquarters of the Indian National Science Academy (INSA) located?",
          "options": [
            "Bahadur Shah Zafar Marg, New Delhi",
            "Bengaluru",
            "Kolkata",
            "Pune"
          ],
          "correct": 0,
          "explanation": "INSA was established in 1935 as the National Institute of Sciences of India and has its headquarters in New Delhi."
        },
        {
          "id": 23,
          "question": "Who is the Director General of the Council of Scientific and Industrial Research (CSIR), the first woman to lead CSIR?",
          "options": [
            "Dr. N. Kalaiselvi",
            "Dr. Shekhar Mande",
            "Dr. R.A. Mashelkar",
            "Dr. Soumya Swaminathan"
          ],
          "correct": 0,
          "explanation": "Eminent electrochemist Dr. Nallathamby Kalaiselvi is the first woman Director General of CSIR and Secretary of the Department of Scientific and Industrial Research (DSIR)."
        },
        {
          "id": 24,
          "question": "Where are the headquarters of the Council of Scientific and Industrial Research (CSIR) located?",
          "options": [
            "Anusandhan Bhawan, Rafi Marg, New Delhi",
            "Bengaluru",
            "Pune",
            "Hyderabad"
          ],
          "correct": 0,
          "explanation": "CSIR, India's largest research and development organization founded in 1942, operates 37 national laboratories and is based at Anusandhan Bhawan in New Delhi."
        },
        {
          "id": 25,
          "question": "Who is the ex-officio President of the Council of Scientific and Industrial Research (CSIR)?",
          "options": [
            "The Prime Minister of India",
            "The Union Minister of Science and Technology",
            "The Principal Scientific Adviser",
            "The Director General of CSIR"
          ],
          "correct": 0,
          "explanation": "Under CSIR's constitution, the Prime Minister of India serves as the ex-officio President of CSIR, while the Union Minister of Science and Technology is Vice President."
        }
      ]
    },
    "awards_appointments_jun2026": {
      "id": "awards_appointments_jun2026",
      "category_id": "awards_appointments",
      "category_name": "Awards, Honours & Appointments",
      "month_id": "jun2026",
      "month_name": "June 2026",
      "title": "Awards & Appointments Current Affairs - June 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "The Sahitya Akademi announced the winners of the Bal Sahitya Puraskar and Sahitya Akademi Yuva Puraskar in June 2026 across how many recognized Indian languages?",
          "options": [
            "24 languages (22 Eighth Schedule languages plus English and Rajasthani)",
            "22 languages",
            "20 languages",
            "28 languages"
          ],
          "correct": 0,
          "explanation": "Sahitya Akademi recognizes 24 languages: the 22 languages enumerated in the Eighth Schedule of the Constitution, along with English and Rajasthani."
        },
        {
          "id": 2,
          "question": "In which year was the Sahitya Akademi (India's National Academy of Letters) established by the Government of India?",
          "options": [
            "1954 (March 12, 1954)",
            "1950",
            "1952",
            "1960"
          ],
          "correct": 0,
          "explanation": "The Sahitya Akademi was formally inaugurated on March 12, 1954, by the Government of India, with Jawaharlal Nehru serving as its first President."
        },
        {
          "id": 3,
          "question": "Where are the headquarters of the Sahitya Akademi located?",
          "options": [
            "Rabindra Bhavan, Ferozeshah Road, New Delhi",
            "Kolkata",
            "Bengaluru",
            "Mumbai"
          ],
          "correct": 0,
          "explanation": "Rabindra Bhavan in New Delhi houses the national academies: Sahitya Akademi, Sangeet Natak Akademi, and Lalit Kala Akademi."
        },
        {
          "id": 4,
          "question": "Who is the current President of the Sahitya Akademi?",
          "options": [
            "Madhav Kaushik",
            "Chandrashekhar Kambar",
            "Vishwanath Prasad Tiwari",
            "Sunil Gangopadhyay"
          ],
          "correct": 0,
          "explanation": "Hindi poet and author Madhav Kaushik serves as the President of the Sahitya Akademi."
        },
        {
          "id": 5,
          "question": "Who was re-appointed as the Principal Secretary to Prime Minister Narendra Modi in June 2026?",
          "options": [
            "Dr. Pramod Kumar Mishra (P.K. Mishra)",
            "Ajit Doval",
            "Amit Khare",
            "Tarun Kapoor"
          ],
          "correct": 0,
          "explanation": "Senior bureaucrat Dr. P.K. Mishra (1972 batch Gujarat cadre IAS) was re-appointed as Principal Secretary to PM Modi with Cabinet rank."
        },
        {
          "id": 6,
          "question": "Who was re-appointed as the National Security Advisor (NSA) to the Prime Minister in June 2026?",
          "options": [
            "Ajit Doval",
            "P.K. Mishra",
            "General Anil Chauhan",
            "T.V. Somanathan"
          ],
          "correct": 0,
          "explanation": "Former Intelligence Bureau chief Ajit Doval (1968 batch IPS officer) was re-appointed for a historic third consecutive term as NSA with Union Cabinet status."
        },
        {
          "id": 7,
          "question": "Who were appointed as Advisors to the Prime Minister in the Prime Minister's Office (PMO)?",
          "options": [
            "Amit Khare and Tarun Kapoor",
            "Arvind Shrivastava and P.K. Mishra",
            "Sanjeev Sanyal and Bibek Debroy",
            "V. Anantha Nageswaran"
          ],
          "correct": 0,
          "explanation": "Retired senior IAS officers Amit Khare and Tarun Kapoor had their tenures extended as key policy Advisors to the Prime Minister."
        },
        {
          "id": 8,
          "question": "Who was appointed as the Director of the Intelligence Bureau (IB), with his tenure extended by the Central Government?",
          "options": [
            "Tapan Kumar Deka",
            "Samant Goel",
            "Ravi Sinha",
            "Dinkar Gupta"
          ],
          "correct": 0,
          "explanation": "Senior IPS officer Tapan Kumar Deka (1988 batch Himachal Pradesh cadre) serves as the Director of the Intelligence Bureau (DIB)."
        },
        {
          "id": 9,
          "question": "Who is the Secretary of the Research and Analysis Wing (R&AW), India's foreign intelligence agency?",
          "options": [
            "Ravi Sinha",
            "Samant Goel",
            "Anil Dhasmana",
            "Alok Joshi"
          ],
          "correct": 0,
          "explanation": "Senior IPS officer Ravi Sinha (1988 batch Chhattisgarh cadre) heads R&AW under the direct supervision of the Prime Minister's Office."
        },
        {
          "id": 10,
          "question": "Who is the Director of the Central Bureau of Investigation (CBI)?",
          "options": [
            "Praveen Sood",
            "Subodh Kumar Jaiswal",
            "Rishi Kumar Shukla",
            "Alok Verma"
          ],
          "correct": 0,
          "explanation": "Former Karnataka Director General of Police Praveen Sood (1986 batch IPS) was appointed as the Director of the CBI for a two-year tenure."
        },
        {
          "id": 11,
          "question": "Under which statutory enactment does the Central Bureau of Investigation (CBI) derive its police powers to investigate offences?",
          "options": [
            "Delhi Special Police Establishment (DSPE) Act, 1946",
            "CBI Act, 1963",
            "Police Act, 1861",
            "Code of Criminal Procedure"
          ],
          "correct": 0,
          "explanation": "The CBI is not a statutory body created by an independent CBI Act; it derives all its investigative jurisdiction and police powers from the DSPE Act, 1946."
        },
        {
          "id": 12,
          "question": "Who comprises the high-powered statutory committee that recommends the appointment of the CBI Director under Section 4A of the DSPE Act?",
          "options": [
            "The Prime Minister (Chairperson), Leader of Opposition in Lok Sabha, and Chief Justice of India (or SC Judge nominated by CJI)",
            "Prime Minister and Home Minister only",
            "President and CJI",
            "Cabinet Secretary and Home Secretary"
          ],
          "correct": 0,
          "explanation": "Pursuant to the Lokpal Act and Supreme Court mandates, the selection panel consists of the PM, Leader of the Opposition in Lok Sabha, and the Chief Justice of India."
        },
        {
          "id": 13,
          "question": "Who was appointed as the Chairman of the State Bank of India (SBI) in 2024, succeeding Dinesh Kumar Khara?",
          "options": [
            "Challa Sreenivasulu Setty (C.S. Setty)",
            "Dinesh Kumar Khara",
            "Rajnish Kumar",
            "Arundhati Bhattacharya"
          ],
          "correct": 0,
          "explanation": "C.S. Setty was appointed by the Financial Services Institutions Bureau (FSIB) and Appointments Committee of the Cabinet as the Chairman of SBI."
        },
        {
          "id": 14,
          "question": "What autonomous body recommends appointments for wholetime directors and non-executive chairpersons in public sector banks and financial institutions?",
          "options": [
            "Financial Services Institutions Bureau (FSIB)",
            "Banks Board Bureau (BBB)",
            "RBI Board",
            "UPSC"
          ],
          "correct": 0,
          "explanation": "FSIB replaced the erstwhile Banks Board Bureau (BBB) in 2022 to recommend board-level appointments in state-run banks, insurers, and financial institutions."
        },
        {
          "id": 15,
          "question": "Who is the Chairperson of the Financial Services Institutions Bureau (FSIB)?",
          "options": [
            "Bhanu Pratap Sharma (former DoPT Secretary)",
            "Vinod Rai",
            "M. Damodaran",
            "U.K. Sinha"
          ],
          "correct": 0,
          "explanation": "Bhanu Pratap Sharma heads the FSIB, which screens and recommends chiefs for nationalized banks and public insurers."
        },
        {
          "id": 16,
          "question": "Who was appointed as the Deputy Governor of the Reserve Bank of India, in charge of monetary policy?",
          "options": [
            "Dr. Michael Debabrata Patra",
            "Swaminathan J.",
            "T. Rabi Sankar",
            "M. Rajeshwar Rao"
          ],
          "correct": 0,
          "explanation": "Dr. Michael Debabrata Patra serves as Deputy Governor overseeing the Monetary Policy Department and sits on the MPC."
        },
        {
          "id": 17,
          "question": "How many Deputy Governors can the Reserve Bank of India have under Section 8 of the RBI Act, 1934?",
          "options": [
            "Not more than four Deputy Governors",
            "Three Deputy Governors",
            "Two Deputy Governors",
            "Five Deputy Governors"
          ],
          "correct": 0,
          "explanation": "Under Section 8(1)(a) of the RBI Act, the Central Board consists of a Governor and not more than four Deputy Governors appointed by the Central Government."
        },
        {
          "id": 18,
          "question": "Who is the 25th Governor of the Reserve Bank of India, serving since December 2018?",
          "options": [
            "Shaktikanta Das",
            "Urjit Patel",
            "Raghuram Rajan",
            "D. Subbarao"
          ],
          "correct": 0,
          "explanation": "Shaktikanta Das (former Economic Affairs Secretary) assumed charge on December 12, 2018, and was conferred 'Governor of the Year' by Central Banking in London."
        },
        {
          "id": 19,
          "question": "Who was awarded the 'Central Banker of the Year / Governor of the Year Award' by international publication Central Banking in 2023-2024?",
          "options": [
            "Shaktikanta Das (Governor, RBI)",
            "Jerome Powell",
            "Christine Lagarde",
            "Andrew Bailey"
          ],
          "correct": 0,
          "explanation": "Shaktikanta Das was awarded the prestigious international award for steering India's financial system through the pandemic and geopolitical crises."
        },
        {
          "id": 20,
          "question": "Who was appointed as the Director General of the Geological Survey of India (GSI)?",
          "options": [
            "Janardan Prasad / Asit Saha",
            "S. Raju",
            "Rajendra Singh Garkhal",
            "N. Kutumba Rao"
          ],
          "correct": 0,
          "explanation": "Senior geologists lead GSI, which operates under the Ministry of Mines, discovering lithium deposits in Jammu & Kashmir and rare earths across the country."
        },
        {
          "id": 21,
          "question": "Where are the headquarters of the Geological Survey of India (GSI) located?",
          "options": [
            "Kolkata, West Bengal",
            "New Delhi",
            "Nagpur, Maharashtra",
            "Hyderabad, Telangana"
          ],
          "correct": 0,
          "explanation": "GSI is one of the oldest scientific survey bodies in the world, founded in 1851 by Thomas Oldham, with permanent headquarters in Kolkata."
        },
        {
          "id": 22,
          "question": "Where are the headquarters of the Archaeological Survey of India (ASI) situated?",
          "options": [
            "Dharohar Bhawan, Tilak Marg, New Delhi",
            "Kolkata",
            "Varanasi",
            "Agra"
          ],
          "correct": 0,
          "explanation": "The Archaeological Survey of India, founded in 1861 by Sir Alexander Cunningham (its first Director General), is based in New Delhi."
        },
        {
          "id": 23,
          "question": "Who was the founder and first Director General of the Archaeological Survey of India (ASI)?",
          "options": [
            "Sir Alexander Cunningham ('Father of Indian Archaeology')",
            "Sir John Marshall",
            "Mortimer Wheeler",
            "James Prinsep"
          ],
          "correct": 0,
          "explanation": "Sir Alexander Cunningham was appointed as the Archaeological Surveyor to the Government of India in 1861 and became the first Director General of ASI in 1871."
        },
        {
          "id": 24,
          "question": "Who was the Director General of the ASI during the historic excavations that led to the discovery of Mohenjo-daro and Harappa in the 1920s?",
          "options": [
            "Sir John Marshall",
            "Alexander Cunningham",
            "Aurel Stein",
            "Dayaram Sahni"
          ],
          "correct": 0,
          "explanation": "Sir John Marshall served as Director General of ASI from 1902 to 1928, announcing the discovery of the ancient Indus Valley Civilization to the world in 1924."
        },
        {
          "id": 25,
          "question": "Which Indian epigraphist and scholar deciphered the Brahmi script used in Ashoka's rock and pillar edicts in 1837?",
          "options": [
            "James Prinsep",
            "Alexander Cunningham",
            "William Jones",
            "Max Müller"
          ],
          "correct": 0,
          "explanation": "James Prinsep, an Anglo-Indian scholar and founding editor of the Journal of the Asiatic Society of Bengal, deciphered the Brahmi and Kharosthi scripts in 1837."
        }
      ]
    },
    "awards_appointments_jul2026": {
      "id": "awards_appointments_jul2026",
      "category_id": "awards_appointments",
      "category_name": "Awards, Honours & Appointments",
      "month_id": "jul2026",
      "month_name": "July 2026",
      "title": "Awards & Appointments Current Affairs - July 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "Prime Minister Narendra Modi was conferred the 'Order of St. Andrew the Apostle the First-Called' in Moscow in July 2026. What is the significance of this honour?",
          "options": [
            "The highest state decoration and order of chivalry of the Russian Federation",
            "The highest Russian military medal",
            "A civic peace prize",
            "An honorary doctorate"
          ],
          "correct": 0,
          "explanation": "Established by Tsar Peter the Great in 1698, the Order of St. Andrew is Russia's highest decoration, conferred on PM Modi for developing special strategic partnership."
        },
        {
          "id": 2,
          "question": "How many foreign state honours and highest civilian decorations has Prime Minister Narendra Modi received from foreign nations as of mid-2026?",
          "options": [
            "15+ highest civilian awards from foreign nations",
            "8 awards",
            "10 awards",
            "5 awards"
          ],
          "correct": 0,
          "explanation": "Prime Minister Modi has been conferred highest state honours by over 15 nations, including Russia, France, Egypt, Saudi Arabia, UAE, Afghanistan, Bahrain, Bhutan, Greece, and Nigeria."
        },
        {
          "id": 3,
          "question": "Which is the highest civilian award of France, conferred upon Prime Minister Narendra Modi during his visit as Chief Guest for Bastille Day?",
          "options": [
            "Grand Cross of the Legion of Honour (Grand-Croix de la Légion d'Honneur)",
            "Order of Agricultural Merit",
            "National Order of Merit",
            "Military Medal"
          ],
          "correct": 0,
          "explanation": "French President Emmanuel Macron bestowed the Grand Cross of the Legion of Honour—France's highest military and civilian order—upon PM Modi in Paris."
        },
        {
          "id": 4,
          "question": "Which is the highest civilian honour of Egypt, presented to Prime Minister Narendra Modi in Cairo by President Abdel Fattah El-Sisi?",
          "options": [
            "Order of the Nile (Collar of the Nile)",
            "Order of the Republic",
            "Order of Merit",
            "Medal of the Sinai"
          ],
          "correct": 0,
          "explanation": "President El-Sisi conferred Egypt's highest state decoration, the Collar of the Nile, on PM Modi during his landmark state visit to Cairo."
        },
        {
          "id": 5,
          "question": "Which is the highest civilian decoration of Greece, conferred upon Prime Minister Narendra Modi in Athens?",
          "options": [
            "Grand Cross of the Order of Honour",
            "Order of the Phoenix",
            "Order of the Redeemer",
            "Cross of Valour"
          ],
          "correct": 0,
          "explanation": "Greek President Katerina Sakellaropoulou bestowed the Grand Cross of the Order of Honour upon Prime Minister Modi in Athens."
        },
        {
          "id": 6,
          "question": "Who is the Chief Justice of India (CJI) serving in 2024-2026, succeeding Justice D.Y. Chandrachud?",
          "options": [
            "Justice Sanjiv Khanna",
            "Justice B.R. Gavai",
            "Justice Surya Kant",
            "Justice Uday Umesh Lalit"
          ],
          "correct": 0,
          "explanation": "Justice Sanjiv Khanna was appointed as the 51st Chief Justice of India upon the superannuation of the 50th CJI, Justice D.Y. Chandrachud, on November 10, 2024."
        },
        {
          "id": 7,
          "question": "Who served as the 50th Chief Justice of India for a pivotal two-year tenure from November 2022 to November 2024?",
          "options": [
            "Justice Dhananjaya Yeshwant Chandrachud (D.Y. Chandrachud)",
            "Justice U.U. Lalit",
            "Justice N.V. Ramana",
            "Justice S.A. Bobde"
          ],
          "correct": 0,
          "explanation": "Justice D.Y. Chandrachud served as the 50th CJI, authoring historic verdicts on digital courts, Article 370 revocation validity, electoral bonds, and marriage equality."
        },
        {
          "id": 8,
          "question": "Who is scheduled in seniority to become the 52nd Chief Justice of India in May 2025?",
          "options": [
            "Justice Bhushan Ramkrishna Gavai (B.R. Gavai)",
            "Justice Surya Kant",
            "Justice Vikram Nath",
            "Justice B.V. Nagarathna"
          ],
          "correct": 0,
          "explanation": "Justice B.R. Gavai is in line of succession to become the second Dalit Chief Justice of India after Justice K.G. Balakrishnan."
        },
        {
          "id": 9,
          "question": "Who is slated to become the first woman Chief Justice of India in September 2027?",
          "options": [
            "Justice B.V. Nagarathna",
            "Justice Hima Kohli",
            "Justice Bela M. Trivedi",
            "Justice Fathima Beevi"
          ],
          "correct": 0,
          "explanation": "Justice B.V. Nagarathna of the Supreme Court of India is in line to become the nation's first female Chief Justice of India in September 2027."
        },
        {
          "id": 10,
          "question": "Who was the first woman judge of the Supreme Court of India, appointed in 1989?",
          "options": [
            "Justice M. Fathima Beevi",
            "Justice Sujata Manohar",
            "Justice Ruma Pal",
            "Justice Gyan Sudha Misra"
          ],
          "correct": 0,
          "explanation": "Justice M. Fathima Beevi was appointed as the first female judge of the Supreme Court of India on October 6, 1989, later serving as Governor of Tamil Nadu."
        },
        {
          "id": 11,
          "question": "Who was the first Chief Justice of independent India under the Constitution?",
          "options": [
            "Sir Harilal Jekisundas Kania (H.J. Kania)",
            "M. Patanjali Sastri",
            "Mehr Chand Mahajan",
            "Sudhi Ranjan Das"
          ],
          "correct": 0,
          "explanation": "Justice H.J. Kania took the oath of office as the first Chief Justice of India on January 26, 1950, when the Supreme Court came into existence."
        },
        {
          "id": 12,
          "question": "Who held the longest tenure as Chief Justice of India, serving for over seven years from 1978 to 1985?",
          "options": [
            "Justice Y.V. Chandrachud (Yeshwant Vishnu Chandrachud)",
            "Justice P.N. Bhagwati",
            "Justice A.N. Ray",
            "Justice R.S. Pathak"
          ],
          "correct": 0,
          "explanation": "Justice Y.V. Chandrachud served as the 16th CJI for 7 years and 139 days (from February 1978 to July 1985), the longest in Indian judicial history."
        },
        {
          "id": 13,
          "question": "Who held the shortest tenure as Chief Justice of India, serving for just 17 days in 1991?",
          "options": [
            "Justice Kamal Narain Singh (K.N. Singh)",
            "Justice S. Rajendra Babu",
            "Justice J.C. Shah",
            "Justice G.B. Patnaik"
          ],
          "correct": 0,
          "explanation": "Justice K.N. Singh served as the 22nd CJI for exactly 17 days (from November 25, 1991 to December 12, 1991)."
        },
        {
          "id": 14,
          "question": "Who is known as the 'Father of Public Interest Litigation (PIL)' in India along with Justice V.R. Krishna Iyer?",
          "options": [
            "Justice P.N. Bhagwati",
            "Justice Y.V. Chandrachud",
            "Justice H.R. Khanna",
            "Justice Subba Rao"
          ],
          "correct": 0,
          "explanation": "Justice P.N. Bhagwati and Justice V.R. Krishna Iyer pioneered Public Interest Litigation (epistolary jurisdiction) to give marginalized citizens access to justice."
        },
        {
          "id": 15,
          "question": "Which legendary Supreme Court judge delivered the lone dissenting judgment in the ADM Jabalpur v. Shivkant Shukla (Habeas Corpus case) during the Emergency?",
          "options": [
            "Justice H.R. Khanna (Hans Raj Khanna)",
            "Justice M.H. Beg",
            "Justice A.N. Ray",
            "Justice P.N. Bhagwati"
          ],
          "correct": 0,
          "explanation": "Justice H.R. Khanna courageously ruled that the right to life and personal liberty under Article 21 cannot be suspended even during a National Emergency, sacrificing his seniority for CJI."
        },
        {
          "id": 16,
          "question": "Who is the Attorney General for India, the highest law officer in the country under Article 76?",
          "options": [
            "R. Venkataramani",
            "Tushar Mehta",
            "K.K. Venugopal",
            "Mukul Rohatgi"
          ],
          "correct": 0,
          "explanation": "Senior advocate R. Venkataramani was appointed as the 16th Attorney General for India in October 2022."
        },
        {
          "id": 17,
          "question": "Who is the Solicitor General of India, the second highest law officer of the country?",
          "options": [
            "Tushar Mehta",
            "Chetan Sharma",
            "Aishwarya Bhati",
            "K.M. Nataraj"
          ],
          "correct": 0,
          "explanation": "Senior advocate Tushar Mehta has served as the Solicitor General of India since October 2018, receiving multiple tenure extensions."
        },
        {
          "id": 18,
          "question": "What unique right does the Attorney General for India have in Parliament under Article 88 of the Constitution?",
          "options": [
            "The right to speak in and participate in proceedings of either House of Parliament or joint sittings, but without the right to vote",
            "Full voting rights in Lok Sabha",
            "Right to introduce money bills",
            "Right to preside over Rajya Sabha"
          ],
          "correct": 0,
          "explanation": "Under Article 88, the Attorney General can speak and take part in proceedings of both Houses and parliamentary committees, but does not possess the right to cast a vote."
        },
        {
          "id": 19,
          "question": "What qualifications are required under Article 76(1) to be appointed as the Attorney General for India?",
          "options": [
            "A person qualified to be appointed as a Judge of the Supreme Court",
            "A retired Supreme Court judge",
            "A member of Parliament",
            "A senior law ministry secretary"
          ],
          "correct": 0,
          "explanation": "The President appoints a person who is qualified to be appointed a Judge of the Supreme Court (citizen of India, High Court judge for 5 years or HC advocate for 10 years, or eminent jurist)."
        },
        {
          "id": 20,
          "question": "What is the tenure of the Attorney General for India specified in the Constitution?",
          "options": [
            "Holds office during the pleasure of the President (no fixed constitutional term)",
            "5 years fixed",
            "6 years or age 65",
            "3 years"
          ],
          "correct": 0,
          "explanation": "Article 76(4) specifies that the Attorney General shall hold office during the pleasure of the President and receive such remuneration as the President may determine."
        },
        {
          "id": 21,
          "question": "Who was the first Attorney General for independent India, holding office for a record 13 years from 1950 to 1963?",
          "options": [
            "M.C. Setalvad (Motilal Chimanlal Setalvad)",
            "C.K. Daphtary",
            "Niren De",
            "Fali S. Nariman"
          ],
          "correct": 0,
          "explanation": "M.C. Setalvad was India's first and longest-serving Attorney General, and also served as the first Chairman of the Law Commission of independent India."
        },
        {
          "id": 22,
          "question": "Who is the Chairman of the National Medical Commission (NMC), the apex regulator for medical education in India?",
          "options": [
            "Dr. B.N. Gangadhar",
            "Dr. Suresh Chandra Sharma",
            "Dr. Abhijat Sheth",
            "Dr. Rajiv Bahl"
          ],
          "correct": 0,
          "explanation": "Former NIMHANS Director Dr. B.N. Gangadhar was appointed as the Chairperson of the National Medical Commission, which replaced the Medical Council of India (MCI)."
        },
        {
          "id": 23,
          "question": "Who is the Director General of the Indian Council of Medical Research (ICMR) and Secretary, Department of Health Research?",
          "options": [
            "Dr. Rajiv Bahl",
            "Dr. Balram Bhargava",
            "Dr. Soumya Swaminathan",
            "Dr. V.M. Katoch"
          ],
          "correct": 0,
          "explanation": "Distinguished public health scientist Dr. Rajiv Bahl serves as the Director General of ICMR, headquartered at Ansari Nagar, New Delhi."
        },
        {
          "id": 24,
          "question": "Where are the headquarters of the Indian Council of Medical Research (ICMR) located?",
          "options": [
            "New Delhi (Ansari Nagar)",
            "Pune, Maharashtra",
            "Kolkata",
            "Chennai"
          ],
          "correct": 0,
          "explanation": "ICMR, founded in 1911 as the Indian Research Fund Association (IRFA), is one of the oldest biomedical research bodies in the world, based in New Delhi."
        },
        {
          "id": 25,
          "question": "Where is the National Institute of Virology (NIV), a premier ICMR laboratory specializing in viral research and vaccine development, located?",
          "options": [
            "Pune, Maharashtra",
            "Hyderabad, Telangana",
            "Bengaluru, Karnataka",
            "Kolkata, West Bengal"
          ],
          "correct": 0,
          "explanation": "ICMR-NIV in Pune played a historic role in isolating the SARS-CoV-2 virus and co-developing India's indigenous Covid vaccine 'Covaxin' with Bharat Biotech."
        }
      ]
    },
    "awards_appointments_aug2026": {
      "id": "awards_appointments_aug2026",
      "category_id": "awards_appointments",
      "category_name": "Awards, Honours & Appointments",
      "month_id": "aug2026",
      "month_name": "August 2026",
      "title": "Awards & Appointments Current Affairs - August 2026",
      "time_limit_minutes": 25,
      "questions": [
        {
          "id": 1,
          "question": "Who was appointed as the new Cabinet Secretary of India in August 2026, succeeding Rajiv Gauba after his record five-year tenure?",
          "options": [
            "Dr. T.V. Somanathan (former Finance Secretary)",
            "Rajiv Gauba",
            "Ajay Kumar Bhalla",
            "Govind Mohan"
          ],
          "correct": 0,
          "explanation": "Dr. T.V. Somanathan (1987 batch Tamil Nadu cadre IAS officer) was appointed as the Cabinet Secretary of India, the top-most civil servant in the Government of India."
        },
        {
          "id": 2,
          "question": "Who was appointed as the Union Home Secretary in August 2026, succeeding Ajay Kumar Bhalla?",
          "options": [
            "Govind Mohan",
            "Ajay Kumar Bhalla",
            "T.V. Somanathan",
            "Punya Salila Srivastava"
          ],
          "correct": 0,
          "explanation": "Govind Mohan (1989 batch Sikkim cadre IAS officer, former Culture Secretary) took charge as the Union Home Secretary in the Ministry of Home Affairs."
        },
        {
          "id": 3,
          "question": "Who was appointed as the Chairman of the Union Public Service Commission (UPSC) in August 2024, succeeding Dr. Manoj Soni?",
          "options": [
            "Preeti Sudan (former Union Health Secretary)",
            "Dr. Manoj Soni",
            "Pradeep Kumar Joshi",
            "Arvind Saxena"
          ],
          "correct": 0,
          "explanation": "Former Union Health Secretary Preeti Sudan (1983 batch Andhra Pradesh cadre IAS officer) was appointed by the President as the Chairperson of the UPSC."
        },
        {
          "id": 4,
          "question": "The President of India presented the inaugural 'Rashtriya Vigyan Puraskar' awards at Rashtrapati Bhavan on National Space Day in August 2026. Who was conferred the prestigious 'Vigyan Ratna' (the lifetime achievement award in science)?",
          "options": [
            "Prof. Govindarajan Padmanabhan (former Director of IISc Bengaluru)",
            "Dr. Annapurni Subramaniam",
            "Prof. Jayant Narlikar",
            "Prof. CNR Rao"
          ],
          "correct": 0,
          "explanation": "Eminent biochemist and pioneer of malaria parasite molecular biology Prof. G. Padmanabhan received the premier 'Vigyan Ratna' award from President Droupadi Murmu."
        },
        {
          "id": 5,
          "question": "How many categories comprise the unified 'Rashtriya Vigyan Puraskar' instituted by the Government of India to replace legacy science awards?",
          "options": [
            "4 categories: Vigyan Ratna, Vigyan Shri, Vigyan Yuva-Shanti Swarup Bhatnagar, and Vigyan Team",
            "3 categories",
            "5 categories",
            "2 categories"
          ],
          "correct": 0,
          "explanation": "The Government consolidated dozens of science prizes into four prestigious tiers: Vigyan Ratna (lifetime), Vigyan Shri (distinguished contribution), Vigyan Yuva-SSB (under 45 years), and Vigyan Team (collaborative breakthroughs)."
        },
        {
          "id": 6,
          "question": "Which landmark mission was conferred the 'Vigyan Team' award at the inaugural Rashtriya Vigyan Puraskar ceremony?",
          "options": [
            "Chandrayaan-3 Team (ISRO)",
            "Aditya-L1 Team",
            "Gaganyaan Team",
            "Deep Ocean Mission Team"
          ],
          "correct": 0,
          "explanation": "The ISRO Chandrayaan-3 team was honoured with the Vigyan Team award for accomplishing India's historic soft landing near the lunar south pole."
        },
        {
          "id": 7,
          "question": "Who was awarded the prestigious Major Dhyan Chand Khel Ratna Award, India's highest sporting honour, announced in the National Sports Awards?",
          "options": [
            "Satwiksairaj Rankireddy and Chirag Shetty (Badminton duo)",
            "Neeraj Chopra",
            "Sharath Kamal",
            "Manu Bhaker"
          ],
          "correct": 0,
          "explanation": "Dynamic men's doubles pair Satwiksairaj Rankireddy and Chirag Shetty received the Khel Ratna for their sensational triumphs at the Asian Games, Asian Championships, and Indonesia Open."
        },
        {
          "id": 8,
          "question": "What is the cash prize awarded to recipients of the Major Dhyan Chand Khel Ratna Award?",
          "options": [
            "₹25 lakh, a medal, and a citation",
            "₹15 lakh",
            "₹10 lakh",
            "₹50 lakh"
          ],
          "correct": 0,
          "explanation": "The Khel Ratna award carries a cash prize of ₹25 lakh (enhanced from ₹7.5 lakh in 2020), making it the highest monetary sports honour in India."
        },
        {
          "id": 9,
          "question": "In which year was the 'Rajiv Gandhi Khel Ratna Award' officially renamed as the 'Major Dhyan Chand Khel Ratna Award'?",
          "options": [
            "August 2021",
            "2019",
            "2020",
            "2022"
          ],
          "correct": 0,
          "explanation": "Prime Minister Narendra Modi announced the renaming of the Khel Ratna on August 6, 2021, in honor of hockey wizard Major Dhyan Chand."
        },
        {
          "id": 10,
          "question": "Who was the very first recipient of the Khel Ratna Award in 1991-92?",
          "options": [
            "Viswanathan Anand (Chess Grandmaster)",
            "Geet Sethi",
            "Sachin Tendulkar",
            "Karnam Malleswari"
          ],
          "correct": 0,
          "explanation": "India's first chess Grandmaster and five-time World Chess Champion Viswanathan Anand was the inaugural winner of the Khel Ratna in 1991-92."
        },
        {
          "id": 11,
          "question": "Who was the first woman athlete to receive the Khel Ratna Award in 1994-95?",
          "options": [
            "Karnam Malleswari (Weightlifting)",
            "Kunjurani Devi",
            "Mary Kom",
            "Sania Mirza"
          ],
          "correct": 0,
          "explanation": "Olympic bronze medallist weightlifter Karnam Malleswari was the first female recipient of the prestigious award."
        },
        {
          "id": 12,
          "question": "What is the cash prize awarded to recipients of the 'Arjuna Award' for outstanding performance in sports and games?",
          "options": [
            "₹15 lakh, a bronze statuette of Arjuna, and a citation",
            "₹10 lakh",
            "₹25 lakh",
            "₹5 lakh"
          ],
          "correct": 0,
          "explanation": "The Arjuna Award carries a cash prize of ₹15 lakh, a bronze statuette of Arjuna, and a scroll of honour."
        },
        {
          "id": 13,
          "question": "Which award is conferred annually by the Ministry of Youth Affairs and Sports to recognize outstanding coaches in sports?",
          "options": [
            "Dronacharya Award (Regular and Lifetime categories)",
            "Arjuna Award",
            "Rashtriya Khel Protsahan Puruskar",
            "Tenzing Norgay Award"
          ],
          "correct": 0,
          "explanation": "The Dronacharya Award, instituted in 1985, honors coaches who have consistently enabled athletes to excel at international championships."
        },
        {
          "id": 14,
          "question": "What is the cash prize awarded for the Dronacharya Award in the Lifetime category?",
          "options": [
            "₹15 lakh",
            "₹10 lakh",
            "₹25 lakh",
            "₹5 lakh"
          ],
          "correct": 0,
          "explanation": "The Dronacharya Award Lifetime category carries a cash purse of ₹15 lakh, while the Regular category carries ₹10 lakh."
        },
        {
          "id": 15,
          "question": "Which award recognizes lifetime contribution to sports development and post-retirement dedication by veteran sportspersons?",
          "options": [
            "Dhyan Chand Award for Lifetime Achievement in Sports and Games",
            "Arjuna Award",
            "Khel Ratna",
            "Padma Shri"
          ],
          "correct": 0,
          "explanation": "Instituted in 2002, the Dhyan Chand Award honors sportspersons who have contributed to sports during their active career and continue to promote sports after retirement."
        },
        {
          "id": 16,
          "question": "What is the highest civilian award in India, instituted in 1954?",
          "options": [
            "Bharat Ratna",
            "Padma Vibhushan",
            "Padma Bhushan",
            "Param Vir Chakra"
          ],
          "correct": 0,
          "explanation": "Bharat Ratna, instituted on January 2, 1954, is the highest civilian award of the Republic of India, awarded for exceptional service/performance of the highest order."
        },
        {
          "id": 17,
          "question": "Who were the first three recipients of the Bharat Ratna in 1954?",
          "options": [
            "C. Rajagopalachari, Dr. Sarvepalli Radhakrishnan, and Dr. C.V. Raman",
            "Jawaharlal Nehru, Sardar Patel, and Rajendra Prasad",
            "Dr. B.R. Ambedkar, Bhagwan Das, and M. Visvesvaraya",
            "Govind Ballabh Pant, DK Karve, and BC Roy"
          ],
          "correct": 0,
          "explanation": "The first Bharat Ratna awards were conferred upon the last Governor-General C. Rajagopalachari, philosopher-statesman Dr. S. Radhakrishnan, and Nobel laureate physicist Dr. C.V. Raman."
        },
        {
          "id": 18,
          "question": "Who was the first person to be posthumously awarded the Bharat Ratna in 1966?",
          "options": [
            "Lal Bahadur Shastri",
            "Sardar Vallabhbhai Patel",
            "K. Kamaraj",
            "Dr. B.R. Ambedkar"
          ],
          "correct": 0,
          "explanation": "Prime Minister Lal Bahadur Shastri was the first person to be honoured posthumously with the Bharat Ratna following his sudden demise at Tashkent in 1966."
        },
        {
          "id": 19,
          "question": "Who was the first naturalized/foreign citizen to receive the Bharat Ratna in 1980?",
          "options": [
            "Mother Teresa",
            "Khan Abdul Ghaffar Khan",
            "Nelson Mandela",
            "Annie Besant"
          ],
          "correct": 0,
          "explanation": "Mother Teresa (naturalized Indian citizen) received the Bharat Ratna in 1980, followed by foreign nationals Khan Abdul Ghaffar Khan (1987) and Nelson Mandela (1990)."
        },
        {
          "id": 20,
          "question": "Who was the first non-Indian citizen without Indian citizenship to be awarded the Bharat Ratna in 1987?",
          "options": [
            "Khan Abdul Ghaffar Khan ('Frontier Gandhi')",
            "Nelson Mandela",
            "Martin Luther King Jr.",
            "Dalai Lama"
          ],
          "correct": 0,
          "explanation": "Pakistani national and legendary freedom fighter Khan Abdul Ghaffar Khan (Badshah Khan) was the first non-citizen to be awarded the Bharat Ratna in 1987."
        },
        {
          "id": 21,
          "question": "Who is the youngest recipient of the Bharat Ratna, awarded at the age of 40 in 2014?",
          "options": [
            "Sachin Tendulkar",
            "Rajiv Gandhi",
            "Indira Gandhi",
            "Abhinav Bindra"
          ],
          "correct": 0,
          "explanation": "Cricket icon Sachin Tendulkar became the youngest person and the first sportsperson to receive the Bharat Ratna in 2014."
        },
        {
          "id": 22,
          "question": "What is the design of the Bharat Ratna medallion?",
          "options": [
            "A peepal-leaf shaped medallion in bronze with a platinum sun and 'Bharat Ratna' embossed in Devanagari",
            "A lotus flower",
            "A gold coin",
            "An Ashoka pillar replica"
          ],
          "correct": 0,
          "explanation": "The medallion is cast in bronze in the shape of a peepal leaf, with an embossed replica of the Sun in platinum on the obverse and the State Emblem of India on the reverse."
        },
        {
          "id": 23,
          "question": "Does the Bharat Ratna award carry any monetary cash grant?",
          "options": [
            "No monetary grant is attached to the Bharat Ratna; it includes a Sanad (certificate signed by the President) and a medallion",
            "₹1 crore",
            "₹50 lakh",
            "₹25 lakh"
          ],
          "correct": 0,
          "explanation": "Unlike civilian gallantry or sports awards, no cash allowance is provided with the Bharat Ratna; recipients receive a presidential Sanad and a medallion, and figure 7th in the Table of Precedence."
        },
        {
          "id": 24,
          "question": "What is the maximum number of Bharat Ratna awards that can normally be conferred in a single calendar year under official regulations?",
          "options": [
            "Three awards (though exceptional special relaxations occurred in 1999 and 2024)",
            "Two awards",
            "One award",
            "Five awards"
          ],
          "correct": 0,
          "explanation": "Statutory regulations restrict Bharat Ratna awards to a maximum of three in a calendar year, although the government made rare exceptions in 1999 (4 awards) and 2024 (5 awards)."
        },
        {
          "id": 25,
          "question": "Which civilian decoration ranks immediately below the Bharat Ratna in the Indian honours system?",
          "options": [
            "Padma Vibhushan",
            "Padma Bhushan",
            "Padma Shri",
            "Param Vir Chakra"
          ],
          "correct": 0,
          "explanation": "The hierarchy of civilian honours is: 1. Bharat Ratna, 2. Padma Vibhushan (exceptional and distinguished service), 3. Padma Bhushan (distinguished service of high order), 4. Padma Shri (distinguished service)."
        }
      ]
    }
  }
};
